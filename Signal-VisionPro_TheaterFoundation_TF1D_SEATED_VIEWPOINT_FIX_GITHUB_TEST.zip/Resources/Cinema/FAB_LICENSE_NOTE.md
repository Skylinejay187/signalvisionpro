# Signal Fab Movie Theater asset

`SignalFabMovieTheater.usdz` is a purchased Fab asset supplied by the Signal project owner.
Source listing: https://www.fab.com/listings/027172ba-67aa-42f3-b43d-25adbbc5f7fb

The binary asset is included only for use inside the application build. Do not extract,
redistribute, publish, or offer the source asset as a standalone asset. Keep the original
purchased Blender/FBX/GLB/texture packages outside public source distributions.
