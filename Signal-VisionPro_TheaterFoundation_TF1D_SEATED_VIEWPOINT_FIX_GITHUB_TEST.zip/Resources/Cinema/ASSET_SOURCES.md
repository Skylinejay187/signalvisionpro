# Cinema Environment Asset / Reference Sources

## 3DAssets.dev — Cinema Multiplex and Foyer

- Source: https://3dassets.dev/packs/cinema-multiplex-and-foyer
- License reported by source: CC0 1.0 / public domain dedication; no attribution required.
- Build 31 use: dimensional and architectural reference only.
- Referenced ideas/dimensions include tiered seating, cinema seat/cupholder layout, aisle steps, screen proportions, acoustic wall panels, exit modules, projection-booth details, lightboxes, and foyer/theater construction vocabulary.
- No third-party GLB binary from this pack is bundled in Build 31.

## Apple visionOS immersive-media guidance

- Building an immersive media viewing experience:
  https://developer.apple.com/documentation/visionos/building-an-immersive-media-viewing-experience
- Presenting windows and spaces:
  https://developer.apple.com/documentation/visionos/presenting-windows-and-spaces

Build 31 follows the general guidance of treating the screen as part of the environment, maintaining a comfortable primary viewing position, and constructing a real spatial environment around the viewer. True video-color reflection/docking is intentionally not claimed in this build; the current implementation uses restrained environment/screen-spill lighting until it can be integrated without creating a second playback owner.

## SignalCinema_CC_BY_4.usdz (TF1A imported environment)
- Title: cinema/movie theater_[interior]
- Author: yuuuusukeeee / Comicaroid
- Source: https://sketchfab.com/3d-models/cinemamovie-theater-interior-dcaf6cdebcad4f03879c24186da257ee
- License: CC BY 4.0 — commercial use allowed with attribution.
- License URL: https://creativecommons.org/licenses/by/4.0/
- Imported from user-supplied USDZ for Theater Foundation TF1A.
