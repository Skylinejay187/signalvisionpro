# Theater Foundation TF1C — Orientation + Single-Screen Runtime Repair

Physical Vision Pro screenshots from TF1B showed two concrete runtime faults:

1. The purchased Fab auditorium was facing the wrong immersive direction, leaving the viewer looking into/through seating and ceiling structure rather than toward the architectural screen.
2. The bootstrap WindowGroup remained visible after the immersive space opened, creating a second floating screen even though the theater architecture is meant to have one and only one main screen.

TF1C repairs those faults without adding Signal UI or playback:

- rotates only the imported auditorium 180 degrees around Y, preserving Y-up;
- establishes a center/premium-row initial offset;
- immediately dismisses the bootstrap window after immersive-space open;
- makes the bootstrap surface transparent, plain, and 1x1 so it cannot become a second theater display;
- keeps auditorium scale fixed (screen controls no longer resize the entire room);
- adds controllable low-level house lighting so the purchased geometry is readable instead of nearly black;
- preserves the purchased model's `CinemaScreen` as the sole future Signal/Aether target;
- keeps TF1 free of Signal RootView, AVPlayer, VideoMaterial, and legacy SignalVisionTheater runtime presentation.

## Headset acceptance test

- Launch should transition directly into the immersive theater without a persistent floating "SIGNAL THEATER / Entering cinema" window.
- Viewer should face the architectural movie screen, not the back rows/ceiling.
- Theater should remain upright with floor below and ceiling above.
- Seats and architecture should be readable under low house lighting.
- Only the personal theater controller may float independently; there must be no second application/movie screen.
