#if os(visionOS)
import SwiftUI
import RealityKit
import UIKit

@MainActor
final class SignalTheaterFoundationState: ObservableObject {
    static let shared = SignalTheaterFoundationState()

    @Published var lighting: Float = 0.32
    @Published var screenScale: Float = 1.0
    @Published var screenHeight: Float = 0.0
    @Published var seatDepth: Float = 0.0
    @Published var seatHeight: Float = 0.55
    @Published var tabletX: Float = 0.72
    @Published var tabletY: Float = 0.02
    @Published var tabletZ: Float = -1.05
    @Published var tabletVisible = true

    func resetView() {
        lighting = 0.32
        screenScale = 1.0
        screenHeight = 0.0
        seatDepth = 0.0
        seatHeight = 0.55
    }

    func resetTablet() {
        tabletX = 0.72
        tabletY = 0.02
        tabletZ = -1.05
        persistTablet()
    }

    func loadTablet() {
        let d = UserDefaults.standard
        guard d.object(forKey: "tf1.tablet.x") != nil else { return }
        tabletX = d.float(forKey: "tf1.tablet.x")
        tabletY = d.float(forKey: "tf1.tablet.y")
        tabletZ = d.float(forKey: "tf1.tablet.z")
    }

    func persistTablet() {
        let d = UserDefaults.standard
        d.set(tabletX, forKey: "tf1.tablet.x")
        d.set(tabletY, forKey: "tf1.tablet.y")
        d.set(tabletZ, forKey: "tf1.tablet.z")
    }
}

struct SignalTheaterFoundationBootstrap: View {
    @Environment(\.openImmersiveSpace) private var openImmersiveSpace
    @Environment(\.dismissWindow) private var dismissWindow
    @State private var requested = false

    var body: some View {
        // This window exists only long enough to request the immersive space.
        // It must never become a second application/movie screen in the theater.
        Color.clear
            .frame(width: 1, height: 1)
            .task {
                guard !requested else { return }
                requested = true
                let result = await openImmersiveSpace(id: "signal-theater-foundation")
                if case .opened = result {
                    dismissWindow(id: "signal-main")
                }
            }
    }
}

struct SignalTheaterFoundationSpace: View {
    @StateObject private var state = SignalTheaterFoundationState.shared
    @State private var dragStartX: Float?
    @State private var dragStartY: Float?

    var body: some View {
        RealityView { content, attachments in
            let room = await TF1CinemaFactory.makeCinema()
            content.add(room)
            if let tablet = attachments.entity(for: "theater-tablet") {
                tablet.name = "TF1PersonalTablet"
                content.add(tablet)
            }
        } update: { content, attachments in
            if let room = content.entities.first(where: { $0.name == "TF1Cinema" }) {
                TF1CinemaFactory.update(room: room, state: state)
            }
            if let tablet = attachments.entity(for: "theater-tablet") {
                tablet.position = [state.tabletX, state.tabletY, state.tabletZ]
                tablet.isEnabled = state.tabletVisible
            }
        } attachments: {
            Attachment(id: "theater-tablet") {
                TF1TheaterTablet(state: state)
                    .frame(width: 620, height: 560)
                    .glassBackgroundEffect(in: RoundedRectangle(cornerRadius: 38))
                    .gesture(
                        DragGesture(minimumDistance: 0)
                            .onChanged { value in
                                if dragStartX == nil {
                                    dragStartX = state.tabletX
                                    dragStartY = state.tabletY
                                }
                                let sx = dragStartX ?? state.tabletX
                                let sy = dragStartY ?? state.tabletY
                                state.tabletX = sx + Float(value.translation.width) * 0.0015
                                state.tabletY = sy - Float(value.translation.height) * 0.0015
                            }
                            .onEnded { _ in
                                dragStartX = nil
                                dragStartY = nil
                                state.persistTablet()
                            }
                    )
            }
        }
        .onAppear { state.loadTablet() }
    }
}

private struct TF1TheaterTablet: View {
    @ObservedObject var state: SignalTheaterFoundationState
    @State private var section = "Room"

    var body: some View {
        VStack(spacing: 0) {
            HStack {
                VStack(alignment: .leading, spacing: 2) {
                    Text("SIGNAL").font(.system(size: 18, weight: .black))
                    Text("THEATER CONTROL").font(.caption).foregroundStyle(.secondary)
                }
                Spacer()
                Image(systemName: "move.3d").font(.title2)
                Text("Grab to move").font(.caption).foregroundStyle(.secondary)
            }
            .padding(24)

            Divider()

            HStack(alignment: .top, spacing: 0) {
                VStack(spacing: 10) {
                    TF1Tab("Room", icon: "theatermasks", selected: $section)
                    TF1Tab("Seat", icon: "chair.lounge", selected: $section)
                    TF1Tab("Screen", icon: "rectangle.inset.filled", selected: $section)
                    TF1Tab("Lighting", icon: "lightbulb", selected: $section)
                    Spacer()
                }
                .frame(width: 155)
                .padding(14)

                Divider()

                ScrollView {
                    VStack(alignment: .leading, spacing: 20) {
                        Text(section).font(.title2.bold())
                        if section == "Room" {
                            LabeledContent("Environment", value: "Classic Cinema")
                            Text("TF1 is a clean theater foundation. Signal UI and playback are intentionally not loaded.")
                                .font(.callout).foregroundStyle(.secondary)
                            Button("Reset Theater") { state.resetView() }
                                .buttonStyle(.borderedProminent)
                        } else if section == "Seat" {
                            TF1Slider(title: "Seat forward / back", value: $state.seatDepth, range: -1.2...1.2)
                            TF1Slider(title: "Seat height", value: $state.seatHeight, range: 0.0...1.2)
                            Button("Center Seat") { state.seatDepth = 0; state.seatHeight = 0.55 }
                        } else if section == "Screen" {
                            TF1Slider(title: "Screen size", value: $state.screenScale, range: 0.78...1.22)
                            TF1Slider(title: "Screen height", value: $state.screenHeight, range: -0.65...0.65)
                        } else {
                            TF1Slider(title: "House lights", value: $state.lighting, range: 0.08...1.0)
                        }

                        Divider()
                        Text("Tablet Position").font(.headline)
                        TF1Slider(title: "Distance", value: $state.tabletZ, range: -1.8 ... -0.65)
                        Button("Reset Tablet Position") { state.resetTablet() }
                    }
                    .padding(24)
                }
            }
        }
        .background(.black.opacity(0.22))
    }
}

private struct TF1Tab: View {
    let title: String
    let icon: String
    @Binding var selected: String
    init(_ title: String, icon: String, selected: Binding<String>) {
        self.title = title; self.icon = icon; self._selected = selected
    }
    var body: some View {
        Button { selected = title } label: {
            HStack { Image(systemName: icon); Text(title); Spacer() }
                .frame(maxWidth: .infinity)
        }
        .buttonStyle(.bordered)
        .tint(selected == title ? .primary : .secondary)
    }
}

private struct TF1Slider: View {
    let title: String
    @Binding var value: Float
    let range: ClosedRange<Float>
    var body: some View {
        VStack(alignment: .leading, spacing: 8) {
            HStack { Text(title); Spacer(); Text(String(format: "%.2f", value)).monospacedDigit().foregroundStyle(.secondary) }
            Slider(value: $value, in: range)
        }
    }
}

@MainActor
private enum TF1CinemaFactory {
    // TF1B uses the purchased Fab theater as the room itself. Nothing from the old
    // Signal theater implementation is instantiated here.
    static func makeCinema() async -> Entity {
        let root = Entity(); root.name = "TF1Cinema"

        guard let imported = loadFabCinema() else {
            let marker = ModelEntity(
                mesh: .generateBox(size: [3.6, 1.8, 0.08]),
                materials: [SimpleMaterial(color: .init(red: 0.35, green: 0.02, blue: 0.02, alpha: 1), isMetallic: false)]
            )
            marker.name = "TF1FabAssetLoadFailure"
            marker.position = [0, 0.25, -4.0]
            root.addChild(marker)
            return root
        }

        imported.name = "FabMovieTheaterEnvironment"
        // The source auditorium is roughly 33 x 37 x 15 model units. At 0.25 scale
        // that becomes an ~8.3m x 9.1m room with a ~4.7m-wide architectural screen.
        // The source origin is intentionally kept near the premium/front-middle seat
        // and its screen is authored at negative depth.
        imported.scale = [0.25, 0.25, 0.25]
        // Fab's converted USDZ faces the opposite direction from visionOS' default
        // immersive forward axis. Rotate the auditorium around Y only (keep Y-up),
        // then offset to a center-aisle / premium-row seated viewpoint.
        imported.orientation = simd_quatf(angle: .pi, axis: [0, 1, 0])
        imported.position = [0, -1.57, -0.65]
        root.addChild(imported)

        addHouseLights(to: root)

        // Restyle only the seat hierarchy. This leaves the purchased architecture,
        // screen, curtain, speakers and wall materials intact.
        if let seats = findEntity(namedLike: "seats", under: imported) {
            applyBlackSeatMaterial(to: seats)
        }

        // These are semantic anchors, not additional screens. TF2 will bind Signal to
        // the purchased model's screen mesh; TF3 will switch that SAME target to Aether.
        if let sourceScreen = findEntity(namedLike: "screen", under: imported) {
            sourceScreen.name = "CinemaScreen"
        }

        // Poster anchors are empty in TF1B. Later builds can populate them dynamically
        // with authorized Signal catalog artwork without baking copyrighted posters.
        let posterLeft = Entity(); posterLeft.name = "SignalPosterAnchorLeft"; posterLeft.position = [-3.55, 0.25, -1.2]
        let posterRight = Entity(); posterRight.name = "SignalPosterAnchorRight"; posterRight.position = [3.55, 0.25, -1.2]
        root.addChild(posterLeft); root.addChild(posterRight)

        return root
    }

    static func update(room: Entity, state: SignalTheaterFoundationState) {
        guard let environment = room.findEntity(named: "FabMovieTheaterEnvironment") else { return }

        // Never resize or vertically move the whole theater from a screen control.
        // The auditorium is a fixed world. TF2 will bind these controls only to the
        // single CinemaScreen surface.
        environment.scale = [0.25, 0.25, 0.25]
        environment.orientation = simd_quatf(angle: .pi, axis: [0, 1, 0])
        environment.position = [0, -1.02 - state.seatHeight, -0.65]

        // The imported model has actual seat-back geometry around the old spawn depth.
        // Keep the neutral viewer point in the open space immediately in front of a row,
        // then move the auditorium for user-selected fore/aft seating. Seat height moves
        // the auditorium down relative to the viewer, which raises the viewer above the
        // seat/floor geometry without tilting or scaling the room.
        room.position.z = state.seatDepth
        updateHouseLights(in: room, level: state.lighting)
    }

    private static func addHouseLights(to parent: Entity) {
        let specs: [(String, SIMD3<Float>, UIColor, Float, Float)] = [
            ("TF1HouseLightFront", [0, 1.45, -4.6], UIColor(red: 0.72, green: 0.78, blue: 0.88, alpha: 1), 1450, 7.5),
            ("TF1HouseLightLeft", [-2.9, 1.15, -1.2], UIColor(red: 1.0, green: 0.58, blue: 0.30, alpha: 1), 1100, 6.0),
            ("TF1HouseLightRight", [2.9, 1.15, -1.2], UIColor(red: 1.0, green: 0.58, blue: 0.30, alpha: 1), 1100, 6.0),
            ("TF1HouseLightRear", [0, 1.55, 2.2], UIColor(red: 0.68, green: 0.72, blue: 0.80, alpha: 1), 700, 5.5)
        ]
        for (name, position, color, intensity, radius) in specs {
            let light = Entity()
            light.name = name
            light.position = position
            light.components.set(PointLightComponent(
                color: color,
                intensity: intensity,
                attenuationRadius: radius,
                attenuationFalloffExponent: 2.0
            ))
            parent.addChild(light)
        }
    }

    private static func updateHouseLights(in root: Entity, level: Float) {
        let clamped = max(0.08, min(1.0, level))
        let specs: [(String, UIColor, Float, Float)] = [
            ("TF1HouseLightFront", UIColor(red: 0.72, green: 0.78, blue: 0.88, alpha: 1), 1450, 7.5),
            ("TF1HouseLightLeft", UIColor(red: 1.0, green: 0.58, blue: 0.30, alpha: 1), 1100, 6.0),
            ("TF1HouseLightRight", UIColor(red: 1.0, green: 0.58, blue: 0.30, alpha: 1), 1100, 6.0),
            ("TF1HouseLightRear", UIColor(red: 0.68, green: 0.72, blue: 0.80, alpha: 1), 700, 5.5)
        ]
        for (name, color, baseIntensity, radius) in specs {
            guard let light = root.findEntity(named: name) else { continue }
            light.components.set(PointLightComponent(
                color: color,
                intensity: baseIntensity * clamped,
                attenuationRadius: radius,
                attenuationFalloffExponent: 2.0
            ))
        }
    }

    private static func loadFabCinema() -> Entity? {
        let candidates = [
            "SignalFabMovieTheater",
            "SignalFabMovieTheater.usdz",
            "Cinema/SignalFabMovieTheater",
            "Cinema/SignalFabMovieTheater.usdz"
        ]
        for candidate in candidates {
            if let entity = try? Entity.load(named: candidate, in: .main) { return entity }
        }
        return nil
    }

    private static func findEntity(namedLike needle: String, under entity: Entity) -> Entity? {
        if entity.name.localizedCaseInsensitiveContains(needle) { return entity }
        for child in entity.children {
            if let match = findEntity(namedLike: needle, under: child) { return match }
        }
        return nil
    }

    private static func applyBlackSeatMaterial(to entity: Entity) {
        if let model = entity as? ModelEntity, var component = model.model {
            let count = max(1, component.materials.count)
            let charcoal = SimpleMaterial(
                color: .init(red: 0.025, green: 0.027, blue: 0.030, alpha: 1),
                roughness: 0.72,
                isMetallic: false
            )
            component.materials = Array(repeating: charcoal, count: count)
            model.model = component
        }
        for child in entity.children { applyBlackSeatMaterial(to: child) }
    }
}

#endif // os(visionOS)
