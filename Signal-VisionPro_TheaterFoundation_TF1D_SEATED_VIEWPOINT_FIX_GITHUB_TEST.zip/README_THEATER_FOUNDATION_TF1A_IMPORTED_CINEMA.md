# Signal Vision Pro — Theater Foundation TF1A

TF1A replaces TF1's procedural box-built cinema with the user-supplied `cinema/movie theater_[interior]` USDZ.

## Asset / license
- Author: yuuuusukeeee (Comicaroid)
- Source: https://sketchfab.com/3d-models/cinemamovie-theater-interior-dcaf6cdebcad4f03879c24186da257ee
- License: CC BY 4.0; commercial use permitted with attribution.
- The attribution above must remain with any distributed build using this environment.

## Architecture locks
- The imported theater is the immersive foundation, not a floating Signal dashboard.
- No RootView is mounted in the theater.
- No AVPlayer, VideoMaterial, Aether playback surface, or second cinema screen is added by TF1A.
- `CinemaScreen` is one logical anchor reserved for TF2/TF3.
- Theater controls remain a separate personal spatial control surface.

## Physical test
1. Launch and enter immersive theater automatically.
2. Confirm the imported theater geometry, seats, floor and ceiling are visible at believable scale.
3. Confirm there is no floating Signal dashboard.
4. Confirm only the theater's architectural screen is visually present.
5. Confirm the personal theater control panel can be moved and controls can be interacted with.
6. Report orientation/scale/seat position issues from the headset; those are expected tuning targets for TF1B.
