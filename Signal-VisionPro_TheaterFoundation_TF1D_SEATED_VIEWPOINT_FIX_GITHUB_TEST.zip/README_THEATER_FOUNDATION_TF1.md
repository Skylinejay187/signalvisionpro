# Signal Vision Pro — Theater Foundation TF1

TF1 deliberately starts the immersive product foundation over from Build 38B infrastructure.

## Physical headset acceptance test
1. Launch Signal; it should request the new `signal-theater-foundation` immersive space.
2. You should be seated inside a furnished Classic Cinema, not in the legacy Signal theater.
3. There is exactly one architectural cinema screen. It is blank by design in TF1.
4. There is no Signal RootView/dashboard, Media Information, Aether, AVPlayer, VideoMaterial, or legacy playback HUD in the immersive scene.
5. A personal Theater Control tablet appears near the viewer.
6. Drag the tablet to reposition it in X/Y; use Distance for Z. Its position persists.
7. Room controls adjust seat depth, screen scale/height and house-light brightness.
8. Reset Theater and Reset Tablet Position restore defaults.

## Next phases
- TF2: render Signal application UI on the one architectural cinema screen.
- TF3: switch that exact same screen from Signal UI to Aether playback.

Physical Vision Pro testing is authoritative. Compile/static checks do not prove runtime appearance or comfort.
