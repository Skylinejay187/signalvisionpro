# Signal Vision Pro — Theater Foundation TF1B (Purchased Fab Cinema)

TF1B replaces the temporary Sketchfab environment with the purchased Fab movie-theater asset supplied by the project owner.

## Foundation locks
- The Fab theater is the immersive world itself; no procedural theater shell is rendered.
- No Signal RootView/dashboard is mounted in the immersive room.
- The purchased architectural screen is renamed `CinemaScreen` and is the single future application/playback target.
- No AVPlayer, VideoMaterial, Aether renderer, or second visual screen is introduced in TF1B.
- Seats are restyled to black/charcoal at runtime without altering the source geometry.
- Two empty poster anchors are reserved for later dynamic Signal artwork; TF1B does not bake movie posters into the asset.
- The personal theater controller remains separate from the cinema screen and its transform persists.

## Source geometry calibration
The supplied glTF reports an auditorium envelope of about 33.3 x 36.6 x 15 model units and a screen about 18.94 x 8.30 units. TF1B starts at 0.25 world scale, producing an approximately 4.7m-wide screen and 8–9m auditorium footprint. Physical Vision Pro testing remains authoritative for final scale/orientation.

## Physical test
1. Launch; enter the immersive cinema automatically.
2. Confirm the purchased Fab theater appears, with seats, walls, curtain/speakers and architectural screen.
3. Confirm seats appear black/charcoal.
4. Confirm there is no Signal dashboard or second screen.
5. Confirm the theater-control tablet is usable and can be repositioned.
6. Capture front, left/right and rear views so scale/orientation and the initial premium-seat position can be tuned from headset evidence.

## Asset handling
The purchased asset is application content. Do not publish/extract/redistribute its original source packages as standalone assets. See `Resources/Cinema/FAB_LICENSE_NOTE.md`.
