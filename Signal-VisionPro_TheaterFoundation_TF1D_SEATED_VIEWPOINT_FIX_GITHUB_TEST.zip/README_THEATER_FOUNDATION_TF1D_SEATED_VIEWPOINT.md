# Theater Foundation TF1D — Seated Viewpoint Repair

Physical TF1C headset screenshots proved the viewer was intersecting / sitting below the imported seat row.

TF1D changes only the theater foundation placement and seat controls:
- keeps the Fab auditorium upright and facing its architectural screen
- moves the neutral spawn out of the seat-back depth band
- raises the viewer relative to the auditorium by lowering the room 0.55 m
- adds a real Seat height control (0.0–1.2 m)
- Center Seat restores the tested neutral height and fore/aft position
- keeps the bootstrap window dismissed; no second application screen
- does not add Signal UI or playback

The headset result remains authoritative.
