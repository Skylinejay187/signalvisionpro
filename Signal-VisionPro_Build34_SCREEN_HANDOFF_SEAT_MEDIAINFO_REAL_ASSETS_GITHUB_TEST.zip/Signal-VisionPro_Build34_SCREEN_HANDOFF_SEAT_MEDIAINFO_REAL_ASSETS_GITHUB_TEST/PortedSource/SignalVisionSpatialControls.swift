import SwiftUI

/// Build 22 native controls. The original Unity Live TV, catalog and detail
/// visuals stay mounted in RootView; only the active surface is interactive.
/// This is a same-window focus-layer foundation, NOT a claim that visionOS
/// supports non-movable, perfectly coincident independent system windows.
struct SignalVisionSpatialControls: View {
    @EnvironmentObject private var store: CatalogStore
    @EnvironmentObject private var unityCore: UnityAppCore
    @EnvironmentObject private var theater: SignalVisionTheaterCoordinator
    @Environment(\.openImmersiveSpace) private var openImmersiveSpace
    @Environment(\.dismissImmersiveSpace) private var dismissImmersiveSpace
    @AppStorage("signalVisionPersistentTheaterV22") private var persistentTheater = true
    @AppStorage("signalVisionCinemaEnvironmentV28") private var cinemaEnvironment = "Classic Cinema"
    @AppStorage("signalVisionCinemaSeatRowV31") private var cinemaSeatRow = "Middle"
    @AppStorage("signalVisionCinemaSeatPositionV31") private var cinemaSeatPosition = "Center"
    @AppStorage("signalVisionCinemaSeatHeightV31") private var cinemaSeatHeight: Double = 0.0
    @State private var preferencesVisible = false
    @State private var diagnosticsVisible = false
    private let diagnostics = SignalVisionDiagnostics.shared

    private var playbackActive: Bool { store.playbackURL != nil }
    private var detailActive: Bool { store.selectedDetail != nil }
    private var canGoBack: Bool {
        playbackActive || detailActive || store.searchActive || store.liveQuickPanelOpen || store.selectedTab != .live
    }

    var body: some View {
        Group {
            // A window ornament lives OUTSIDE the fixed-size Signal canvas.
            // It never obscures Guide, footer chips, navigation, or the player.
            if !playbackActive {
                HStack(spacing: 12) {
                    if canGoBack {
                        Button(action: goBack) {
                            Label("Back", systemImage: "chevron.backward")
                                .frame(minHeight: 44)
                        }
                        .accessibilityLabel("Back one Signal layer")
                    }
                    Button {
                        preferencesVisible = true
                    } label: {
                        Label("Vision Pro / Theater", systemImage: "theatermasks")
                            .frame(minHeight: 44)
                    }
                    .accessibilityLabel("Vision Pro theater settings")
                }
                .buttonStyle(.bordered)
                .padding(10)
                .background(.ultraThinMaterial, in: Capsule())
            }
        }
        .sheet(isPresented: $diagnosticsVisible) { SignalVisionDiagnosticsPanel() }
        .sheet(isPresented: $preferencesVisible) {
            VStack(alignment: .leading, spacing: 22) {
                Text("Signal · Vision Pro")
                    .font(.title2.bold())
                Text("The original Signal design and player remain unchanged. Theater entry is requested through visionOS.")
                    .font(.subheadline)
                    .foregroundStyle(.secondary)
                Picker("Theater environment", selection: $cinemaEnvironment) {
                    Text("Classic Cinema").tag("Classic Cinema")
                    Text("Home Theater").tag("Home Theater")
                    Text("Drive-In").tag("Drive-In")
                    Text("Grand Theater").tag("Grand Theater")
                }
                .pickerStyle(.menu)
                Text("The last selected environment is remembered for your next visit.")
                    .font(.caption)
                    .foregroundStyle(.secondary)

                Divider()
                Text("Viewing Seat")
                    .font(.headline)
                Picker("Row", selection: $cinemaSeatRow) {
                    Text("Front").tag("Front")
                    Text("Middle").tag("Middle")
                    Text("Back").tag("Back")
                }
                .pickerStyle(.segmented)
                Picker("Seat", selection: $cinemaSeatPosition) {
                    Text("Left").tag("Left")
                    Text("Center").tag("Center")
                    Text("Right").tag("Right")
                }
                .pickerStyle(.segmented)
                VStack(alignment: .leading, spacing: 8) {
                    Text("Seat height: \(Int((cinemaSeatHeight * 100).rounded())) cm")
                        .font(.subheadline)
                    Slider(value: $cinemaSeatHeight, in: -0.20...0.20, step: 0.02)
                }
                Text("Signal builds the environment around this physical viewing seat. Changes apply the next time the theater opens.")
                    .font(.caption)
                    .foregroundStyle(.secondary)

                Toggle("Stay in Theater", isOn: $persistentTheater)
                    .toggleStyle(.switch)
                Text(persistentTheater
                     ? "Cinema stays open until you explicitly exit it."
                     : "Cinema closes when playback ends.")
                    .font(.caption)
                    .foregroundStyle(.secondary)
                Button("Cinema Diagnostics / Export", systemImage: "doc.text.magnifyingglass") {
                    preferencesVisible = false
                    diagnosticsVisible = true
                }
                .buttonStyle(.bordered)
                if let error = theater.entryFailure {
                    Text(error).foregroundStyle(.orange)
                        .accessibilityLabel("Theater error: \(error)")
                }
                Button("Enter Selected Theater", systemImage: "theatermasks.fill") {
                    preferencesVisible = false
                    requestTheater()
                }
                .buttonStyle(.borderedProminent)
                .disabled(theater.transitionInProgress)
                if theater.immersiveActive {
                    Button("Exit Theater", systemImage: "xmark") {
                        preferencesVisible = false
                        Task { @MainActor in
                            await dismissImmersiveSpace()
                            theater.immersiveActive = false
                            diagnostics.record("entry", "manual theater exit completed")
                        }
                    }
                    .buttonStyle(.bordered)
                }
                Button("Close Settings") { preferencesVisible = false }
                    .buttonStyle(.bordered)
            }
            .padding(30)
            .frame(width: 510)
        }
    }

    private func goBack() {
        if playbackActive { store.closePlayer(); return }
        if detailActive {
            if let previous = store.detailBackStack.popLast() {
                store.selectedDetail = previous
            } else {
                store.selectedDetail = nil
            }
            return
        }
        if store.searchActive { store.searchActive = false; return }
        if store.liveQuickPanelOpen { store.liveQuickPanelOpen = false; return }
        if store.selectedTab != .live {
            unityCore.select(.live, store: store, reason: "visionOS spatial layer unwind")
            return
        }
        NotificationCenter.default.post(name: SignalVisionRemoteEvent.back, object: nil)
    }

    private func requestTheater() {
        guard !theater.transitionInProgress else {
            diagnostics.record("entry", "duplicate request ignored: transition in progress")
            return
        }
        Task { @MainActor in
            theater.transitionInProgress = true
            diagnostics.sceneSnapshot("before-manual-entry")
            defer { theater.transitionInProgress = false }
            theater.entryFailure = nil
            if theater.immersiveActive {
                diagnostics.record("entry", "already-active request ignored")
                return
            }
            theater.mode = persistentTheater ? .app : (playbackActive ? .playback : .app)
            // Do not request the immersive scene during the sheet dismissal animation.
            // The controls/ornament view remains mounted after the sheet disappears.
            try? await Task.sleep(nanoseconds: 350_000_000)
            diagnostics.record("entry", "requesting signal-theater mode=\(theater.mode.rawValue)")
            switch await openImmersiveSpace(id: "signal-theater") {
            case .opened:
                theater.immersiveActive = true
                diagnostics.record("entry", "openImmersiveSpace returned opened")
                diagnostics.sceneSnapshot("entry-opened")
            case .userCancelled:
                theater.entryFailure = "Theater entry was cancelled. Choose Enter Classic Cinema to retry."
                diagnostics.record("entry", "openImmersiveSpace returned userCancelled")
            case .error:
                // .error does NOT prove any headset permission was denied.
                theater.entryFailure = "Classic Cinema could not open. The system returned an entry error; no permission denial was confirmed. Exit another immersive app if one is open and retry. Open Cinema Diagnostics and export the report."
                diagnostics.record("entry", "openImmersiveSpace returned error; reason not available through this API")
                diagnostics.sceneSnapshot("entry-error")
            @unknown default:
                theater.entryFailure = "Theater entry returned an unknown result; check device logs."
                diagnostics.record("entry", "openImmersiveSpace returned unknown result")
            }
        }
    }
}

/// Build 23: ONLY shown when the original Unity catalog owns the canvas.
/// Calls its existing rail-selection logic directly through the active rail,
/// rather than forwarding to the tvOS focus engine or the removed virtual remote.
struct SignalVisionCatalogArrows: View {
    let availableSize: CGSize
    @AppStorage("signalVisionCatalogPalettePositionV26") private var locationIndex = 0
    @AppStorage("signalVisionCatalogPaletteOffsetX") private var savedX: Double = 0
    @AppStorage("signalVisionCatalogPaletteOffsetY") private var savedY: Double = 0
    @GestureState private var gestureOffset: CGSize = .zero

    private func arrow(_ symbol: String, _ label: String, _ direction: SignalMoveDirection) -> some View {
        Button {
            NotificationCenter.default.post(name: SignalVisionRemoteEvent.catalogDirection, object: direction)
        } label: {
            Image(systemName: symbol)
                .font(.system(size: 18, weight: .bold))
                .frame(width: 46, height: 46)
        }
        .buttonStyle(.bordered)
        .hoverEffect(.highlight)
        .accessibilityLabel(label)
    }

    private func cyclePosition() {
        locationIndex = (locationIndex + 1) % 4
        let horizontal = max(0, availableSize.width - 230)
        let vertical = max(0, availableSize.height * 0.27)
        switch locationIndex {
        case 1: savedX = Double(horizontal); savedY = 0
        case 2: savedX = Double(horizontal); savedY = Double(-vertical)
        case 3: savedX = 0; savedY = Double(-vertical)
        default: savedX = 0; savedY = 0
        }
    }

    private var repositionGesture: some Gesture {
        DragGesture(minimumDistance: 0)
            .updating($gestureOffset) { value, state, _ in state = value.translation }
            .onEnded { value in
                let x = CGFloat(savedX) + value.translation.width
                let y = CGFloat(savedY) + value.translation.height
                // The palette starts near the left gutter. Keep the grab handle in view.
                savedX = Double(min(max(-4, x), max(0, availableSize.width - 175)))
                savedY = Double(min(max(-availableSize.height * 0.55, y), availableSize.height * 0.38))
            }
    }

    var body: some View {
        VStack(spacing: 6) {
            HStack(spacing: 6) {
                Image(systemName: "hand.draw.fill")
                Button("Move") { cyclePosition() }
                    .buttonStyle(.bordered)
                    .accessibilityLabel("Move catalog controls to another screen corner")
            }
                .font(.system(size: 16, weight: .medium))
                .frame(width: 146, height: 56)
                .contentShape(Rectangle())
                .simultaneousGesture(repositionGesture)
                .accessibilityLabel("Drag or choose Move to reposition catalog controls")
            arrow("chevron.up", "Previous catalog row", .up)
            HStack(spacing: 6) {
                arrow("chevron.left", "Previous poster", .left)
                arrow("chevron.right", "Next poster", .right)
            }
            arrow("chevron.down", "Next catalog row", .down)
        }
        .padding(8)
        .background(Color.black.opacity(0.08), in: RoundedRectangle(cornerRadius: 22))
        .offset(CGSize(width: CGFloat(savedX) + gestureOffset.width,
                       height: CGFloat(savedY) + gestureOffset.height))
        .accessibilityLabel("Movable catalog navigation")
    }
}
