#if os(visionOS)
import SwiftUI
import RealityKit
import UIKit

@MainActor
final class SignalTheaterFoundationState: ObservableObject {
    static let shared = SignalTheaterFoundationState()

    @Published var lighting: Float = 0.42
    @Published var screenScale: Float = 1.0
    @Published var screenHeight: Float = 0.0
    @Published var seatDepth: Float = 0.0
    @Published var tabletX: Float = 0.72
    @Published var tabletY: Float = 0.02
    @Published var tabletZ: Float = -1.05
    @Published var tabletVisible = true

    func resetView() {
        lighting = 0.42
        screenScale = 1.0
        screenHeight = 0.0
        seatDepth = 0.0
    }

    func resetTablet() {
        tabletX = 0.72
        tabletY = 0.02
        tabletZ = -1.05
        persistTablet()
    }

    func loadTablet() {
        let d = UserDefaults.standard
        guard d.object(forKey: "tf1.tablet.x") != nil else { return }
        tabletX = d.float(forKey: "tf1.tablet.x")
        tabletY = d.float(forKey: "tf1.tablet.y")
        tabletZ = d.float(forKey: "tf1.tablet.z")
    }

    func persistTablet() {
        let d = UserDefaults.standard
        d.set(tabletX, forKey: "tf1.tablet.x")
        d.set(tabletY, forKey: "tf1.tablet.y")
        d.set(tabletZ, forKey: "tf1.tablet.z")
    }
}

struct SignalTheaterFoundationBootstrap: View {
    @Environment(\.openImmersiveSpace) private var openImmersiveSpace
    @State private var requested = false

    var body: some View {
        ZStack {
            Color.black.ignoresSafeArea()
            VStack(spacing: 16) {
                Text("SIGNAL THEATER")
                    .font(.system(size: 42, weight: .black, design: .rounded))
                Text("Entering cinema…")
                    .foregroundStyle(.secondary)
            }
        }
        .task {
            guard !requested else { return }
            requested = true
            _ = await openImmersiveSpace(id: "signal-theater-foundation")
        }
    }
}

struct SignalTheaterFoundationSpace: View {
    @StateObject private var state = SignalTheaterFoundationState.shared
    @State private var dragStartX: Float?
    @State private var dragStartY: Float?

    var body: some View {
        RealityView { content, attachments in
            let room = TF1CinemaFactory.makeCinema()
            content.add(room)
            if let tablet = attachments.entity(for: "theater-tablet") {
                tablet.name = "TF1PersonalTablet"
                content.add(tablet)
            }
        } update: { content, attachments in
            if let room = content.entities.first(where: { $0.name == "TF1Cinema" }) {
                TF1CinemaFactory.update(room: room, state: state)
            }
            if let tablet = attachments.entity(for: "theater-tablet") {
                tablet.position = [state.tabletX, state.tabletY, state.tabletZ]
                tablet.isEnabled = state.tabletVisible
            }
        } attachments: {
            Attachment(id: "theater-tablet") {
                TF1TheaterTablet(state: state)
                    .frame(width: 620, height: 560)
                    .glassBackgroundEffect(in: RoundedRectangle(cornerRadius: 38))
                    .gesture(
                        DragGesture(minimumDistance: 0)
                            .onChanged { value in
                                if dragStartX == nil {
                                    dragStartX = state.tabletX
                                    dragStartY = state.tabletY
                                }
                                let sx = dragStartX ?? state.tabletX
                                let sy = dragStartY ?? state.tabletY
                                state.tabletX = sx + Float(value.translation.width) * 0.0015
                                state.tabletY = sy - Float(value.translation.height) * 0.0015
                            }
                            .onEnded { _ in
                                dragStartX = nil
                                dragStartY = nil
                                state.persistTablet()
                            }
                    )
            }
        }
        .onAppear { state.loadTablet() }
    }
}

private struct TF1TheaterTablet: View {
    @ObservedObject var state: SignalTheaterFoundationState
    @State private var section = "Room"

    var body: some View {
        VStack(spacing: 0) {
            HStack {
                VStack(alignment: .leading, spacing: 2) {
                    Text("SIGNAL").font(.system(size: 18, weight: .black))
                    Text("THEATER CONTROL").font(.caption).foregroundStyle(.secondary)
                }
                Spacer()
                Image(systemName: "move.3d").font(.title2)
                Text("Grab to move").font(.caption).foregroundStyle(.secondary)
            }
            .padding(24)

            Divider()

            HStack(alignment: .top, spacing: 0) {
                VStack(spacing: 10) {
                    TF1Tab("Room", icon: "theatermasks", selected: $section)
                    TF1Tab("Seat", icon: "chair.lounge", selected: $section)
                    TF1Tab("Screen", icon: "rectangle.inset.filled", selected: $section)
                    TF1Tab("Lighting", icon: "lightbulb", selected: $section)
                    Spacer()
                }
                .frame(width: 155)
                .padding(14)

                Divider()

                ScrollView {
                    VStack(alignment: .leading, spacing: 20) {
                        Text(section).font(.title2.bold())
                        if section == "Room" {
                            LabeledContent("Environment", value: "Classic Cinema")
                            Text("TF1 is a clean theater foundation. Signal UI and playback are intentionally not loaded.")
                                .font(.callout).foregroundStyle(.secondary)
                            Button("Reset Theater") { state.resetView() }
                                .buttonStyle(.borderedProminent)
                        } else if section == "Seat" {
                            TF1Slider(title: "Seat position", value: $state.seatDepth, range: -1.2...1.2)
                            Button("Center Seat") { state.seatDepth = 0 }
                        } else if section == "Screen" {
                            TF1Slider(title: "Screen size", value: $state.screenScale, range: 0.78...1.22)
                            TF1Slider(title: "Screen height", value: $state.screenHeight, range: -0.65...0.65)
                        } else {
                            TF1Slider(title: "House lights", value: $state.lighting, range: 0.08...1.0)
                        }

                        Divider()
                        Text("Tablet Position").font(.headline)
                        TF1Slider(title: "Distance", value: $state.tabletZ, range: -1.8 ... -0.65)
                        Button("Reset Tablet Position") { state.resetTablet() }
                    }
                    .padding(24)
                }
            }
        }
        .background(.black.opacity(0.22))
    }
}

private struct TF1Tab: View {
    let title: String
    let icon: String
    @Binding var selected: String
    init(_ title: String, icon: String, selected: Binding<String>) {
        self.title = title; self.icon = icon; self._selected = selected
    }
    var body: some View {
        Button { selected = title } label: {
            HStack { Image(systemName: icon); Text(title); Spacer() }
                .frame(maxWidth: .infinity)
        }
        .buttonStyle(.bordered)
        .tint(selected == title ? .primary : .secondary)
    }
}

private struct TF1Slider: View {
    let title: String
    @Binding var value: Float
    let range: ClosedRange<Float>
    var body: some View {
        VStack(alignment: .leading, spacing: 8) {
            HStack { Text(title); Spacer(); Text(String(format: "%.2f", value)).monospacedDigit().foregroundStyle(.secondary) }
            Slider(value: $value, in: range)
        }
    }
}

@MainActor
private enum TF1CinemaFactory {
    static func makeCinema() -> Entity {
        let root = Entity(); root.name = "TF1Cinema"

        // Room shell: charcoal rather than absolute black so architecture remains readable.
        addBox(to: root, name: "Floor", size: [15, 0.12, 20], position: [0, -1.65, -6.5], color: .init(white: 0.035, alpha: 1))
        addBox(to: root, name: "Ceiling", size: [15, 0.12, 20], position: [0, 5.4, -6.5], color: .init(white: 0.025, alpha: 1))
        addBox(to: root, name: "LeftWall", size: [0.15, 7, 20], position: [-7.45, 1.85, -6.5], color: .init(red: 0.075, green: 0.055, blue: 0.06, alpha: 1))
        addBox(to: root, name: "RightWall", size: [0.15, 7, 20], position: [7.45, 1.85, -6.5], color: .init(red: 0.075, green: 0.055, blue: 0.06, alpha: 1))
        addBox(to: root, name: "FrontWall", size: [15, 7, 0.15], position: [0, 1.85, -16.45], color: .init(white: 0.025, alpha: 1))

        // Stage and single architectural screen. This is the ONLY content screen in TF1.
        addBox(to: root, name: "Stage", size: [11.8, 0.35, 2.0], position: [0, -1.42, -14.65], color: .init(red: 0.09, green: 0.025, blue: 0.03, alpha: 1))
        addBox(to: root, name: "ScreenFrame", size: [11.9, 5.35, 0.18], position: [0, 1.45, -16.18], color: .black)
        addBox(to: root, name: "CinemaScreen", size: [11.25, 4.7, 0.08], position: [0, 1.45, -16.06], color: .init(white: 0.32, alpha: 1))

        // Acoustic wall panels + sconces.
        for side: Float in [-1, 1] {
            for row in 0..<5 {
                let z = -3.5 - Float(row) * 2.35
                addBox(to: root, name: "AcousticPanel", size: [0.22, 2.35, 1.55], position: [side * 7.22, 1.15, z], color: .init(red: 0.13, green: 0.045, blue: 0.05, alpha: 1))
                addBox(to: root, name: "Sconce", size: [0.26, 0.45, 0.18], position: [side * 7.10, 2.65, z], color: .init(red: 0.95, green: 0.48, blue: 0.14, alpha: 1), emissive: true)
            }
        }

        // Raked seating: viewer starts around the premium middle row with visible rows ahead and behind.
        for row in 0..<6 {
            let z = -3.0 - Float(row) * 1.55
            let y = -1.25 + Float(row) * 0.16
            addBox(to: root, name: "Riser", size: [12.0, 0.18, 1.45], position: [0, y - 0.42, z], color: .init(white: 0.055, alpha: 1))
            for col in -4...4 where col != 0 {
                addSeat(to: root, x: Float(col) * 1.18, y: y, z: z)
            }
            // Center pair leaves a subtle central aisle/view corridor.
            addSeat(to: root, x: -0.68, y: y, z: z)
            addSeat(to: root, x: 0.68, y: y, z: z)
        }

        // Aisle marker lights.
        for i in 0..<11 {
            let z = -1.8 - Float(i) * 1.25
            for x: Float in [-6.1, 6.1] {
                addBox(to: root, name: "AisleLight", size: [0.14, 0.08, 0.32], position: [x, -1.42, z], color: .init(red: 1.0, green: 0.28, blue: 0.05, alpha: 1), emissive: true)
            }
        }

        // Ceiling coves add readable depth without flooding the room.
        for z: Float in [-3.5, -7.0, -10.5, -14.0] {
            addBox(to: root, name: "CeilingCove", size: [10.8, 0.08, 0.16], position: [0, 5.20, z], color: .init(red: 0.65, green: 0.18, blue: 0.06, alpha: 1), emissive: true)
        }

        return root
    }

    static func update(room: Entity, state: SignalTheaterFoundationState) {
        if let screen = room.findEntity(named: "CinemaScreen") {
            screen.scale = [state.screenScale, state.screenScale, 1]
            screen.position.y = 1.45 + state.screenHeight
        }
        if let frame = room.findEntity(named: "ScreenFrame") {
            frame.scale = [state.screenScale, state.screenScale, 1]
            frame.position.y = 1.45 + state.screenHeight
        }
        // Move the environment relative to the stationary viewer to emulate seat depth.
        room.position.z = state.seatDepth

        let brightness = max(0.05, min(1.0, state.lighting))
        room.forEachDescendant { entity in
            guard entity.name == "Sconce" || entity.name == "CeilingCove" || entity.name == "AisleLight" else { return }
            entity.components.set(OpacityComponent(opacity: brightness))
        }
    }

    private static func addSeat(to root: Entity, x: Float, y: Float, z: Float) {
        let seat = Entity(); seat.name = "TheaterSeat"
        addBox(to: seat, name: "SeatBase", size: [0.88, 0.22, 0.72], position: [0, -0.12, 0], color: .init(white: 0.035, alpha: 1))
        addBox(to: seat, name: "SeatBack", size: [0.88, 1.02, 0.22], position: [0, 0.43, 0.28], color: .init(white: 0.045, alpha: 1))
        addBox(to: seat, name: "ArmL", size: [0.12, 0.42, 0.78], position: [-0.49, 0.02, 0], color: .init(white: 0.018, alpha: 1))
        addBox(to: seat, name: "ArmR", size: [0.12, 0.42, 0.78], position: [0.49, 0.02, 0], color: .init(white: 0.018, alpha: 1))
        seat.position = [x, y, z]
        root.addChild(seat)
    }

    private static func addBox(to parent: Entity, name: String, size: SIMD3<Float>, position: SIMD3<Float>, color: UIColor, emissive: Bool = false) {
        let mesh = MeshResource.generateBox(size: size)
        var material = PhysicallyBasedMaterial()
        material.baseColor = .init(tint: color)
        material.roughness = .init(floatLiteral: emissive ? 0.4 : 0.82)
        let entity = ModelEntity(mesh: mesh, materials: [material])
        entity.name = name
        entity.position = position
        parent.addChild(entity)
    }
}

private extension Entity {
    func forEachDescendant(_ body: (Entity) -> Void) {
        for child in children {
            body(child)
            child.forEachDescendant(body)
        }
    }
}
#endif
