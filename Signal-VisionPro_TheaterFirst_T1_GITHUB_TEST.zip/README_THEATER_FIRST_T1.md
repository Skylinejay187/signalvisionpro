# Signal Vision Pro — Theater-First T1

Base: uploaded Build 38B compile-fix package.

This is a clean theater-foundation experiment. Signal's application/core is retained,
but the active visionOS immersive scene does not use SignalVisionTheaterSpace.

T1 scope:
- New `SignalTheaterFirst.swift`.
- New immersive scene ID: `signal-theater-first`.
- Automatic theater entry from the bootstrap window.
- New Classic Cinema geometry generated independently of the legacy theater builder.
- Exactly one architectural screen object, with NO playback renderer in T1.
- Existing real Signal `RootView` mounted as the interactive spatial dashboard.
- Existing catalog/data/Live TV/settings/core remain in use.
- Old theater source remains only for compile/reference compatibility; it is not the
  registered immersive scene used by T1.

Physical acceptance test:
1. Launch Signal.
2. Classic Cinema opens automatically.
3. Signal dashboard is visible as a spatial panel in the room.
4. Navigate Signal rows, Live TV, Media Information and Settings from that panel.
5. Confirm there is only one architectural cinema screen and no playback/floating screen.
6. Exit Theater returns to the ordinary Signal window fallback.

Playback is intentionally NOT part of T1. T2 is the Aether-to-single-screen experiment
only after T1 navigation/presentation passes on the headset.
