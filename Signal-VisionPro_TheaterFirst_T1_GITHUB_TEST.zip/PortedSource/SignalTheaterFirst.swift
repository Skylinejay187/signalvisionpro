#if os(visionOS)
import SwiftUI
import RealityKit

@MainActor
final class SignalTheaterFirstState: ObservableObject {
    static let shared = SignalTheaterFirstState()

    @Published var immersiveActive = false
    @Published var entryInProgress = false
    @Published var entryError: String?

    private init() {}
}

/// T1 bootstrap: the ordinary window exists only to request the new immersive root.
/// If visionOS refuses immersive entry, the normal Signal UI remains available as
/// a safe fallback rather than presenting an empty application.
struct SignalTheaterFirstBootstrap: View {
    @EnvironmentObject private var store: CatalogStore
    @EnvironmentObject private var unityCore: UnityAppCore
    @EnvironmentObject private var legacyTheater: SignalVisionTheaterCoordinator
    @EnvironmentObject private var theaterFirst: SignalTheaterFirstState
    @Environment(\.openImmersiveSpace) private var openImmersiveSpace

    var body: some View {
        ZStack {
            RootView(visionTheaterSurface: false)
                .environmentObject(store)
                .environmentObject(unityCore)
                .environmentObject(legacyTheater)
                .opacity(theaterFirst.immersiveActive ? 0 : 1)
                .allowsHitTesting(!theaterFirst.immersiveActive)

            if theaterFirst.entryInProgress {
                VStack(spacing: 16) {
                    ProgressView()
                    Text("Opening Signal Theater")
                        .font(.headline)
                }
                .padding(28)
                .glassBackgroundEffect()
            }
        }
        .task {
            guard !theaterFirst.immersiveActive, !theaterFirst.entryInProgress else { return }
            theaterFirst.entryInProgress = true
            theaterFirst.entryError = nil

            switch await openImmersiveSpace(id: "signal-theater-first") {
            case .opened:
                theaterFirst.immersiveActive = true
            case .userCancelled:
                theaterFirst.entryError = "Theater entry was cancelled."
            case .error:
                theaterFirst.entryError = "visionOS could not open the theater."
            @unknown default:
                theaterFirst.entryError = "Unknown theater entry result."
            }
            theaterFirst.entryInProgress = false
        }
    }
}

/// T1 is intentionally playback-free. This is a clean RealityKit theater world
/// whose only application surface is the existing Signal dashboard.
struct SignalTheaterFirstSpace: View {
    @EnvironmentObject private var store: CatalogStore
    @EnvironmentObject private var unityCore: UnityAppCore
    @EnvironmentObject private var legacyTheater: SignalVisionTheaterCoordinator
    @EnvironmentObject private var theaterFirst: SignalTheaterFirstState
    @Environment(\.dismissImmersiveSpace) private var dismissImmersiveSpace
    @Environment(\.openWindow) private var openWindow

    var body: some View {
        RealityView { content, attachments in
            let world = Entity()
            world.name = "signal-t1-world"
            content.add(world)

            buildClassicCinema(into: world)

            if let dashboard = attachments.entity(for: "signal-dashboard") {
                dashboard.name = "signal-t1-dashboard"
                dashboard.position = SIMD3<Float>(0, 0.15, -2.35)
                dashboard.scale = SIMD3<Float>(repeating: 0.82)
                world.addChild(dashboard)
            }
        } update: { content, attachments in
            if let world = content.entities.first(where: { $0.name == "signal-t1-world" }),
               let dashboard = world.findEntity(named: "signal-t1-dashboard") {
                dashboard.isEnabled = true
            }
        } attachments: {
            Attachment(id: "signal-dashboard") {
                ZStack(alignment: .topTrailing) {
                    RootView(visionTheaterSurface: false)
                        .environmentObject(store)
                        .environmentObject(unityCore)
                        .environmentObject(legacyTheater)
                        .frame(width: 1500, height: 900)
                        .clipShape(RoundedRectangle(cornerRadius: 34, style: .continuous))

                    Button {
                        Task { @MainActor in
                            theaterFirst.immersiveActive = false
                            openWindow(id: "signal-main")
                            await dismissImmersiveSpace()
                        }
                    } label: {
                        Label("Exit Theater", systemImage: "xmark.circle.fill")
                            .font(.headline)
                            .padding(.horizontal, 16)
                            .padding(.vertical, 10)
                    }
                    .buttonStyle(.borderedProminent)
                    .padding(24)
                }
            }
        }
        .onAppear {
            theaterFirst.immersiveActive = true
        }
        .onDisappear {
            theaterFirst.immersiveActive = false
        }
    }

    // MARK: - T1 Classic Cinema
    // Deliberately generated here rather than importing any legacy theater builder.
    private func buildClassicCinema(into root: Entity) {
        let room = Entity()
        room.name = "signal-t1-classic-cinema"
        root.addChild(room)

        func box(_ name: String,
                 size: SIMD3<Float>,
                 position: SIMD3<Float>,
                 material: SimpleMaterial) {
            let entity = ModelEntity(
                mesh: .generateBox(size: size),
                materials: [material]
            )
            entity.name = name
            entity.position = position
            room.addChild(entity)
        }

        let dark = SimpleMaterial(color: .init(white: 0.035, alpha: 1), isMetallic: false)
        let wall = SimpleMaterial(color: .init(white: 0.075, alpha: 1), isMetallic: false)
        let trim = SimpleMaterial(color: .init(white: 0.14, alpha: 1), isMetallic: false)
        let screen = SimpleMaterial(color: .init(white: 0.92, alpha: 1), isMetallic: false)
        let seat = SimpleMaterial(color: .init(red: 0.16, green: 0.025, blue: 0.03, alpha: 1), isMetallic: false)

        // Seated coordinate system: eye ~= y 0, floor ~= -1.25 m.
        box("floor", size: [10.5, 0.12, 12.0], position: [0, -1.31, -4.3], material: dark)
        box("ceiling", size: [10.5, 0.12, 12.0], position: [0, 3.25, -4.3], material: dark)
        box("front-wall", size: [10.5, 4.6, 0.16], position: [0, 0.97, -9.95], material: wall)
        box("left-wall", size: [0.16, 4.6, 12.0], position: [-5.2, 0.97, -4.3], material: wall)
        box("right-wall", size: [0.16, 4.6, 12.0], position: [5.2, 0.97, -4.3], material: wall)

        // Architectural screen. T1 has NO video renderer.
        box("architectural-screen-frame", size: [7.75, 3.55, 0.12], position: [0, 0.72, -9.72], material: trim)
        box("architectural-screen", size: [7.25, 3.05, 0.08], position: [0, 0.72, -9.62], material: screen)

        // Stage.
        box("stage", size: [8.6, 0.30, 1.35], position: [0, -1.12, -8.95], material: trim)

        // Furnished seating behind/around the current viewer. Nothing is placed
        // directly in front of the user, preserving the dashboard sight line.
        for row in 0..<4 {
            let z = Float(0.85 + Double(row) * 1.15)
            let y = Float(-0.78 + Double(row) * 0.10)
            for col in -4...4 {
                let x = Float(col) * 0.92
                let base = Entity()
                base.name = "seat-\(row)-\(col)"
                base.position = [x, y, z]

                let cushion = ModelEntity(mesh: .generateBox(size: [0.70, 0.18, 0.62]), materials: [seat])
                cushion.position = [0, 0, 0]
                base.addChild(cushion)

                let back = ModelEntity(mesh: .generateBox(size: [0.70, 0.78, 0.16]), materials: [seat])
                back.position = [0, 0.43, 0.26]
                base.addChild(back)

                room.addChild(base)
            }
        }

        // Side architectural columns / sconces.
        for side: Float in [-1, 1] {
            for index in 0..<4 {
                let z = Float(-8.0 + Double(index) * 2.15)
                box("column-\(side)-\(index)",
                    size: [0.32, 3.8, 0.42],
                    position: [side * 4.82, 0.55, z],
                    material: trim)
            }
        }
    }
}
#endif
