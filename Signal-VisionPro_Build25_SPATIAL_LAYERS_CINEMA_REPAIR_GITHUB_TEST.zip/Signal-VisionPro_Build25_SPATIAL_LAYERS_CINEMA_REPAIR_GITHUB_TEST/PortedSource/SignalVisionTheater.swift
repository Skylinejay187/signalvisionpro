import SwiftUI
import RealityKit

@MainActor
final class SignalVisionTheaterCoordinator: ObservableObject {
    static let shared = SignalVisionTheaterCoordinator()
    enum Mode: String { case app, playback }
    @Published var mode: Mode = .app
    @Published var immersiveActive = false
    @Published var transitionInProgress = false
    @Published var entryFailure: String?
    var didAttemptAutomaticEntry = false
    private init() {}
}

enum SignalVisionRemoteEvent {
    static let direction = Notification.Name("SignalVision.Remote.Direction")
    static let back = Notification.Name("SignalVision.Remote.Back")
    static let home = Notification.Name("SignalVision.Remote.Home")
    static let catalogDirection = Notification.Name("SignalVision.Catalog.Direction")
}

struct SignalVisionTheaterSpace: View {
    @EnvironmentObject private var store: CatalogStore
    @EnvironmentObject private var unityCore: UnityAppCore
    @EnvironmentObject private var theater: SignalVisionTheaterCoordinator
    @Environment(\.dismissImmersiveSpace) private var dismissImmersiveSpace
    @Environment(\.openWindow) private var openWindow
    @Environment(\.dismissWindow) private var dismissWindow
    @State private var cinemaScreenReady = false

    var body: some View {
        RealityView { content, attachments in
            print("[SignalVisionCinema][Build25] RealityView construction started")
            let floor = ModelEntity(mesh: .generateBox(size: [9, 0.08, 9]), materials: [SimpleMaterial(color: .darkGray, isMetallic: false)])
            floor.position = [0, -0.06, -3.4]
            content.add(floor)

            let ceiling = ModelEntity(mesh: .generateBox(size: [9, 0.08, 9]), materials: [SimpleMaterial(color: .black, isMetallic: false)])
            ceiling.position = [0, 3.45, -3.4]
            content.add(ceiling)

            let backWall = ModelEntity(mesh: .generateBox(size: [9, 5.2, 0.08]), materials: [SimpleMaterial(color: .black, isMetallic: false)])
            backWall.position = [0, 1.67, -6.0]
            content.add(backWall)

            let leftWall = ModelEntity(mesh: .generateBox(size: [0.08, 5.2, 9]), materials: [SimpleMaterial(color: .black, isMetallic: false)])
            leftWall.position = [-4.45, 1.67, -2.0]
            content.add(leftWall)
            let rightWall = leftWall.clone(recursive: true)
            rightWall.position.x = 4.45
            content.add(rightWall)

            let screenBacking = ModelEntity(mesh: .generateBox(size: [5.9, 3.45, 0.08]), materials: [SimpleMaterial(color: .black, isMetallic: false)])
            screenBacking.position = [0, 1.66, -5.72]
            content.add(screenBacking)

            // Empty center aisle and an unobstructed position around the viewer.
            // Physical geometry remains intentionally non-colliding.
            for row in 0..<4 {
                for seat in [-4, -3, -2, -1, 1, 2, 3, 4] {
                    let chair = ModelEntity(mesh: .generateBox(size: [0.62, 0.62, 0.62]), materials: [SimpleMaterial(color: .darkGray, isMetallic: false)])
                    chair.position = [Float(seat) * 0.82, 0.38, Float(row) * 1.0 - 0.7]
                    content.add(chair)
                }
            }

            print("[SignalVisionCinema][Build25] Room geometry built; attaching cinema screen and exit")
            if let controls = attachments.entity(for: "signal-controls") {
                // A separately anchored control surface ~1.1 m away, not a tiny
                // target baked into the 5.6 m distant screen.
                controls.position = [0, 1.08, -1.15]
                content.add(controls)
            }
            if let screen = attachments.entity(for: "signal-screen") {
                screen.position = [0, 1.65, -5.62]
                screen.scale = [0.00305, 0.00305, 0.00305]
                content.add(screen)
            }
        } attachments: {
            Attachment(id: "signal-screen") {
                Group {
                    if cinemaScreenReady {
                        RootView()
                            .environmentObject(store)
                            .environmentObject(unityCore)
                    } else {
                        ZStack {
                            Color.black
                            VStack(spacing: 18) {
                                Image(systemName: "theatermasks.fill").font(.system(size: 90))
                                Text("SIGNAL · CLASSIC CINEMA").font(.system(size: 48, weight: .bold))
                                Text("Preparing cinema screen…").font(.system(size: 30))
                            }.foregroundStyle(.white)
                        }
                    }
                }
                .frame(width: 1600, height: 900)
                .clipped()
                .background(.black)
                .clipShape(RoundedRectangle(cornerRadius: 18))
            }
            Attachment(id: "signal-controls") {
                VStack(spacing: 10) {
                    Button("Exit Theater", systemImage: "rectangle.portrait.and.arrow.right") {
                        Task { @MainActor in
                            // Reopen the 2D scene before dismissing the last open scene.
                            openWindow(id: "signal-main")
                            await dismissImmersiveSpace()
                            theater.immersiveActive = false
                        }
                    }
                    .buttonStyle(.borderedProminent)
                    // Playback controls remain on the screen in the original player;
                    // theater exit is an independent near-viewer gaze/pinch button.
                    Text("Look at Exit Theater to return to Signal")
                        .font(.caption)
                        .foregroundStyle(.secondary)
                }
                .padding(16)
                .background(.ultraThinMaterial, in: RoundedRectangle(cornerRadius: 22))
            }
        }
        .onAppear {
            theater.immersiveActive = true
            theater.transitionInProgress = false
            theater.entryFailure = nil
            theater.didAttemptAutomaticEntry = true
            print("[SignalVisionCinema][Build25] Immersive scene appeared; geometry coordinates use foot-level origin")
            // Avoid two RootView/player instances when entry originated in the window.
            dismissWindow(id: "signal-main")
            Task { @MainActor in
                try? await Task.sleep(nanoseconds: 450_000_000)
                guard theater.immersiveActive else { return }
                cinemaScreenReady = true
                print("[SignalVisionCinema][Build25] Full Signal screen attached")
            }
        }
        .onDisappear {
            theater.immersiveActive = false
            cinemaScreenReady = false
            print("[SignalVisionCinema][Build25] Immersive scene disappeared")
        }
        .onChange(of: store.playbackURL) { url in
            guard theater.mode == .playback, url == nil else { return }
            Task { @MainActor in
                openWindow(id: "signal-main")
                await dismissImmersiveSpace()
                theater.immersiveActive = false
            }
        }
    }
}
