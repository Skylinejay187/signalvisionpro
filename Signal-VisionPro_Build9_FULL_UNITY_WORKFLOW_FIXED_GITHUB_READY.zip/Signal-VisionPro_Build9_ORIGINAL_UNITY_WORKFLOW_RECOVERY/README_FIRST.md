# Build 8 — ORIGINAL UNITY source port / compiler bring-up

**Not a verified working build.** This package stops compiling the substitute `SignalRootView` entirely and instead makes the actual vBRDC357 `DebridChannelsTVOSApp` (`@main`), its `RootView`, `CatalogStore`, `UnityAppCore`, full playback source inventory, and all original managers the ONLY visionOS application target. It includes a separate bit-for-bit preserved tvOS reference under `OriginalTVOS_vBRDC357/`. Build 7 is **not** the UI baseline.

The port tree `PortedSource/` is initially a copy of the actual original tvOS `Sources/`. Deliberate platform changes are limited to: guard TVServices/TopShelf notification; replace tvOS `UIScreen` lookups with window metrics; wrap original root in `GeometryReader`; add `SignalVisionWindowMetrics`; and visionOS platform enablement for the copied AetherPlaybackKit SwiftPM manifest. No redesigned Home/Movies/Shows/Live TV or dummy Restore Code screen is compiled.

The GitHub workflow prepares the original pinned KSPlayer and AetherEngine dependencies, then attempts to compile the actual original Unity root for visionOS. **Compiler failures are expected until all platform API and binary-slice issues are addressed.** It uploads diagnostic logs even on failure. It refuses to package an IPA from the simplified foundation. An IPA is produced ONLY if the original source builds for BOTH simulator and device.

Original tvOS project is not modified. No guarantee yet that Aether binary XCFrameworks include visionOS slices, or that all tvOS APIs exist on visionOS. Retain original vBRDC357 unchanged and send the `Original-Unity-visionOS-diagnostics` artifact to continue fixing the actual compiler errors instead of shipping another substitute UI.
