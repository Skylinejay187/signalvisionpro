#!/bin/bash
set -euo pipefail
bash Scripts/fetch_patch_kspnuvio_vBRDC064.sh
bash Scripts/fetch_patch_aether_vBRDC242.sh
python3 - <<'PYTHON'
from pathlib import Path
p=Path('Vendor/AetherPlaybackKit/Package.swift')
s=p.read_text()
if '.visionOS(' not in s:
    s=s.replace('        .tvOS(.v17),','        .tvOS(.v17),\n        .visionOS(.v2),')
    p.write_text(s)
assert '.visionOS(' in p.read_text()
PYTHON
