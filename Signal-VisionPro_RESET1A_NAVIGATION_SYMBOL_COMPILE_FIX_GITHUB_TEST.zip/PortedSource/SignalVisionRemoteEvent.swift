import Foundation

// Clean-slate navigation notification contract.
// This intentionally lives outside every theater/environment implementation so
// removing an environment can never remove app-wide navigation symbols again.
enum SignalVisionRemoteEvent {
    static let direction = Notification.Name("SignalVision.Remote.Direction")
    static let back = Notification.Name("SignalVision.Remote.Back")
    static let home = Notification.Name("SignalVision.Remote.Home")
    static let catalogDirection = Notification.Name("SignalVision.Catalog.Direction")
}
