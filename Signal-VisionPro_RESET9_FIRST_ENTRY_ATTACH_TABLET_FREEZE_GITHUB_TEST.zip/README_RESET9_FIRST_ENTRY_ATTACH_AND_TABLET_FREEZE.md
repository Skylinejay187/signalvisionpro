# RESET9 — First-entry paid theater attach + one-shot tablet anchor

Version: 0.9.0-RESET9  
Build: 54

Physical RESET8 findings used for this patch:
- Paid FAB asset eventually decodes after leave/re-enter, proving the bundle resource is loadable.
- RESET8 status "ready" did not prove the entity was actually attached/visible.
- Tablet placement is good but remained head-following.

RESET9 changes:
1. Paid FAB decode and live-scene attachment are now separate success stages.
2. After addChild, the code explicitly enables the FAB entity, disables fallback, yields, verifies parentage, and only then reports `FAB attached`.
3. The status includes the attached RealityKit visual-bounds extents. A load/attach error now reports the localized failure instead of hanging on a generic loading string.
4. Tablet uses `AnchorEntity(.head, trackingMode: .once)` directly. The timed continuous-head-anchor/detach race has been removed.
5. Recenter reanchors the tablet using `.once` again.
6. Spatial drag now writes the computed 3D target directly to the tablet rig transform as well as persisting the coordinates.
7. Existing fallback geometry/orientation and async watchdog-safe loading are preserved.

Runtime acceptance criteria:
- First immersive entry must progress to `FAB attached • ...` without leaving/re-entering.
- Fallback room must disappear only after verified paid entity attachment.
- Paid geometry must actually be visible; status alone is not accepted as success.
- Turning the head after initial placement must not move the tablet.
- Pinch-dragging the grab bar must move the tablet in 3D.
