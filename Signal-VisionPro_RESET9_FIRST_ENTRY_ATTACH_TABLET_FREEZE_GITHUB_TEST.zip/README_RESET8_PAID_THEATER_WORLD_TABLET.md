# RESET8 / Build 53 — Paid Theater + World-Space Tablet

Physical RESET7 testing confirmed the head-relative spawn location is good, but the tablet remained head-following and the paid FAB theater had not visibly replaced the fallback room.

RESET8 changes only those two paths:

- Tablet still acquires its initial comfortable pose from a RealityKit head anchor.
- After 700 ms it is reparented to `SignalTabletWorldRoot` with `preservingWorldTransform: true`; the head anchor is then disabled. It therefore keeps the good spawn pose but no longer follows the wearer's head.
- Recenter temporarily reparents it to the head anchor, reacquires the current head pose, and detaches it back into world space again.
- The paid FAB USDZ remains the selected default and is loaded asynchronously from the exact bundle URL; fallback remains only until that entity is actually present.
- Runtime geometry calibration and the fallback geometry/orientation are unchanged from RESET7.
- Original purchased GLB/Blend/textures remain the authoritative source assets; they are not redistributed in this test ZIP. The current app-bundled USDZ is only the runtime representation until a macOS/Xcode conversion pipeline from the originals is available.

Physical Vision Pro testing remains authoritative.
