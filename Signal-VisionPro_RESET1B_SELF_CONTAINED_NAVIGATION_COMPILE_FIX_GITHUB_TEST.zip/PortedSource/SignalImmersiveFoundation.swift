#if os(visionOS)
import SwiftUI
import RealityKit
import ARKit
import QuartzCore

@MainActor
final class SignalImmersiveFoundationState: ObservableObject {
    static let shared = SignalImmersiveFoundationState()

    // Tablet coordinates are expressed in the user's spawn frame:
    // +X = user's right, +Y = up, +Z = behind the user. Therefore a negative Z
    // places the tablet in front of the user.
    @Published var tabletX: Float = 0.0
    @Published var tabletY: Float = -0.18
    @Published var tabletZ: Float = -1.05
    @Published var recenterRevision: Int = 0

    func resetTablet() {
        tabletX = 0.0
        tabletY = -0.18
        tabletZ = -1.05
    }

    func requestRecenter() {
        recenterRevision &+= 1
    }
}

@MainActor
private final class SignalDevicePoseTracker {
    static let shared = SignalDevicePoseTracker()
    private let session = ARKitSession()
    private let worldTracking = WorldTrackingProvider()
    private var started = false

    func startIfNeeded() async {
        guard !started else { return }
        guard WorldTrackingProvider.isSupported else { return }
        started = true
        do {
            try await session.run([worldTracking])
        } catch {
            started = false
            print("[SignalFoundation] world tracking start failed: \(error)")
        }
    }

    func pose() -> simd_float4x4? {
        guard worldTracking.state == .running else { return nil }
        guard let anchor = worldTracking.queryDeviceAnchor(atTimestamp: CACurrentMediaTime()), anchor.isTracked else { return nil }
        return anchor.originFromAnchorTransform
    }
}

struct SignalImmersiveBootstrap: View {
    @Environment(\.openImmersiveSpace) private var openImmersiveSpace
    @Environment(\.dismissWindow) private var dismissWindow
    @State private var requested = false

    var body: some View {
        Color.clear
            .frame(width: 1, height: 1)
            .task {
                guard !requested else { return }
                requested = true
                let result = await openImmersiveSpace(id: "signal-clean-foundation")
                if case .opened = result {
                    dismissWindow(id: "signal-main")
                }
            }
    }
}

struct SignalImmersiveFoundationSpace: View {
    @StateObject private var state = SignalImmersiveFoundationState.shared
    @State private var spawnTransform = Transform.identity
    @State private var lastAppliedRecenter = -1
    @State private var dragStartX: Float?
    @State private var dragStartY: Float?

    var body: some View {
        RealityView { content, attachments in
            let root = Entity()
            root.name = "SignalCleanFoundationRoot"
            content.add(root)

            if let tablet = attachments.entity(for: "signal-control-tablet") {
                tablet.name = "SignalControlTablet"
                root.addChild(tablet)
            }
        } update: { content, attachments in
            guard let root = content.entities.first(where: { $0.name == "SignalCleanFoundationRoot" }) else { return }

            if state.recenterRevision != lastAppliedRecenter,
               let pose = SignalDevicePoseTracker.shared.pose() {
                spawnTransform = Self.horizontalSpawnTransform(from: pose)
                root.transform = spawnTransform
                lastAppliedRecenter = state.recenterRevision
            }

            if let tablet = attachments.entity(for: "signal-control-tablet") {
                // This is deliberately NOT parented to any theater/model transform.
                // Positive X always means the wearer's right in the calibrated spawn frame.
                tablet.position = [state.tabletX, state.tabletY, state.tabletZ]
                tablet.orientation = simd_quatf(angle: 0, axis: [0, 1, 0])
            }
        } attachments: {
            Attachment(id: "signal-control-tablet") {
                SignalCleanControlTablet(state: state)
                    .frame(width: 560, height: 330)
                    .glassBackgroundEffect(in: RoundedRectangle(cornerRadius: 34))
                    .gesture(
                        DragGesture(minimumDistance: 0)
                            .onChanged { value in
                                if dragStartX == nil {
                                    dragStartX = state.tabletX
                                    dragStartY = state.tabletY
                                }
                                let sx = dragStartX ?? state.tabletX
                                let sy = dragStartY ?? state.tabletY
                                // SwiftUI drag right => +X => user's right.
                                // SwiftUI drag down => -Y => down.
                                state.tabletX = sx + Float(value.translation.width) * 0.0015
                                state.tabletY = sy - Float(value.translation.height) * 0.0015
                            }
                            .onEnded { _ in
                                dragStartX = nil
                                dragStartY = nil
                            }
                    )
            }
        }
        .task {
            await SignalDevicePoseTracker.shared.startIfNeeded()
            for _ in 0..<50 {
                if SignalDevicePoseTracker.shared.pose() != nil {
                    state.requestRecenter()
                    break
                }
                try? await Task.sleep(nanoseconds: 40_000_000)
            }
        }
    }

    private static func horizontalSpawnTransform(from pose: simd_float4x4) -> Transform {
        let position = SIMD3<Float>(pose.columns.3.x, pose.columns.3.y, pose.columns.3.z)

        // Device forward is local -Z. Flatten to the floor plane so head pitch/roll
        // cannot tilt or invert the foundation frame.
        var forward = SIMD3<Float>(-pose.columns.2.x, 0, -pose.columns.2.z)
        if simd_length_squared(forward) < 0.0001 {
            forward = [0, 0, -1]
        } else {
            forward = simd_normalize(forward)
        }
        let yaw = atan2(forward.x, -forward.z)
        let rotation = simd_quatf(angle: yaw, axis: [0, 1, 0])
        return Transform(scale: .one, rotation: rotation, translation: position)
    }
}

private struct SignalCleanControlTablet: View {
    @ObservedObject var state: SignalImmersiveFoundationState

    var body: some View {
        VStack(alignment: .leading, spacing: 16) {
            HStack {
                VStack(alignment: .leading, spacing: 3) {
                    Text("SIGNAL").font(.system(size: 19, weight: .black))
                    Text("CLEAN IMMERSIVE FOUNDATION").font(.caption).foregroundStyle(.secondary)
                }
                Spacer()
                Image(systemName: "move.3d")
                Text("Drag me")
                    .font(.caption)
                    .foregroundStyle(.secondary)
            }

            Divider()

            Text("No theater environment is loaded in this build.")
                .font(.headline)
            Text("This reset exists only to verify the Vision Pro world frame and controller movement before any new cinema model is introduced.")
                .font(.callout)
                .foregroundStyle(.secondary)

            HStack {
                Button("Recenter") { state.requestRecenter() }
                    .buttonStyle(.borderedProminent)
                Button("Reset Tablet") { state.resetTablet() }
                Spacer()
                Text(String(format: "x %.2f   y %.2f   z %.2f", state.tabletX, state.tabletY, state.tabletZ))
                    .font(.caption.monospacedDigit())
                    .foregroundStyle(.secondary)
            }
        }
        .padding(24)
        .background(.black.opacity(0.18))
    }
}
#endif
