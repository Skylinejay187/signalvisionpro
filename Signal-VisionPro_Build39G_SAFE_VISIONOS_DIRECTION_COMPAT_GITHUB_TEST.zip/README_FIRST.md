# Build 10: original Unity root — KSPlayer visionOS compile correction

READ `README_BUILD10_KSPLAYER_VISIONOS_FIX.md` first. Source remains the original vBRDC357 Unity app, not the replacement UI.
