# Build 18 — Original Unity SwiftUI compile repair

Directly based on the full Build 17 package. Addresses the six diagnosed errors from GitHub run 96583602984: the season strips, satellite source row, missing `return` in providerChip, Source Intelligence overlay and VOD panel option. The original full Apple TV source remains unchanged; source screens and player dependencies are preserved. Swift syntax and project/ZIP checks are not equivalent to building with Xcode; run GitHub Actions and upload its diagnostics if compilation still fails.
