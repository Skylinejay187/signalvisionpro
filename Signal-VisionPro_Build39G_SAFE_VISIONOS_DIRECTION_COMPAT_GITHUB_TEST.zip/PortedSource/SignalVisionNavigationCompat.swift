import SwiftUI

// visionOS does not expose tvOS MoveCommandDirection/onMoveCommand.
// Preserve the original Unity directional routing for hardware keyboard arrows
// without modifying the unported Apple TV source. Native gaze/pinch selection
// continues through SwiftUI's existing focus and button interaction system.
enum SignalMoveDirection: Equatable {
    case up, down, left, right
}

extension View {
    func signalMoveCommand(perform action: @escaping (SignalMoveDirection) -> Void) -> some View {
        self
            .onKeyPress(keys: [.upArrow, .downArrow, .leftArrow, .rightArrow]) { press in
                switch press.key {
                case .upArrow: action(.up)
                case .downArrow: action(.down)
                case .leftArrow: action(.left)
                case .rightArrow: action(.right)
                default: return .ignored
                }
                return .handled
            }
            .onReceive(NotificationCenter.default.publisher(for: SignalVisionRemoteEvent.direction)) { note in
                guard let direction = note.object as? SignalMoveDirection else { return }
                action(direction)
            }
    }
}


// v16: tvOS-only modifiers are not available on visionOS. Keep the same
// original Unity callbacks wired to keyboard equivalents; primary gaze/pinch
// operation still goes through the unchanged onTapGesture/Button actions.
extension View {
    @ViewBuilder
    func signalVisionFocusSection() -> some View {
        #if os(tvOS)
        self.focusSection()
        #else
        self
        #endif
    }

    @ViewBuilder
    func signalVisionExitCommand(_ action: @escaping () -> Void) -> some View {
        #if os(tvOS)
        self.onExitCommand(perform: action)
        #else
        self
            .onKeyPress(keys: [.escape]) { _ in action(); return .handled }
            .onReceive(NotificationCenter.default.publisher(for: SignalVisionRemoteEvent.back)) { _ in action() }
        #endif
    }

    @ViewBuilder
    func signalVisionPlayPauseCommand(_ action: @escaping () -> Void) -> some View {
        #if os(tvOS)
        self.onPlayPauseCommand(perform: action)
        #else
        self.onKeyPress(keys: [.space]) { _ in action(); return .handled }
        #endif
    }
    @ViewBuilder
    func signalVisionFocusEffectPolicy() -> some View {
        #if os(tvOS)
        self.focusEffectDisabled()
        #else
        // visionOS: retain the native gaze/hand focus highlight. The tvOS build
        // intentionally suppresses Apple's default focus ring because Signal draws
        // its own Unity chrome, but suppressing it on Vision Pro makes targets appear
        // non-interactive to eye targeting.
        self.hoverEffect(.highlight)
        #endif
    }

}
