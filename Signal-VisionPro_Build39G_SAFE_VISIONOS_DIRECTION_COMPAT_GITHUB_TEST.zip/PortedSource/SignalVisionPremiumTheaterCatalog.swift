import Foundation

/// Build 36 future premium environment registry.
///
/// The Free3D model is NOT bundled in this build. This record only reserves the
/// product identity and price the user requested. The purchased model must be
/// converted into a protected app resource before this entry is enabled because
/// Free3D's Royalty Free License permits use inside an interactive Creation but
/// prohibits redistributing the raw Stock Media Product in an open/extractable form.
enum SignalVisionPremiumTheaterCatalog {
    static let premiumMovieTheaterProductID = "signal.vision.theater.premium.movieinterior"
    static let premiumMovieTheaterDisplayName = "Premium Movie Theater"
    static let premiumMovieTheaterPriceUSD: Decimal = 0.99
    static let premiumMovieTheaterAssetSource = "Free3D Movie Theater Interior 4554"

    /// Keep false until the model has been purchased, converted, protected and
    /// its final distribution treatment has been checked against the purchased license.
    static let premiumMovieTheaterAssetBundled = false
}
