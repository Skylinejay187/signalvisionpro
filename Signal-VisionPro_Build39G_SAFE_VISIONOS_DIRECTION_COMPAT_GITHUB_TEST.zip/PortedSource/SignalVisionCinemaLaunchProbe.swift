import SwiftUI

/// A restored visionOS window may appear instead of the preferred immersive launch role.
/// This view requests the already-declared immersive scene ONCE, avoiding a second request
/// when exiting the theater and returning to Signal.
struct SignalVisionCinemaLaunchProbe: View {
    @EnvironmentObject private var theater: SignalVisionTheaterCoordinator
    @Environment(\.openImmersiveSpace) private var openImmersiveSpace

    var body: some View {
        Color.clear
            .frame(width: 0, height: 0)
            .task { @MainActor in
                guard !theater.didAttemptAutomaticEntry, !theater.immersiveActive,
                      !theater.transitionInProgress else { return }
                theater.didAttemptAutomaticEntry = true
                theater.transitionInProgress = true
                defer { theater.transitionInProgress = false }
                theater.mode = .app
                // Let the first window finish connecting and the system settle.
                try? await Task.sleep(nanoseconds: 650_000_000)
                guard !Task.isCancelled, !theater.immersiveActive else { return }
                print("[SignalVisionCinema][Build25] Restored 2D scene: automatic immersive entry requested")
                switch await openImmersiveSpace(id: "signal-theater") {
                case .opened:
                    print("[SignalVisionCinema][Build25] openImmersiveSpace returned opened")
                case .userCancelled:
                    theater.entryFailure = "Cinema entry cancelled. Use Vision Pro / Theater to retry."
                    print("[SignalVisionCinema][Build25] automatic entry userCancelled")
                case .error:
                    theater.entryFailure = "Cinema scene was refused by visionOS. Reopen it from Theater settings; capture the [SignalVisionCinema] device log if this repeats."
                    print("[SignalVisionCinema][Build25] automatic entry error; check system immersive-space activity and Info.plist in signed app")
                @unknown default:
                    theater.entryFailure = "Cinema entry returned an unknown result."
                }
            }
    }
}
