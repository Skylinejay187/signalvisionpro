# Signal Vision Pro — Build 32
## RealityKit Video Screen + CC0 Cinema Multiplex + Media Information Compositing Repair

Build 32 patches forward from Build 31B while preserving the Build 27 immersive-space launch configuration that physically opened on Apple Vision Pro.

### 1. The cinema screen is now a real RealityKit video surface
Build 31B placed the full SwiftUI/Signal root into a RealityView attachment. That can preserve SwiftUI controls, but it does not turn the UIKit / KSPlayer / Aether rendering surface into video pixels on a 3D plane. Build 32 removes that fake-screen path and creates a RealityKit `ModelEntity` with `VideoMaterial(avPlayer:)` on a real XY screen plane.

`SignalVisionTheaterVideoBridge` is the single owner of the immersive AVPlayer. Before it takes a theater URL it releases auxiliary preview players, releases the PlaybackKit render surface for the active session, and stops that PlaybackKit session. This is specifically intended to prevent the repeated / quadruple audio symptom when the same media has more than one render owner.

Playback headers are retained when creating the AVURLAsset. Theater controls operate on the same immersive AVPlayer (play/pause, +/-15 sec). Exiting the immersive space stops the theater AVPlayer before returning the 2D app.

IMPORTANT: this path can play formats that AVPlayer supports. Physical Vision Pro testing is still required for every debrid source format. It does not claim that every KSPlayer/Aether-only codec is now AVPlayer-compatible.

### 2. Real CC0 cinema assets from the user-selected 3DAssets.dev pack
Build 32 uses the Cinema Multiplex and Foyer pack supplied by the user:
- Pack: https://3dassets.dev/packs/cinema-multiplex-and-foyer
- Tiered row: https://3dassets.dev/assets/cinema-multiplex-and-foyer-tiered-seating-row-ec21447b
- License: CC0 1.0 Universal

GitHub Actions downloads selected permanent CDN GLBs and converts their static geometry to USDA before XcodeGen. Textured base-color images are exported and referenced by the USDA when present. The build fails early if required converted assets are missing, and the compiled .app is checked to ensure key assets were actually bundled.

Selected modules:
- tiered cinema seating rows
- premium recliner rows
- cinema screen + masking frame
- acoustic wall panels
- exit door + sign
- side wall light strips
- projection-port wall panel
- auditorium aisle floor tiles
- wall-mounted surround speakers
- aisle step modules
- wall-mounted poster light boxes
- assembled multiplex floor (kept available as a reference/fallback resource)

The original procedural geometry remains only as structural fallback / fill so a failed optional model does not make the ImmersiveSpace empty.

### 3. Seated viewer layout
Classic Cinema now transforms the auditorium around the selected seat rather than simply moving a UI value. The selected row is centered on the viewer origin and intentionally leaves the head position open while peripheral chair geometry surrounds the viewer. Non-selected rows use the CC0 tier modules at real-world scale. Side aisles, tier rise and screen sightline are rebuilt around this origin.

Changing Front/Middle/Back, Left/Center/Right or seat-height changes the RealityView identity so the environment is reconstructed immediately from that anchor.

### 4. Media Information no longer depends on the connector-line layer
The visionOS Media Information popup no longer applies `SignalVisionLayerSurface(level: .detail, ...)`. The invisible-but-hit-testable symptom proved the popup content was still mounted while its spatial composition disappeared.

Build 32 keeps Media Information in the primary Signal composition and gives its popup a visible visionOS foundation. `connectorLineVisible` controls the decorative connector only. It is not consulted by `mediaInfoPanelPresented` or by the panel background visibility.

Catalog rows remain on their normal flat Signal/Unity presentation and do not receive the Media Information popup treatment.

### 5. Build / regression checks
- Build number: 32
- Preserve Build 27 nested `UIApplicationSupportsMultipleScenes=true` manifest arrangement
- Preserve original Apple TV vBRDC357 source tree and hash lock
- Swift frontend parser check before the long Xcode build
- Cinema source asset verification
- GitHub-time CC0 asset fetch / conversion validation
- Compiled app asset-presence validation
- Device-only visionOS build path remains primary to avoid the old duplicate simulator compile

### Physical test priorities
1. Select VOD / Live TV and enter theater: moving picture must appear on the physical cinema screen.
2. Confirm only one copy of program/movie audio is audible after repeated tuning and theater entry/exit.
3. Disable the Media Information Connector Line and open Media Information: the popup must remain visible and interactive; connector retraction must not dismiss it.
4. Change cinema row / seat / height and confirm the room moves to a genuinely different seated sightline.
5. Inspect CC0 seat rows, masking frame, acoustic walls, aisle treatment, exit/projection details, speakers and poster boxes on device.
