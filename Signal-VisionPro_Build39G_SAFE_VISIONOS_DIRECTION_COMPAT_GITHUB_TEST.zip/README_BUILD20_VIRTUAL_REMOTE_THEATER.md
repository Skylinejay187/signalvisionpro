# Build 20 — Vision Pro interaction + theater foundation

Build 20 starts the physical-headset phase from the successfully compiling Build 19 full Unity port.

Changes:
- Native visionOS gaze highlight is restored for controls that the tvOS source intentionally marked `focusEffectDisabled()`.
- Adds an always-available virtual remote: Up / Down / Left / Right / Back / Home.
- During VOD/Live playback the remote fades to 10% opacity after 3.5 seconds; targeting/hovering the dock wakes it again.
- Adds two theater entry modes: App Theater and Playback Theater.
- App Theater keeps the full Signal Unity app on the cinema screen so browsing and playback remain in the environment.
- Playback Theater enters the cinema for current playback and returns to the normal Signal window when playback ends.
- Adds a first procedural cinema room (screen, dark room, floor and seating) as the theater foundation.
- Main Vision Pro window defaults to 1600x900 so the 16:9 Unity canvas no longer starts cramped; it remains resizable.
- GitHub Actions now builds the physical Vision Pro device target once. The redundant optional simulator compile was removed because it compiled the huge Unity root a second time and materially increased successful run time.

Important runtime note:
- The fade wake-up currently responds to Vision Pro target hover/gaze/hand interaction with the dock. A free-space "wave anywhere" hand gesture is not claimed in this build; that requires a separate ARKit hand-tracking interaction layer and permission/runtime validation on hardware.
- Theater geometry and attachment scale require physical Vision Pro tuning.
