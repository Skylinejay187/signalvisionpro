# Build 39B — Workflow Source Discovery Fix

Narrow follow-up to Build 39.

- Preserves Build 39 Aether-only playback and theater changes.
- Repairs GitHub Actions source discovery for ZIP-based builds.
- Removes the obsolete 1:1 original-tvOS source completeness gate, which is invalid after the intentional Aether-only Vision Pro migration.
- Adds extracted-project diagnostics.
- No theater/UI/playback behavior was rolled back.
