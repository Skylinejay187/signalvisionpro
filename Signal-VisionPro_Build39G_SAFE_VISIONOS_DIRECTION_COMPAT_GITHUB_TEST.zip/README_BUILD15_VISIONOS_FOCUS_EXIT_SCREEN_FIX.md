# Build 15 — visionOS platform API compilation patch

Based directly on full Unity Build 14; no original tvOS sources removed or modified.

Build 14 log `logs_96573508189.zip` reached original Unity Swift compilation and failed at three tvOS-only `.onExitCommand` modifiers, three `.focusSection` modifiers (all in Phase15FinalIntegration.swift) and three `UIScreen.main.scale` calls in PlaybackKitKSPlayerSurface.swift.

This patch retains the original tvOS API calls behind conditional platform adapters and preserves the same visible Close/Cancel interactions on visionOS; remote Exit handling and focus-section behavior are not claimed as implemented on visionOS. The SwiftUI layer now takes the current UIView traitCollection displayScale instead of UIScreen.main.scale. The original full source, assets, players and features are preserved.

Replace the repository's root `.github/workflows/build-visionos.yml` with the one inside this archive in addition to replacing/extracting the package. A GitHub IPA is not verified until Actions successfully compiles the physical-device binary.
