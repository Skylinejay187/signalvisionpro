# Signal Vision Pro — Build 29: modeled cinema asset candidate

Base: physical-tested Build 28; preserve Build 27 immersive scene fix, original vBRDC357 source, scene manifest, and existing media player libraries.

## Real changes
- Added an **original, native USDA 3D cinema recliner model** as a bundled resource. Curved upholstery, independent seat and back cushions, shell, armrests, pedestal, cup holders, PBR colors/roughness and metal accents. Not a downloaded third-party model.
- Classic Cinema loads one USD seat model and clones it into 18 theater chairs. Runtime fallback has smooth geometry if USD loading fails, and diagnostics explicitly distinguish both paths.
- Replaced block-only theater room: acoustic panel bays, slat details, sconces, perimeter trim, ceiling coffers, aisle edge markings, screen proscenium, and corrected screen sightline/aisle geometry. Kept attachment-based Signal screen and original KSPlayer/Aether player ownership.
- Room material colors use deterministic dim UnlitMaterial on architecture; curved modeled seat has PBR USD materials. This is a significant art/layout upgrade but **photorealism and live screen rendering are unverified**.
- Updated bundle build version 29; kept scene registration and launch fixed.

## External assets evaluated but NOT included
- Sketchfab CC-BY cinema interiors and chairs: downloads inaccessible in current environment and would require original author attribution and geometry/performance review.
- Poly Haven / ambientCG CC0 PBR material libraries: identified and evaluated but binary downloads unavailable in current tool runtime; none are represented as included.
- Native USDA model here was authored for Signal, not copied from Sketchfab or converted from a downloaded GLB. It avoids license uncertainty.

## Required headset acceptance
1. Verify GitHub xcodebuild succeeds; preserve Build 28 IPA for rollback.
2. Enter Classic Cinema. Confirm modeled seats are loaded in Cinema Diagnostics: `CinemaSeat USD geometry loaded`. If fallback logs instead, inspect asset bundling and USD validation rather than saying it succeeded.
3. From center starting position, screen ahead unobstructed, visible details but no glare. Verify gaze Exit Theater.
4. Test VOD and Live TV in theater: confirm real moving video and audio; if dark, log player surface/render state. A rendered frame is NOT guaranteed by appearance of this model.
5. Re-test Home Theater, Drive-In, catalog popup and Media Information connector off/on (no regressions).

No macOS/visionOS SDK or physical headset available here; a local Swift grammar parser is not a full Xcode build. The model should be validated with `usdchecker --arkit` on runner if available and actual headset appearance checked before claiming completion.
