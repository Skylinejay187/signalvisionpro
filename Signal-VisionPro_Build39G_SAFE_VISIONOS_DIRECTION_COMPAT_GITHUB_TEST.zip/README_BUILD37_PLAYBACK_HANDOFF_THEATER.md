# Build 37 — Playback Handoff Theater

- Theater is playback-only; Signal browsing stays in the normal window.
- Drive-In removed until further notice.
- Movable eye-level theater HUD controls playback plus existing Signal VOD overlay settings (Production/Ratings and Spotlight Hub) through the same AppStorage keys used by Apple TV.
- Front/Middle/Back, Left/Center/Right, seat height, tilt, screen size/height and house lighting remain adjustable.
- Catalog wall posters use widely separated items from the loaded catalog and display artwork only (no title text).
- Grand Theater keeps the complete playhouse starter scene and explicitly adds Cinema Multiplex tiered seating and premium rear recliners.
- Build 27 immersive-space registration remains untouched.
- Drive-In code remains dormant only for rollback/history; it is not exposed as an environment.

## Architecture references applied
Build 37 follows the Destination Video/OpenImmersive direction: browsing remains outside the environment; immersive space is a playback destination with a dedicated transport/control surface. The existing Build 27 scene-registration path remains locked. The next native docking step can migrate the screen renderer to AVPlayerViewController + DockingRegionComponent without putting the Signal browser inside the theater.

## Environment policy
Drive-In is removed from the user-facing environment picker/catalog until further notice. Classic, Grand, Home, Private Screening, Rooftop, Retro Palace, Abandoned Cinema and Cruise Deck remain. Grand Theater mounts the free playhouse starter plus Cinema Multiplex tier seating and premium rear recliners.
