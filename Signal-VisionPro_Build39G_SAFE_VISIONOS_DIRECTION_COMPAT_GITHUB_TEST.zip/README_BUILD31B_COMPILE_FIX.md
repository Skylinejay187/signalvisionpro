# Build 31B — RealityKit / CGFloat compile fix

This patch is based directly on Build 31 and only repairs the compiler errors reported by the Build 31 GitHub Actions log.

Changes:
- Wrap dynamic RealityKit `SimpleMaterial` roughness values in `MaterialScalarParameter.float(...)`.
- Convert dynamic Drive-In `UIColor` red/blue components from `Float` to `CGFloat`.
- Preserve Build 31 theater, Media Information, catalog, playback single-owner, and Build 27 immersive-space behavior unchanged.

The KSPlayer actor-isolation messages in the supplied log remain warnings and were not the Build 31 failure.
