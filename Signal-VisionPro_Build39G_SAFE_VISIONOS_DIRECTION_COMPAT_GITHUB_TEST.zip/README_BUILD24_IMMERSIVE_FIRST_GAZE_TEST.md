# Signal Vision Pro Build 24 — headset diagnostic candidate

PATCH BASE: Build 23 exclusively. Complete vBRDC357 original source retained unchanged.

## Deliberate diagnostic behavior
* VisionInfo.plist requests the first immersive scene as the **launch scene** with full immersion. This bypasses the failing `openImmersiveSpace` call entirely. Launch Signal => Classic Cinema; Exit Theater => ordinary Signal window. This is a temporary diagnostic, not the final launch workflow.
* `SignalVisionTheaterSpace.onAppear` logs `[SignalVisionCinema][Build24] Immersive scene appeared` and `onDisappear` logs closure. Absence of this on physical device means the immersive scene failed even via default-launch configuration.
* No new claimed theater permissions; no ARKit permission requested.

## Vision interaction changes
* The Live TV grid card uses a real SwiftUI Button. Looking at a card attempts to bind Signal's existing selection, ring and preview. Eye gaze hover delivery is still a headset test requirement: SwiftUI `onHover` is not guaranteed to deliver every raw gaze transition.
* Hold-pinch/drag within grid attempts to traverse current 12-card page: horizontal translation ~170 pt/column, vertical ~155 pt/row. Release settles selection / preview only; short pinch of a card activates that channel. This is a best-effort DragGesture, NOT lower-level hand tracking. The system may arbitrate drag/tap differently in visionOS; test before declaring this reliable.
* Existing page previous/next arrows remain. Switching pages pins incoming selected card's ring.
* Live TV playback's VOD chips are native Buttons, focus before activation. Top-right playback X is more visible. Tapping bare video may continue to toggle play/pause; use explicit controls.
* Existing catalog navigation arrows moved from trailing side to left gutter near rows. No catalog or detail UI redesign.
* Icon asset now clips all three existing Signal artwork layers to a common circular silhouette (no invented branding).

## Physical testing order
1. Start from fully terminated application; confirm Classic Cinema appears directly and capture `[SignalVisionCinema][Build24]` logs.
2. Exit Theater => Signal window. Inspect screen attachment / control and playback separately.
3. Live TV grid: look A, ring + preview; look B, ring + preview. Hold pinch + drag to C; release = focus only; short pinch = plays.
4. During live playback focus each VOD chip; pinch = that chip action. X exits playback; tapping background may still pause.
5. Inspect catalog arrows and circular icon.

## Known limitations and locks
No Xcode/physical Vision Pro available in this environment. ZIP integrity and structural code checks only, not a successful compilation or proof of runtime gaze/theater. This candidate does NOT implement the promised three independently managed spatial windows. Existing SwiftUI same-window catalog/detail focus layers are retained; multi-window architecture requires a separate build and physical validation. All original tvOS source remains unchanged, existing playback engines remain untouched.
