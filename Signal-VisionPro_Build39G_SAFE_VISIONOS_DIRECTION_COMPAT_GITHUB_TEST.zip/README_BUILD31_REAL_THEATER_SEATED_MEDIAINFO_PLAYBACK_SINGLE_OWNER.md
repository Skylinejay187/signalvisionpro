# Signal Vision Pro — Build 31

## Real Theater / Seated Viewer / Media Information Independence / Single-Owner Playback

Build 31 patches forward from Build 30 while preserving the Build 27 immersive-space launch architecture as a regression lock. The `ImmersiveSpace` identity, multi-scene configuration, window transition behavior, and compiled-app manifest verification are intentionally not redesigned in this build.

### 1. Theater is now built around a seated viewer

The immersive environment no longer assumes that the user is standing in a center aisle. Build 31 uses a seated-eye coordinate system and constructs the active auditorium around the selected seat. The selected chair occupies the viewer position while the rest of the environment, screen, tiers, and surrounding seats are positioned relative to that seat.

Vision settings now expose persistent theater seating controls:

- Row: Front / Middle / Back
- Seat: Left / Center / Right
- Seat height adjustment
- Environment: Classic Cinema / Home Theater / Drive-In

The chosen position is applied when the theater opens so the user's sightline and screen distance are derived from the selected seat instead of a generic room origin.

### 2. Each environment is actually distinct

**Classic Cinema** now has tiered auditorium seating, side aisles, acoustic wall bays, sconces, ceiling acoustic rafts/coves, proscenium/screen surround, projection-booth details, exit doors/signs, aisle markers, modeled seats, and Signal artwork lightboxes.

**Home Theater** is a separate residential room: wood floor, rug, warm lighting, walnut/acoustic front wall, speaker towers, smaller seating rows, side tables, and a closer home-cinema screen.

**Drive-In** no longer reuses the cinema room. It is an open night environment with an outdoor freestanding screen, lot/car rows, speaker posts, horizon/stars, and a modeled car interior around the viewer (seat, dashboard, hood, roof/windshield framing).

### 3. Signal posters inside the theater

Poster lightboxes use live Signal catalog artwork instead of permanently bundled fake movie posters. This keeps the theater visually connected to the user's current Signal catalog while avoiding a second content system.

### 4. Media Information connector is structurally decoupled

On visionOS, Media Information panel presentation is now controlled by the Media Information view lifecycle/dismissal state, not by connector-line visibility. The connector line setting and its retract timer can only show/hide the connector decoration.

The panel therefore no longer uses `stageBackdropVisible` as its visionOS visibility gate. It remains mounted until the Media Information view is explicitly dismissed.

### 5. Catalog rows restored to the normal Signal presentation

The catalog-only `SignalVisionLayerSurface(.catalog)` modifier has been removed. Catalog rows retain the original Signal/Unity presentation and interaction behavior instead of floating forward like the Media Information panel. Media Information remains the dedicated spatial popup layer.

### 6. Playback is now retired before every replacement path

Build 31 adds one shared `retirePlaybackPresentation` barrier and uses it before all major playback-session replacement paths:

- normal start/replacement
- experimental source handoff
- restore-original-source
- automatic failover
- close-player

The barrier releases auxiliary preview playback, begins the old presentation's dismissal, suspends/detaches its render host, and stops the old PlaybackKit session before a replacement playback URL/session ID is published. This is intended to prevent old KSPlayer/Aether/render/audio owners from surviving underneath a new Live TV or VOD session and producing duplicate/quadruple audio.

Build 31 also closes a Vision Pro-specific ownership gap: the ordinary window `RootView` and the immersive-screen `RootView` can overlap during space transitions. They now have explicit roles, and only one root is permitted to instantiate `VODPlayerScreen` at a time. When entering or leaving theater during active playback, `PlaybackController.releaseRenderSurfaceForEngineHandoff` releases the outgoing UIKit/KS surface while preserving the shared playback session identity for the incoming root.

### 7. Screen ownership remains Signal's existing playback path

Build 31 does not introduce a second AVPlayer or independent cinema playback engine. The theater screen still hosts the existing Signal view/player ownership path. This is deliberate so KSPlayer/Aether behavior remains centralized.

### 8. Environment research / asset policy

The environment dimensions and modular cinema ideas were cross-checked against current visionOS immersive-media guidance and open cinema reference assets. A CC0 Cinema Multiplex/Foyer set from 3DAssets.dev was used as a dimensional/design reference (screen proportions, row pitch, aisle widths, acoustic panels, exit/projection details). Its binary GLB files are **not** vendored in this source package because they were not reliably retrievable inside the build-editing environment. The Build 31 auditorium is implemented natively in RealityKit and continues to bundle Signal's existing `CinemaSeat.usda` asset.

See `Resources/Cinema/ASSET_SOURCES.md`.

### Validation still required on physical Vision Pro

This source package is GitHub-ready, not proof of runtime success. Physical headset testing remains required for:

- exact seated eye-height and comfort
- environment scale / seat spacing
- one-audio-owner behavior through repeated Live TV/VOD tuning
- Media Information persistence with connector line disabled/retracted
- catalog rows remaining flat/normal
- screen playback and theater state restoration

Build 27's confirmed immersive-entry architecture remains the regression baseline.
