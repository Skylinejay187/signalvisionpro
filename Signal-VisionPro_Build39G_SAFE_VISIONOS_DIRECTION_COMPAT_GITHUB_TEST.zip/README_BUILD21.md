# Build 21 — Vision Pro native controls and cinema lifecycle patch

Authoritative source: user-supplied Build 20 only. Full vBRDC357 original references, Unity port, dependency preparation scripts, playback architecture and working GitHub device build route are retained.

Changes: native gaze/pinch tab shortcuts and direct Back/Home handling (detail, search, quick panel, playback); theater open result diagnostics and transition guard; avoid dismissing the original window upon entry; near-viewer floating theater controls with Exit; full-room ceiling and four rows of seats; build number 21.

Scope limitation: this is a test candidate, NOT a physically verified solution. Existing detailed screen interactions and Live TV double-pinch pagination have NOT been comprehensively migrated to native visionOS. Theater playback presentation still uses the preserved Signal RootView screen and requires physical headset testing. No macOS Xcode/visionOS SDK is available in the packaging environment, so GitHub CI and physical tests remain required.
