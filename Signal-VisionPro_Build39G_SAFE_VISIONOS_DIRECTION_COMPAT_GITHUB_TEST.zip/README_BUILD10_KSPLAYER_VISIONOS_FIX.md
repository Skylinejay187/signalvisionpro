# Build 10 — original Unity source: first actual visionOS compiler correction

From user-supplied Build 9 GitHub log `logs_96565002482.zip`: project detection, pinned KSPlayer/Aether preparation, and XcodeGen completed. Simulator compilation stopped at two genuine KSPlayer errors in `Video/VideoPlayerView.swift` lines 706 and 741: `UIScreen.main.scale` is unavailable on visionOS. The log also contains warnings and Aether FFmpeg binary-slice notes; these are not yet resolved or proof of a successful device build.

This build preserves the complete original vBRDC357 Apple TV source and existing Unity root. After fetching the **same pinned KSPlayer revision** and applying the existing vBRDC064 fixes, an additional strict/idempotent visionOS-only patch substitutes rasterizationScale=1.0 in the two offending assignments, leaving the tvOS code unchanged. This is a conservative compile workaround; spatial display sharpness must be checked on device and refined with a reliable window/trait-based scale later.

The workflow retains strict simulator and device compilation, uploads logs on failure, and only creates an unsigned IPA after both builds pass. It favors a Build 10 ZIP when multiple archives are present. Replace the actual `.github/workflows/build-visionos.yml` file in GitHub; a ZIP alone does not replace the active workflow. Prefer removing stale extracted project folders/ZIPs to avoid project detector ambiguity.

There is no macOS/visionOS Xcode toolchain here. Local validation is limited to patch-script testing against a synthetic file, source-preservation checks, YAML basic inspection, and ZIP integrity. **Not a verified successful visionOS build or proof of full feature parity.**
