# Build 39C — Direct Project Workflow

This is a narrow CI repair on top of Build 39B.

- Removes the legacy recursive "complete Unity source" discovery/extraction stage.
- Sets PROJECT_DIR directly to the checked-out Build 39 repository root.
- Validates the Build 39 Aether-only files before dependency preparation.
- Preserves Build 39 Aether-only playback, FFmpeg stack, theater handoff, HUD, Media Information and environment changes.
- Does not restore KSPlayer.
