# vBRDC357: Preview Mirror header positioning

Based on vBRDC356 (preserves TVVLCKit removal and Aether/KSPlayer).
Only Preview Mirror: move UP NEXT above both logo animations, keep its label visible even if EPG has no next item, move the clock from transient top-menu navigation into the always-visible top-right of the mirror header, using trailing alignment and a 2-point inset. Search remains a magnifying-glass icon in the revealed top menu. No Vision Pro port in this build.

Validation: Swift syntax parse only; full tvOS Xcode build and Apple TV layout require CI/device verification.
