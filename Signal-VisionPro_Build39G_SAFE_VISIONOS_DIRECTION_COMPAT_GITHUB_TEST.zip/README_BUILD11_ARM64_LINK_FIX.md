# Build 11: original Unity arm64 linker recovery

The uploaded Build 10 GitHub log reached linking after KSPlayer compilation. The x86_64 simulator slice cannot link the included arm64-only Aether/FFmpeg frameworks and libdovi.a.

Only the visionOS Simulator xcodebuild invocation changes: ARCHS=arm64 EXCLUDED_ARCHS=x86_64 ONLY_ACTIVE_ARCH=NO. The visionOS device build remains unchanged. OriginalTVOS_vBRDC357, PortedSource, vendors, and the full Unity target are preserved. No playback behavior, design, feature, membership, or restoration change is claimed.

Replace the old GitHub workflow at `.github/workflows/build-visionos.yml`; upload/extract this full package to your separate Vision Pro repository. GitHub macOS runners can cross-compile arm64 visionOS simulator binaries even if the runner CPU is x86_64. The device build and IPA packaging only run after the simulator build succeeds.

Validation here: structural checks and archive integrity, not Xcode linking or Vision Pro runtime. A further linker error could reveal missing platform slices or a different dependency problem.
