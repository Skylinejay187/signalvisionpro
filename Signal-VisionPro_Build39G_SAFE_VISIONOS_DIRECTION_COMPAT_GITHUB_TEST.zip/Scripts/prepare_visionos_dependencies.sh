#!/bin/bash
set -euo pipefail
if [[ -n "${GITHUB_ENV:-}" ]]; then
  printf 'XCODE_XCCONFIG_FILE=%s\n' "$(pwd)/Scripts/visionos_arm64_all_targets.xcconfig" >> "$GITHUB_ENV"
fi
# Build 39: AetherEngine is Signal's sole internal player. Do not fetch KSPlayer/FFmpegKit.
bash Scripts/fetch_patch_aether_vBRDC242.sh
python3 - <<'PYTHON'
from pathlib import Path
p=Path('Vendor/AetherPlaybackKit/Package.swift')
s=p.read_text()
if '.visionOS(' not in s:
    s=s.replace('        .tvOS(.v17),','        .tvOS(.v17),\n        .visionOS(.v2),')
p.write_text(s)
assert '.visionOS(' in p.read_text()
PYTHON
