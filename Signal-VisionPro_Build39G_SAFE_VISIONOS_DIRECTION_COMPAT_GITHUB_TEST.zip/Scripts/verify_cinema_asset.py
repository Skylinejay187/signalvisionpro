#!/usr/bin/env python3
"""Check asset model topology before expensive native compile (not a USD parser)."""
import re, sys
from pathlib import Path
p=Path(sys.argv[1] if len(sys.argv)>1 else 'Resources/Cinema/CinemaSeat.usda')
s=p.read_text()
assert s.startswith('#usda 1.0'), 'USD header missing'
assert 'defaultPrim = "CinemaSeat"' in s, 'root prim missing'
meshes=re.findall(r'def Mesh "(\w+)"\s*\{(.*?)\n    \}', s,re.S)
assert len(meshes)==7, f'expected seven material mesh groups, got {len(meshes)}'
triangles=0
for name,chunk in meshes:
    f=re.search(r'int\[\] faceVertexCounts = \[(.*?)\]',chunk,re.S)
    i=re.search(r'int\[\] faceVertexIndices = \[(.*?)\]',chunk,re.S)
    v=re.search(r'point3f\[\] points = \[(.*?)\]',chunk,re.S)
    assert f and i and v, f'Incomplete mesh {name}'
    counts=[int(x) for x in re.findall(r'\d+',f.group(1))]
    indices=[int(x) for x in re.findall(r'\d+',i.group(1))]
    vertices=re.findall(r'\([^()]+\)',v.group(1))
    assert counts and all(c==3 for c in counts),f'Invalid triangle topology in {name}'
    assert len(indices)==sum(counts),f'Index count mismatch in {name}'
    assert min(indices)>=0 and max(indices)<len(vertices),f'Index out of bounds in {name}'
    assert f'rel material:binding = </CinemaSeat/Materials/{name}>' in chunk
    triangles+=len(counts)
assert triangles>=5000, 'Model looks like a placeholder rather than detailed geometry'
print(f'PASS: native cinema USDA asset {p}, mesh groups={len(meshes)}, triangles={triangles}')
