#!/bin/bash
set -euo pipefail
ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$ROOT_DIR"
echo "============================================================"
echo "SIGNAL vBRDC358 FAST PREFLIGHT + AETHER-ONLY DEPENDENCY PREP"
echo "============================================================"
# Fail fast on local source/asset mistakes before spending minutes downloading/building dependencies.
mkdir -p .build-cache/actool-preflight
echo "Fast preflight: Swift syntax..."
xcrun swiftc -parse Sources/PlaybackKit/PlaybackKitAetherSurface.swift Sources/AetherPlaybackBridge/AetherPlaybackBridge.swift Sources/DebridChannelsTVOSApp.swift TopShelfExtension/ContentProvider.swift
echo "Fast preflight: tvOS asset catalog/AppIcon..."
rm -rf .build-cache/actool-preflight/*
xcrun actool Resources/Assets.xcassets \
  --compile .build-cache/actool-preflight \
  --platform appletvos \
  --minimum-deployment-target 17.0 \
  --target-device tv \
  --app-icon AppIcon \
  --output-partial-info-plist .build-cache/actool-preflight/asset-info.plist >/dev/null
echo "Fast preflight passed. Preparing AetherEngine-only dependency graph."
bash Scripts/fetch_patch_aether_vBRDC242.sh
echo "AetherEngine-only build dependency prepared."
