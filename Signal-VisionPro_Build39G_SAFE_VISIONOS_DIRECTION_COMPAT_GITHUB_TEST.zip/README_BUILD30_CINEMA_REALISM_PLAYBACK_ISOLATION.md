# Build 30 — Cinema realism + playback isolation + flat catalogs

Physical-device fixes requested after Build 29:
- Restores Home/Movies/Shows catalog rows to the original flat UNITY presentation; Media Information remains the dedicated popup surface.
- Keeps the visionOS Media Information connector line decorative only; popup lifetime is independent of the connector preference/retraction.
- Stops the previous PlaybackKit render/audio session before publishing a replacement playback session to prevent stale simultaneous audio on repeated Live TV/VOD tuning.
- Classic Cinema keeps the working immersive-space architecture, replaces flat unlit architectural materials with lit rough materials, and adds four decorative framed poster panels driven by current Signal catalog artwork.
- Build 27 immersive manifest/scene architecture remains unchanged.

Research basis: Apple's immersive-media guidance emphasizes comfortable screen docking, screen-driven light/reflection, grounding, reverb and environment brightness. SKYBOX exposes seat height, theater light and reflected-light intensity; other Vision Pro cinema apps use selectable seating, house-light dimming and screen light spill. Build 30 begins that direction without replacing Signal's playback engines.
