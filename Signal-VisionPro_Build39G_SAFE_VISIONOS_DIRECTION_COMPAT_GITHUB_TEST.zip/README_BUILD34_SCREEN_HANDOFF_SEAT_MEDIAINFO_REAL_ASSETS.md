# Signal Vision Pro Build 34 — Screen Handoff / Seating / Media Info / Real Assets

Physical-headset fixes based on Build 33 test screenshots.

## Critical fixes
- Fixed the RealityView attachment unit conversion that made the 1920×1080 Signal dashboard only a few millimetres wide. The theater screen now scales the attachment from its ~1.92 m native spatial width to the selected cinema screen width.
- Restored Media Information as the dedicated floating/glass detail layer only. Catalog rows remain flat. The detail compositor foundation is independent of the connector line.
- Seat Lower/Raise now moves in obvious 10 cm steps (±50 cm) and forces a full RealityView rebuild on every row/seat/height change. Default geometry still targets a seated ~1.22 m eye-to-floor relationship.
- Theater playback now stops every prior PlaybackKit session before the immersive AVPlayer takes ownership, instead of stopping only a matching UUID. This targets the remaining doubled audio after failover/retune.
- CC0 resource lookup now tries explicit `.usda` names and every likely bundle subpath, addressing the on-device fallback to the old homemade seats and missing drive-in cars.
- Poster attachments were corrected from microscopic scales to real wall-poster scale.
- Added a distinct Grand Theater theme with an ~10.4 m screen, 11 stepped rows, wider auditorium, stage/proscenium, balcony rails, posters, acoustic modules, surround speakers, exits and stronger readable house lighting.
- Drive-In remains the open-air environment and uses the CC0 sedan asset for parked vehicles when resources load; no oval/capsule cars are the intended path.

## Regression locks
- Build 27 immersive-space scene registration/manifest path remains unchanged.
- Catalog rows remain original Signal/UNITY presentation.
- Existing Apple TV vBRDC357 reference source is untouched.
- KSPlayer/Aether remain the main Signal playback engines outside the RealityKit theater screen handoff.
