# Build 13 — original Unity visionOS architecture recovery

The September 21 Build 12 GitHub run compiled Swift but failed while linking **x86_64 simulator** against arm64-only Aether/FFmpeg libraries. The actual workflow command shown in the log omitted the ARCHS override even though an updated workflow was packaged, and app-only XcodeGen settings did not control transitive SwiftPM dependencies.

Build 13 changes **no Apple TV/Unity/feature Swift source**. It updates:
- Workflow: compile physical visionOS device first; package and upload unsigned IPA before optional arm64-only simulator build. Both xcodebuild commands force ARCHS=arm64 and exclude x86_64 for SwiftPM dependencies.
- Dependency preparation script: exports XCODE_XCCONFIG_FILE via GITHUB_ENV so older workflows also apply arm64 across all Xcode targets, not just SignalVisionPro. This file applies for device as well; both device and arm64 simulator use arm64.
- XcodeGen build number 13.

**Important**: Extract and commit `.github/workflows/build-visionos.yml` itself. Merely committing the full source ZIP will NOT update GitHub's workflow. Replace/remove other old workflow YAML files that trigger a competing build. GitHub Actions > run > expand build command and verify `ARCHS=arm64 EXCLUDED_ARCHS=x86_64` or presence of `XCODE_XCCONFIG_FILE`. This package has not been compiled using Xcode in this environment. The next run may expose other visionOS incompatibilities.
