# Signal Vision Pro — Build 28: cinema + layer repair candidate

**Authoritative base:** the physical-headset-confirmed Build 27 ZIP. Never restore Build 26 scene files or replace the scene manifest. This is a complete GitHub-ready source package, **not** a compiled/signed IPA. GitHub's macOS runner must typecheck/compile it and physical Vision Pro testing remains required.

## Changed in this candidate

- Preserved Build 27's `VisionInfo.plist`, `UIApplicationSceneManifest`, `ImmersiveSpace(id: "signal-theater")`, XcodeGen single-Info.plist authority, and compiled-manifest CI failure gate intact.
- Classic Cinema: relocates viewer away from seats and rear wall, pushes screen forward, repositions the Exit control to a lower right gaze/pinch position, models stage/proscenium, side/back/front walls and ceiling, aisle edges, stepped seating banks, backrests, headrests, seat cushions and armrests. Unlit dark materials provide deterministic low-light colors without bright environmental spotlights or all-black seats.
- Environment choice in Vision Pro / Theater settings: Classic Cinema (default), Home Theater and Drive-In. Choice is remembered; all reuse the single working immersive scene, Signal RootView/player, and exit transition.
- Cinema attaches the original Signal RootView to the screen and **does not** instantiate a second AVPlayer, KSPlayer or AetherEngine. Playback surface compatibility and final audio/video rendering are unverified on headset. No claims of a separately engineered video-material handoff.
- Persistent theater now distinguishes playback-start and playback-end and keeps the environment open when enabled. Standard mode requests window restoration before dismissing the immersive scene.
- Vision Pro media-information popup visibility is now independent of connector-line setting and timeout. The line may retract but the popup stays until the usual Back/Play lifecycle. Apple TV originals have not been modified.
- Catalogs: inset rounded glass shell, stronger gradient edge, floating shadow, preserved Unity catalog contents, fixed z-depth and hit testing. The original Live TV base stays mounted underneath.
- Workflow: pinned KSPlayer/Aether vendor download cache, early Swift syntax parse, existing compiled-plist fail-fast still active. Cache speedup is not yet measured.
- Version updated to build 28; diagnostics identify build 28.

## Device verification (critical)

1. GitHub build succeeds, compiles with original Unity player packages, and compiled manifest check passes. Install via existing sideloading route.
2. Enter Classic Cinema, inspect screen orientation, seat distance, upholstery, glare/brightness, Exit Theater, and UI interaction.
3. Play and exit one VOD and one Live TV stream. Confirm actual video *and audio* render on screen (not just the Signal dashboard). Test 2D return. Test persistent mode separately.
4. Test Home Theater and Drive-In via Vision Pro / Theater settings; then switch back to Classic Cinema.
5. Catalogs should reveal a discrete floating shell around the original rows; confirm no navigation/card coordinate mismatch.
6. Media Information with connector OFF must remain visible indefinitely; with connector ON must remain after the line retracts (~7 seconds). Test Back returns to original catalog scroll position.
7. Export Cinema Diagnostics if any stage fails. Preserve Build 27 IPA as immediate rollback.

**Limits:** Swift syntax and static invariants can be checked here, but an Xcode/visionOS SDK build and physical-headset runtime test cannot run in this environment. Final theater geometry is procedural rather than custom USDZ upholstery models. Additional seat/viewing-position fine tuning may be needed after first in-headset look. Cached builds may still take significant time depending on GitHub runners and first-use dependencies.
