# Build 9 — workflow recovery, full-source compiler bring-up

The supplied build log ends in the OLD Build 3 source detector, before Xcode starts. That workflow rejects the Build 8 original Unity source ZIP. Replace the EXISTING `.github/workflows/build-visionos.yml` with the file in this package. Do not just add the Build 9 ZIP alongside the old YAML: GitHub executes the workflow that already exists at `.github/workflows/build-visionos.yml`.

This full package carries the complete original vBRDC357 source, all 73 original Swift files plus platform adaptation, the original root UI, asset catalog, original pinned player dependency preparation, and strict simulator/device build checks. It is a **source preservation and workflow correction**, NOT a claim that the complete visionOS port compiles or runs. Successful project detection will next expose actual visionOS compiler/dependency errors; download `Original-Unity-visionOS-diagnostics` and supply that artifact for targeted fixes.

To upload from an Android browser: either extract the full package and upload its CONTENTS (including hidden `.github` folder), or upload the full ZIP and separately replace `.github/workflows/build-visionos.yml` with the Build 9 workflow. GitHub will NOT read a workflow embedded inside a ZIP automatically.

No production Apple TV app source files or playback code were modified by Build 9. The theater remains deferred until original Unity feature parity and player functionality are verified.
