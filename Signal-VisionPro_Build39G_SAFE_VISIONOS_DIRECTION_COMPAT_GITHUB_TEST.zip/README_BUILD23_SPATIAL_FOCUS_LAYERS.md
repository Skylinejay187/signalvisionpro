# Signal Vision Pro — Build 23 Spatial Focus Layers

Physical-headset goals from Build 22 feedback:
- Virtual remote/D-pad removed. No remote overlay on Signal.
- Fixed 1600x900 Signal canvas retained; Vision controls are a bottom scene ornament outside the Unity layout so Guide/footer chips are not covered.
- Live TV gaze now owns the actual selected channel identity: looking at a card drives the existing Signal focus ring and settled preview; pinch/tap remains activation/play.
- Live TV page arrows remain explicit gaze/pinch controls for previous/next pages.
- Live TV VOD/playback chips gain gaze highlight ownership.
- Catalogs gain an explicit Up/Down/Left/Right gaze/pinch arrow cluster tied to the currently visible Unity rail, not the removed tvOS virtual remote.
- Playback hides the global Back/Theater ornament. A low-opacity top-right X becomes prominent on gaze and exits playback.
- Theater entry no longer labels a generic openImmersiveSpace .error as a permission denial. Duplicate entry is suppressed and device logging is emitted.
- Persistent Classic Cinema defaults ON for this test build.
- Vision Pro layered AppIcon asset is configured from Signal artwork included in the authoritative package.

## Spatial focus layer foundation
The existing Signal/Unity presentation remains visually authoritative. Build 23 continues the same-window fixed-depth/focus-isolation approach: base Live TV -> catalog -> Media Information. Back unwinds the active Signal state without moving/resizing the app. This avoids redesigning Signal while moving interaction ownership toward visionOS-native gaze targets.

## Physical Vision Pro validation required
1. Look across Live TV cards: ring + preview must follow gaze without pinching; pinch must play only the looked-at card.
2. Test Live TV page arrows and VOD chips.
3. Open Home/Movies/Shows and test catalog arrow cluster + gaze/pinch.
4. Open Media Information and verify actions are gaze-highlightable.
5. Start playback: global Back/Theater controls must disappear; gaze at top-right X and pinch to exit.
6. Enter Classic Cinema and capture [SignalVisionCinema] device log if visionOS still returns .error.
