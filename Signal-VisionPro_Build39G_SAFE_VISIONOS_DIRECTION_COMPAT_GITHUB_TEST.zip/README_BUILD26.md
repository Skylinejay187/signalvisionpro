# Build 26 — On-headset Cinema Diagnostics + focus refinements (test candidate)

Patch base: **Build 25A only**. OriginalTVOS_vBRDC357 retained unchanged; KSPlayer, AetherEngine, original Signal/Unity UI and existing spatial surfaces retained.

## Theater repair hypothesis (not a proven device fix)

Build 25A simultaneously declared a preferred default UIKit immersive scene role, configured an explicit SwiftUI ImmersiveSpace, and requested automatic immersive entry from a restored window. Build 26 removes the extra UIKit preferred-scene routing and automatic window-launch probe. The SwiftUI `ImmersiveSpace(id: "signal-theater")` remains explicitly declared, with its own full immersion style and the existing manually triggered entry button. Multi-scene support remains enabled. This avoids conflicting entry pathways; the headset result is still unknown. The existing cinema geometry, screen and player remain intact.

## No-Mac diagnostic exporter

From normal Signal window: select the bottom **Vision Pro / Theater** control -> **Cinema Diagnostics / Export** -> **Capture scene status** (optional) -> **Prepare diagnostics for sharing** -> **Export Diagnostics**. Use Files/Share Sheet and upload the text file to the chat. Entry errors and immersive scene events are logged to Application Support and survive relaunch. The text view also lets you read/copy event lines without exporting.

The diagnostics capture only explicitly coded app events, system version and the types/activation states of connected app scenes. No source URLs, login tokens, video metadata, or user account fields are intentionally logged. Unlike the macOS Console, this cannot capture private visionOS system messages or the underlying cause beyond the result (`.error`, `.userCancelled`, `.opened`) returned by `openImmersiveSpace`.

## Visual / navigation fixes

- Catalog shell depth increased slightly; a thin outer edge distinguishes it without drawing a shadow under the catalog rows or adding a black rail-sized background.
- Catalog controller now has an enlarged gaze-targetable drag area and a **Move** button to cycle four positions if direct drag is awkward. Its X/Y location persists between sessions. The arrow controls still navigate Signal's original catalogs.
- Media Information, live grid, playback engines, and previous Build 25A functionality preserved.

## First headset test

1. Open Signal's normal window; it should not start an automatic competing immersive request.
2. Open Vision Pro / Theater -> Enter Classic Cinema. Confirm whether actual auditorium, screen and Exit appear.
3. If it fails, use Cinema Diagnostics / Export and upload the resulting TXT file; capture it immediately after the failure if possible.
4. Check Move / drag palette and catalog visual edge. Confirm posters still scroll and pinch-select, and media detail/back still works.

Swift parse + plist validity + archive integrity are **not** an Xcode compile or physical Vision Pro test. No macOS Xcode or headset are available in the editing environment.
