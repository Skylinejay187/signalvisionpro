# Build 22 — Spatial Focus Layer Foundation (physical test candidate)

Source authority: PATCHED FORWARD FROM THE USER-UPLOADED BUILD 21 ZIP ONLY. Build 21 was itself patched from Build 20. OriginalTVOS_vBRDC357 reference tree and full PortedSource retained.

## Changes in this candidate
- Removed the virtual D-pad/control dock from BOTH the normal Signal window and theater attachment.
- Replaced it with compact native Back and top-right playback X, plus Theater settings access away from the old floating remote.
- Added a dedicated Vision Pro theater settings sheet with persistent-cinema preference and explicit Enter/Exit actions.
- Repaired a suspected missing multi-scene configuration: explicit visionOS Info.plist with UIApplicationSceneManifest / UIApplicationSupportsMultipleScenes = true. This is necessary for window + immersive scene; it is not proof of the specific headset failure cause.
- Preserved Build 21's RealityKit cinema shell, screen, 4 seating rows, ceiling/walls, existing playback and dismissal. Better headset validation still required.
- Added previous/next page gaze/pinch Buttons alongside the production Live TV page badge, invoking its existing advanceLiveTVGridPage method.
- On Live TV card hover, hand gaze to EXISTING tileFocus, selectedChannelID, ring animation and preview scheduler. Requires actual device verification of onHover delivery for eye input.
- Turned Media Information Play/Trailer/Find Links/Favorites/Trakt/Alerts into native Buttons wrapping the original Unity visuals.
- Increased underlying catalog/settings accessibility and hit-test isolation while Media Information is open. Existing UNITY three-surface compositor remains intact.

## NOT COMPLETE / NO UNVERIFIED CLAIMS
- This is NOT three separate visionOS system windows. It preserves existing three visually aligned Unity surfaces within one Signal window and begins focus isolation. Independent fixed-window positioning cannot be guaranteed by visionOS.
- Not all VOD chips/Guide/program controls are native gaze targets yet. Native gaze hover and card previews are unverified.
- The immersion permission/entry error is NOT proven resolved; the scene-manifest defect is a plausible root cause and an explicit fix. Full Cinema visual quality and Movie/Show/Live playback in theater are unverified on physical hardware.
- No Xcode or physical Apple Vision Pro are available here. The ZIP is a GitHub source/test candidate only; CI and hardware testing are required.

## Physical test sequence
1. Build with preserved .github/workflows/build-visionos.yml, install.
2. Confirm D-pad is gone, Back unwinds media info to catalog and catalog to Live TV, playback X closes player.
3. Verify look at grid card yields Signal's original ring and preview; pinch plays; page arrows actually switch using original grid logic.
4. Open Theater settings, toggle persistent mode, select Enter Classic Cinema. Capture console output for any remaining openImmersiveSpace failure, and confirm room, screen/player and Exit behavior.
5. Verify media chips gaze/pinch, scroll, existing membership, Trakt, playback, Guide regressions.
