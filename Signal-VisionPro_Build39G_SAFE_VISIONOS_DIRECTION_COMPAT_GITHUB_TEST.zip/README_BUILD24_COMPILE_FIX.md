# Build 24 compile-fix candidate

This package preserves Build 24 behavior and only decomposes the two SwiftUI expressions identified by the GitHub/Xcode 16.4 logs as exceeding the type-checker's complexity budget.

- `LiveTVOverlayControlChip.body` is split into named label/background/border/action helpers.
- `mirrorGridModeChip` is split into a base view and move-command handler.
- No Build 24 theater, Live TV gaze/selection, catalog controls, playback controls, icon, or source architecture was intentionally removed.
- Swift frontend parse check passes in the packaging environment.

Physical Vision Pro behavior still requires the GitHub/Xcode build and headset test.
