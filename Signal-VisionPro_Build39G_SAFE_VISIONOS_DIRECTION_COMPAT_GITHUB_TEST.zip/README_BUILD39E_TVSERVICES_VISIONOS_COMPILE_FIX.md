# Build 39E — TVServices visionOS compile fix

Narrow source compile repair on top of Build 39D.

- `TVServices` is now imported only on tvOS.
- `TVTopShelfContentProvider.topShelfContentDidChange()` is now compiled only on tvOS.
- Apple TV Top Shelf behavior remains intact on tvOS.
- Vision Pro no longer attempts to compile the unavailable TVServices framework.
- No Aether, theater, playback, membership, or UI behavior was otherwise changed.
- Internal project build remains 39; E is the compile-fix package suffix.
