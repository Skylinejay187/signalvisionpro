# Build 39G — safe visionOS direction compatibility

Corrected replacement for broken Build 39F, patched from clean Build 39E.

Instead of mechanically rewriting 20 navigation closures, this build adds a tiny
visionOS-only `MoveCommandDirection` compatibility enum with the same four semantic
cases: up/down/left/right. Existing Signal navigation functions and `.onMoveCommand`
closure structure are otherwise left intact.

tvOS continues to resolve the native SwiftUI `MoveCommandDirection`.
No Aether, theater, playback, membership, or UI architecture changes.
Continue using Universal Workflow v4C.
