# Build 14 — original Unity visionOS navigation API compatibility

The provided Build 13 GitHub diagnostic shows compilation has progressed through the original Unity source and pinned players. The Swift module fails because `MoveCommandDirection` is explicitly unavailable on visionOS in 22 references across original Unity view code and focus managers. The former tvOS `.onMoveCommand` modifier is also replaced at 33 original call sites in the visionOS port.

This build updates **only the PortedSource visionOS copies** to use `SignalMoveDirection` and `.signalMoveCommand`, a visionOS SwiftUI adapter that maps external hardware keyboard arrow presses onto the original routing callbacks. The existing native SwiftUI focus/button selection supports gaze-and-pinch. The adapter does NOT claim to emulate tvOS remote directional commands from hand gestures. No visuals, catalogs, data, membership, restore-code, playback routing, or OriginalTVOS_vBRDC357 source are changed.

The device-first workflow is packaged as `.github/workflows/build-visionos.yml` and must be committed as an extracted file. The previous GitHub run still used an old simulator-first workflow; verify the actual GitHub workflow is replaced. Xcode build and physical Vision Pro functionality remain unverified until GitHub compiles and device testing is performed.
