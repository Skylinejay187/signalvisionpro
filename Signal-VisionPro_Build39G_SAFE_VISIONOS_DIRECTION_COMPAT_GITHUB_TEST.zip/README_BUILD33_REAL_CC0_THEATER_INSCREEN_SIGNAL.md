# Signal Vision Pro — Build 33
## Real CC0 Theater Assets + In-Screen Signal + Media Information Visibility Repair

Build 33 patches forward from Build 32B and preserves the Build 27 immersive-space launch architecture.

### Why Build 32B still looked like the old prototype
Physical Vision Pro screenshots showed the previous hand-built/fallback seats and black oval/box Drive-In placeholders. Build 32B generated the CC0 models under a nested resource path, while the runtime loader searched for bare resource names. Build 33 flattens generated cinema USD resources into `Resources/Cinema` and checks the compiled `.app` for every required asset.

### Real Cinema Multiplex assets
GitHub Actions downloads the CC0 `Cinema Multiplex and Foyer` GLB models from 3DAssets.dev and converts them to static USDA resources before XcodeGen. The Classic Cinema uses the real tiered seating, premium recliner, masked screen, acoustic wall, exit door, side light, projection panel, aisle floor, surround speaker, aisle step and poster-lightbox modules. Resources are validated both before compile and inside the compiled app bundle.

The tier seating geometry is used on every row, including the selected row. Seat/row selection transforms the auditorium so the headset origin occupies a physical chair center rather than an aisle gap.

### Drive-In is no longer built from oval 'spaceship' cars
The workflow also downloads a real CC0 four-door saloon model from the 3DAssets.dev road-vehicle set as `DriveInSedan`. The Drive-In clones this model around the viewer. The old repeated oval car placeholders are gone. A simple box fallback exists only to keep the scene alive if a resource is missing, and the workflow is configured to fail packaging if the real sedan asset is absent.

### Signal actually lives on the cinema screen
When no movie/episode/channel is playing, the physical theater screen now mounts the real Signal `RootView` as a SwiftUI RealityView attachment. Users can browse/select Signal content on the theater screen.

When playback starts, that attachment hides and a dedicated RealityKit `VideoMaterial` plane becomes visible in exactly the same screen location. The embedded RootView is explicitly prevented from instantiating its own KSPlayer/Aether VOD surface, avoiding duplicate audio/video owners. The theater AVPlayer bridge takes ownership only for the RealityKit screen.

The on-screen theater controls provide play/pause, ±15 seconds, return to Signal, exit theater, row selection, seat selection and seat-height adjustment.

### Media Information connector-line bug
On visionOS, Media Information panel visibility is no longer gated by `connectorLineVisible` or `stageBackdropVisible`. `selectedDetail` mounts the panel; only explicit detail dismissal hides it. A stable compositing background is retained so disabling or retracting the decorative connector cannot make the popup pixels disappear while leaving invisible hit targets.

### Catalogs
Catalog Home/Movies/Shows rows remain in the normal Signal/Unity presentation. They are not promoted into Media Information-style popup layers.

### Validation in this package
- Swift frontend syntax parse: `SignalVisionTheater.swift` and `DebridChannelsTVOSApp.swift`
- Python compile: `Scripts/fetch_cinema_assets.py`
- YAML parse: workflow and `project.yml`
- `CURRENT_PROJECT_VERSION = 33`
- GitHub build blocks packaging if required CC0 assets are absent from the compiled `.app`

Physical Vision Pro testing remains authoritative. In particular, verify that the CC0 row seats and road cars are visible, Signal navigation appears on the theater screen when idle, selected media transitions to moving video on the same screen, and Media Information remains visible with its connector disabled and after the connector retracts.
