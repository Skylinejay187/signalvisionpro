# Build 25 — Theater visibility/lifecycle repair and spatial-layer surfaces

Base: user-tested Build 24B ONLY. OriginalTVOS_vBRDC357 is unmodified.

## Theater analysis and changes
The previous room was laid out with the floor at y=-1.75m, the movie screen at y=0.35m, and the sole Exit Theater button at y=-0.72m. visionOS immersive world origin is initially at the viewer’s feet, so the most important controls were below the floor and the screen lay below the natural eyeline. Build 25 raises the floor to foot level, the screen to seated eye height, and exit controls to reachable/visible chest height. The stage logs its creation. The full heavy RootView mounts only after an initial visible black cinema title appears.

The default immersive scene is declared first, preferred immersive role and full style remain in the app manifest, and a ONE-TIME auto-entry attempt is added for existing/restored window sessions that bypass the fresh-launch scene. When the immersive scene actually appears, its window is dismissed to prevent two simultaneously mounted players; exit reopens the 2D window before dismissing the immersive scene. If visionOS refuses entry (e.g. another app already owns the full space), we cannot bypass that system constraint: fetch device logs. No ARKit permissions were added.

## Three spatial focus layers
One fixed Signal window composites three distinct named SwiftUI surfaces with original layout, view instances, styling, and Z order (0/6/12-point depth separation): permanently mounted Live TV base, retained Home/Movies/Shows catalog, and Media Information. A layer view modifier gates each subtree's hit-testing and accessibility to the actual top state. Only the top surface receives input. Back continues removing Media Information then the catalog using existing store/navigation so previous row position persists. These are NOT separate movable visionOS system windows; system windows cannot be reliably locked in pixel-perfect registration.

## Navigation refinements
Grid drag sensitivity changed from 170x155 to 122x112 points and minimum distance 24 to 14. The app-added duplicate native hover effect on grid cards was suppressed; Signal's actual focus ring remains. visionOS system-controlled gaze/pinch affordances cannot be guaranteed to disappear. Catalog arrow cluster now has a dedicated drag handle and bounded movable position so it need not obstruct posters.

## Physical acceptance tests
1. Fully quit/reopen Signal. Check whether cinema appears and the screen is centered at comfortable eye height.
2. If it shows a 2D window, wait one second for the automatic entry; inspect [SignalVisionCinema][Build25] logs if entry fails.
3. Use Exit Theater, ensure the normal window returns. Re-enter from Vision Pro / Theater settings.
4. Check catalog arrows reposition via its hand icon, gaze-select & hold-drag sensitivity, and Media Info -> Back -> catalog -> Back -> Live TV.
5. Check movie/show/live playback and observe whether entering Theater restarts the source; avoid declaring seamless playback until physically tested.

NO Xcode/visionOS SDK or physical headset in editing environment: Swift parse, plist and archive tests are NOT a successful device build or proof theater works. If scene entry still fails, collect full device log lines for the [SignalVisionCinema] tag and the corresponding OS immersive-space error.
