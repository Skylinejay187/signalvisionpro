# Build 39D — Aether visionOS / Xcode 16.4 compile fix

Narrow compile repair on top of Build 39C.

- Preserves Build 39 Aether-only theater handoff and UI/runtime changes.
- Fixes AetherEngine 6.89.1 SampleBufferRenderer for Xcode 16.4 visionOS compilation.
- The patch generated during dependency preparation no longer emits `preferredDynamicRange` for visionOS/tvOS.
- Aether's other HDR/display-criteria path remains unchanged.
- Uses a new vendor marker so a stale prepared Aether vendor cannot bypass the fix.
- Internal CURRENT_PROJECT_VERSION remains 39; D is the compile-fix package suffix.
