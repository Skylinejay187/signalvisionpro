# Signal Vision Pro — Build 38

## Playback destination / single-owner architecture

Build 38 is patched only from the supplied Build 37 source. The Build 27 immersive-space registration is a regression lock: `signal-theater`, `VisionInfo.plist`, scene manifest arrangement and app launch scene registration were not rewritten.

### Build 37 audit findings

1. `SignalVisionTheaterVideoBridge` created a brand-new `AVPlayer`, stopped `PlaybackController.shared`, released auxiliary playback, reopened the selected URL, and became a second playback implementation rather than a presentation handoff. This discarded KSPlayer/AetherEngine ownership and was a primary architecture risk for choppy playback, lost engine state, duplicate/restarted decode work and audio transitions.
2. Theater entry dismissed `signal-main`. `VODPlayerScreen.onDisappear` is intentionally an authoritative teardown path for many player tasks, observers, alternate-audio state and PlaybackKit ownership, so closing the window fought the requested "same playback/session" theater model and made exact return-state restoration fragile.
3. Build 37's theater HUD called the theater-only AVPlayer directly for transport while Production/Ratings and Spotlight settings were only AppStorage toggles. It did not route transport through the original VOD overlay/player methods.
4. The RealityView still contained a dormant `signal-app-screen` path from the older "Signal inside theater" design even though no corresponding attachment was supplied.
5. Drive-In implementation and build assets were still present despite the current environment lock removing Drive-In.
6. Screen-size/height/tilt changes were part of the RealityView identity/rebuild path, causing expensive environment reconstruction for adjustments that can be applied to existing entities.
7. Theater poster selection was separated by a stride but deterministic from the same catalog offset each launch.
8. Build 37 used a RealityKit `VideoMaterial` fed by the new AVPlayer. This could not preserve KSPlayer/AetherEngine and therefore could not satisfy single-owner playback.

### Build 38 changes

- Removed the theater-owned URL/AVPlayer takeover completely.
- Added `SignalVisionPlaybackHandoff`, a process-level presentation bridge that references the active Signal session and never opens media itself.
- KSPlayer and AetherEngine can register their existing UIKit render surface with PlaybackKit. The existing `PlaybackPersistentRenderHostView` is temporarily mounted into the immersive cinema-screen attachment and restored to its original anchor on theater exit.
- AVFoundation theater fallback reuses the already-created Signal `AVPlayer`; it does not create another AVPlayer or audio owner.
- The normal Signal window remains alive during immersive playback. This preserves VOD overlay state, Media Information return state, selected media, catalog/row/scroll state and the active playback session instead of forcing teardown/reconstruction.
- Added an `Enter Theater` Vision Pro ornament while playback is active.
- Theater transport commands now route back into `VODPlayerScreen`'s existing `togglePlay`, `seekRelative`, audio/subtitle selection and player-dismissal logic. Production/Ratings and Spotlight Hub continue using the original VOD settings/state rather than a replacement overlay implementation.
- HUD position remains persisted; HUD now shows shared playback engine and progress state. Exit Theater returns the render surface without ending playback; Exit Playback invokes Signal's normal player dismissal.
- Removed Drive-In source, generated-asset requirements and environment catalog entry.
- Poster frames now use a per-theater-entry randomized catalog offset plus separated stride; artwork only, no title captions.
- Reduced avoidable RealityView rebuilds: tilt, screen size and screen height update existing entities instead of forcing a full environment reload. Lighting changes still rebuild because the generated point-light intensities are construction-time values.
- GitHub Actions now caches converted CC0 cinema assets and adds Build 38 regression gates before the expensive Xcode build.
- Build/version identifier is `CURRENT_PROJECT_VERSION = 38`.

### Apple / open-source architecture research

Apple Destination Video uses `AVPlayerViewController` full-window playback plus `DockingRegionComponent` for system docking, and supports media reflections, virtual environment probes and reverb. That architecture is excellent when AVPlayerViewController is the playback owner. Signal, however, must preserve KSPlayer/AetherEngine for its established playback compatibility. Build 38 therefore adopts the *single playback owner + separate immersive presentation destination* principle without replacing KS/Aether with an unrelated AVPlayer. System DockingRegion/video-reflection features are intentionally not forced onto KS/Aether because doing so would require a second AVPlayer or a decoder replacement.

OpenImmersive/OpenImmersiveLib was reviewed as a useful example of keeping playback state/controller ownership separate from immersive rendering and controls. It was not imported as a dependency because its player architecture would replace rather than preserve Signal's KSPlayer/AetherEngine session.

The current 3DAssets.dev Cinema Multiplex and Foyer source explicitly identifies its pack as CC0 1.0 Universal. Build 38 continues using only the existing free/CC0 asset pipeline and does not bundle the future Free3D premium theater.

### Validation performed in this package

- Swift parser check passed for every modified Swift source and the large app root.
- Brace/structure checks passed.
- Build 27 scene/plist regression files are byte-identical to Build 37 (`VisionInfo.plist` and `Info.plist`).
- `signal-theater` scene registration block is unchanged.
- Drive-In strings/assets are absent from current theater source, catalog, fetch script and workflow.
- Workflow contains a strict device Xcode build, compiled Info.plist verification and Build 38 regression gates.

### Physical Vision Pro verification required

Compilation cannot prove headset behavior. On device, verify: KSPlayer and Aether playback continue without restart when entering theater; exactly one audio path is audible; the reused surface renders correctly as a RealityView attachment; AVPlayer fallback renders without audio duplication; screen scale/aspect is comfortable in every environment; HUD remains reachable at Front/Middle/Back and Left/Center/Right; audio/subtitle cycling affects the active stream; Production/Ratings and Spotlight settings affect the original VOD overlay state; exiting theater restores the exact Signal player/UI state; ending playback exits immersive space cleanly; lighting and seat transforms are comfortable at human scale; and long playback no longer develops the Build 37 choppiness.
