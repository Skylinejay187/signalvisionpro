# Signal Vision Pro Build 39 — AetherEngine-Only Theater Handoff

Build 39 patches forward from Build 38B and ports the proven vBRDC358B AetherEngine-only playback architecture.

- AetherEngine is the sole linked internal player; KSPlayer/KSPNUVIO is removed from the project/dependency graph.
- Aether's namespaced FFmpegBuild stack is prepared by the same vBRDC358B dependency path.
- The existing Aether render surface is retained as the single decoder/audio owner and mounted into the immersive theater presentation; the theater does not reopen the URL or create a second player.
- The duplicate AVPlayer fallback theater surface is removed.
- The regular Vision Pro ornament disappears while immersive theater is active; no in-theater Enter Theater button.
- Pre-entry theater settings sheet is removed. Environment, seat, screen, lighting and HUD controls are inside the theater HUD.
- Theater HUD defaults to compact transport controls and expands only for theater configuration. HUD offset remains persistent and the panel is draggable.
- Poster attachments remain catalog-backed and empty poster layouts receive poster placements.
- Build 27 immersive-space ID/registration architecture is preserved.

Physical Vision Pro testing remains authoritative, especially Aether video presentation on the architectural theater screen, return-state preservation, HUD ergonomics and environment scale/material quality.
