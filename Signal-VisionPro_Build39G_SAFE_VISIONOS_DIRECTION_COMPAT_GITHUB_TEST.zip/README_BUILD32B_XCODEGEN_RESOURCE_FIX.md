# Signal Vision Pro Build 32B — XcodeGen Resource Fix

Build 32B is a compile-pipeline repair for the Build 32 failure reported from GitHub Actions.

## Root cause from the uploaded log
XcodeGen aborted before Swift compilation because `project.yml` listed `Resources/Cinema/CC0` as a required source/resource directory, but that generated directory did not exist in the extracted ZIP used by the older workflow. ZIP archives do not preserve empty directories.

## Fix
- `project.yml` now includes the stable `Resources/Cinema` parent directory as the resource source.
- The generated `CC0` directory can be created later and its files are included recursively when present.
- The Build 32 workflow also explicitly creates `Resources/Cinema/CC0` before fetching/converting cinema assets.
- No theater, playback, Media Information, catalog, or Build 27 immersive-launch logic was changed in this repair.

This build is intended to get past the XcodeGen `missing source directory .../Resources/Cinema/CC0` failure before we evaluate any later compiler/runtime issues.
