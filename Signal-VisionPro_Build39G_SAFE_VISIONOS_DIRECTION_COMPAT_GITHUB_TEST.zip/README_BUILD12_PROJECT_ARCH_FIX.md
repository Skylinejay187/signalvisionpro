# Build 12 — project-enforced visionOS arm64

The latest log extracted the Build 11 source ZIP but executed an older repository-level GitHub workflow. Its simulator xcodebuild command omitted ARCHS=arm64 and EXCLUDED_ARCHS=x86_64; Xcode consequently built both arm64 and x86_64, and the x86_64 link rejected the pinned arm64-only Aether/FFmpeg and libdovi libraries.

This build writes ARCHS=arm64 and EXCLUDED_ARCHS=x86_64 into the root and app target build settings of project.yml, so XcodeGen configures them even when the invoking workflow omits architecture overrides. It also updates the bundled workflow to check resolved architectures before compilation and to prefer Build 12 ZIP archives. No feature/UI/player code, vendor code, or original tvOS source was changed.

**Install:** Replace the existing .github/workflows/build-visionos.yml with this package's workflow explicitly, and commit the extracted full Build 12 project (or upload its complete ZIP for the workflow to extract). The workflow at repository root takes precedence over the workflow inside a source ZIP.

**Limitations:** No macOS/Xcode environment here; compilation, device IPA, and runtime remain unverified. This fixes the demonstrated architecture mismatch, not any later unresolved link or platform incompatibility.
