# Build 17 — SwiftUI type-check segmentation (compile candidate)

Based directly on full Build 16 Unity source. The latest Actions log reached the app and found eight `unable to type-check this expression in reasonable time` diagnostics in `DebridChannelsTVOSApp.swift` at Build 16 lines 6729, 12290, 15127, 16369, 16693, 17065, 36892 and 54493. The changed file extracts heavyweight SwiftUI builder branches into private `some View` helpers, preserving their visual content, event handlers and data flow; the `OriginalTVOS_vBRDC357` tree and players are unchanged.

This is not an Xcode-verified build. Run GitHub Actions and attach diagnostic logs for any remaining Swift compiler problems.
