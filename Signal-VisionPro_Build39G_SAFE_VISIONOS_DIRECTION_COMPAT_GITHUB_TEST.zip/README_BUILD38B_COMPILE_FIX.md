# Signal Vision Pro — Build 38B Compile Fix

Source lineage: Build 37 -> Build 38 -> Build 38B compile-only repair.

## GitHub Actions failure fixed
The Build 38 workflow reached Swift compilation and failed in:

`PortedSource/PlaybackKit/PlaybackKitAetherSurface.swift`

The `Coordinator` declaration accidentally contained two consecutive `@MainActor` global-actor attributes. Swift rejects a declaration with multiple global actor attributes, even when both attributes are identical.

Build 38B removes only the duplicate annotation and leaves one `@MainActor` on the Coordinator.

## Intentionally unchanged
- Build 38 playback-destination/single-owner architecture
- KSPlayer/AetherEngine handoff behavior
- Build 27 immersive-space registration/configuration lock
- theater environments and Drive-In removal
- VOD HUD/overlay routing
- Info.plist / VisionInfo.plist scene configuration
- app build/version identifiers (still Build 38)

The KSPlayer actor-isolation diagnostics shown earlier in the same GitHub log are warnings under the workflow's current Swift language mode and were not the cause of this failed build.
