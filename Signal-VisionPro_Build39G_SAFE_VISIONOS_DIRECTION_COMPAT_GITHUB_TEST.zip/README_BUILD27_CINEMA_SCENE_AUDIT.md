# Build 27 — actual compiled scene manifest verification

Base: Build 26 only. Existing Signal Unity source, navigation layers, playback, and diagnostics are retained.

Observed device evidence: Build 26 diagnostics showed `multiple=false` and `openImmersiveSpace` returned `.error`. This establishes a bundle/runtime discrepancy, **not** a proven Signulous modification or a proven complete cause of the failure.

Changes:
- Remove the conflicting XcodeGen `targets.SignalVisionPro.info` declaration so `PortedSource/VisionInfo.plist` is the one explicit Info.plist source (`GENERATE_INFOPLIST_FILE=NO`).
- Explicitly include the `UISceneConfigurations` empty dictionary and Boolean `UIApplicationSupportsMultipleScenes=true` in that plist.
- Validate source plist before Xcode project generation; validate **compiled** `Release-xros/SignalVisionPro.app/Info.plist` after building. Fail GitHub action before IPA packaging if either differs.
- Save compiled manifest result to the GitHub diagnostics artifact.
- In-app export now shows missing/invalid versus false scene setting and installed build number.

**Test:** Run the GitHub build. Only sideload the resulting IPA if the new compiled-manifest validation step passes. On Vision Pro open Cinema Diagnostics and capture status; check for `multiple=true`, then retry theater entry. If entry still returns `.error`, export fresh diagnostics for further scene investigation. The theater is NOT verified until the physical headset opens it.

No changes to Apple TV originals, membership, KSPlayer, or AetherEngine. No Mac or physical headset validation was available in this environment.
