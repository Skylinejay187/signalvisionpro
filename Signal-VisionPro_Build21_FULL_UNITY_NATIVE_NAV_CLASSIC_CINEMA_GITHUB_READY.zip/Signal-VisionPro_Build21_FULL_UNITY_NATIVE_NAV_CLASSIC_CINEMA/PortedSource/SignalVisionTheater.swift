import SwiftUI
import RealityKit

@MainActor
final class SignalVisionTheaterCoordinator: ObservableObject {
    static let shared = SignalVisionTheaterCoordinator()
    enum Mode: String { case app, playback }
    @Published var mode: Mode = .app
    @Published var immersiveActive = false
    @Published var transitionInProgress = false
    @Published var entryFailure: String?
    private init() {}
}

enum SignalVisionRemoteEvent {
    static let direction = Notification.Name("SignalVision.Remote.Direction")
    static let back = Notification.Name("SignalVision.Remote.Back")
    static let home = Notification.Name("SignalVision.Remote.Home")
}

struct SignalVisionControlDock: View {
    @EnvironmentObject private var store: CatalogStore
    @EnvironmentObject private var unityCore: UnityAppCore
    @EnvironmentObject private var theater: SignalVisionTheaterCoordinator
    @Environment(\.openImmersiveSpace) private var openImmersiveSpace
    @Environment(\.dismissImmersiveSpace) private var dismissImmersiveSpace
    @State private var controlsAwake = true
    @State private var fadeTask: Task<Void, Never>?

    private var playbackActive: Bool { store.playbackURL != nil }
    private var dockOpacity: Double { playbackActive && !controlsAwake ? 0.10 : 0.92 }

    var body: some View {
        VStack(spacing: 12) {
            if let failure = theater.entryFailure {
                Text(failure).font(.caption).foregroundStyle(.orange)
                    .accessibilityLabel("Theater entry failed: \(failure)")
            }
            HStack(spacing: 12) {
                theaterButton(mode: .app, icon: "theatermasks.fill", label: "App Theater")
                if playbackActive {
                    theaterButton(mode: .playback, icon: "film.fill", label: "Playback Theater")
                }
            }

            // Native direct selection bypasses the unreliable forwarded tvOS move command.
            // These controls manipulate the original Unity store/core rather than a second app.
            HStack(spacing: 6) {
                ForEach([AppTab.live, .home, .movies, .shows, .settings], id: \.self) { tab in
                    Button(tab.rawValue) {
                        wakeControls()
                        guard store.playbackURL == nil else { return }
                        store.searchActive = false
                        store.selectedDetail = nil
                        unityCore.select(tab, store: store, reason: "visionOS direct native tab")
                    }
                    .buttonStyle(.bordered)
                    .hoverEffect(.highlight)
                    .accessibilityLabel("Open \(tab.rawValue)")
                }
            }
            ZStack {
                Circle().fill(.black.opacity(0.52)).frame(width: 210, height: 210)
                remoteButton("chevron.up", direction: .up).offset(y: -70)
                remoteButton("chevron.down", direction: .down).offset(y: 70)
                remoteButton("chevron.left", direction: .left).offset(x: -70)
                remoteButton("chevron.right", direction: .right).offset(x: 70)
                Circle().fill(.white.opacity(0.13)).frame(width: 82, height: 82)
            }
            .contentShape(Circle())
            .hoverEffect(.lift)

            HStack(spacing: 18) {
                commandButton("arrow.backward", title: "Back") {
                    goBack()
                }
                commandButton("house.fill", title: "Home") {
                    goHome()
                }
            }
        }
        .padding(18)
        .background(.ultraThinMaterial, in: RoundedRectangle(cornerRadius: 28, style: .continuous))
        .opacity(dockOpacity)
        .scaleEffect(playbackActive && !controlsAwake ? 0.78 : 1)
        .animation(.easeInOut(duration: 0.28), value: dockOpacity)
        .onHover { hovering in
            if hovering { wakeControls() }
        }
        .onAppear { scheduleFadeIfNeeded() }
        .onChange(of: playbackActive) { _ in scheduleFadeIfNeeded() }
        .accessibilityLabel("Signal Vision Pro navigation controls")
    }

    private func goHome() {
        if store.playbackURL != nil { store.closePlayer(); return }
        store.searchActive = false
        store.selectedDetail = nil
        store.liveQuickPanelOpen = false
        unityCore.select(.live, store: store, reason: "visionOS direct home")
    }

    private func goBack() {
        // Keep view-local exit handlers available, but do not require an invisible
        // tvOS focus target for the common detail/search/player unwind paths.
        if store.playbackURL != nil { store.closePlayer(); return }
        if store.selectedDetail != nil {
            if let previous = store.detailBackStack.popLast() {
                store.selectedDetail = previous
            } else {
                store.selectedDetail = nil
            }
            return
        }
        if store.searchActive { store.searchActive = false; return }
        if store.liveQuickPanelOpen { store.liveQuickPanelOpen = false; return }
        NotificationCenter.default.post(name: SignalVisionRemoteEvent.back, object: nil)
    }

    private func wakeControls() {
        controlsAwake = true
        scheduleFadeIfNeeded()
    }

    private func scheduleFadeIfNeeded() {
        fadeTask?.cancel()
        guard playbackActive else { controlsAwake = true; return }
        fadeTask = Task { @MainActor in
            try? await Task.sleep(nanoseconds: 3_500_000_000)
            guard !Task.isCancelled else { return }
            controlsAwake = false
        }
    }

    private func post(_ direction: SignalMoveDirection) {
        wakeControls()
        NotificationCenter.default.post(name: SignalVisionRemoteEvent.direction, object: direction)
    }

    private func remoteButton(_ icon: String, direction: SignalMoveDirection) -> some View {
        Button { post(direction) } label: {
            Image(systemName: icon).font(.system(size: 30, weight: .bold)).frame(width: 62, height: 62)
        }
        .buttonStyle(.plain)
        .contentShape(Circle())
        .hoverEffect(.lift)
    }

    private func commandButton(_ icon: String, title: String, action: @escaping () -> Void) -> some View {
        Button { wakeControls(); action() } label: {
            VStack(spacing: 5) {
                Image(systemName: icon).font(.system(size: 23, weight: .semibold))
                Text(title).font(.caption2.weight(.semibold))
            }
            .frame(width: 82, height: 58)
        }
        .buttonStyle(.bordered)
        .hoverEffect(.lift)
    }

    private func theaterButton(mode: SignalVisionTheaterCoordinator.Mode, icon: String, label: String) -> some View {
        Button {
            wakeControls()
            guard !theater.transitionInProgress else { return }
            Task { @MainActor in
                theater.transitionInProgress = true
                defer { theater.transitionInProgress = false }
                theater.entryFailure = nil
                if theater.immersiveActive {
                    await dismissImmersiveSpace()
                    theater.immersiveActive = false
                }
                theater.mode = mode
                let result = await openImmersiveSpace(id: "signal-theater")
                switch result {
                case .opened:
                    theater.immersiveActive = true
                    // Retain the real Signal window: dismissing it tears down its
                    // presentation and can break the same-session playback lifecycle.
                    // Immersive space is foregrounded by the system when opened.
                case .userCancelled:
                    theater.entryFailure = "Theater entry was cancelled. Try again."
                case .error:
                    theater.entryFailure = "Theater did not open. Check immersive-space permission and retry."
                @unknown default:
                    theater.entryFailure = "Unknown theater entry result."
                }
            }
        } label: {
            Label(label, systemImage: icon).font(.caption.weight(.semibold)).padding(.horizontal, 10).frame(height: 36)
        }
        .disabled(theater.transitionInProgress)
        .buttonStyle(.borderedProminent)
        .hoverEffect(.lift)
    }
}

struct SignalVisionTheaterSpace: View {
    @EnvironmentObject private var store: CatalogStore
    @EnvironmentObject private var unityCore: UnityAppCore
    @EnvironmentObject private var theater: SignalVisionTheaterCoordinator
    @Environment(\.dismissImmersiveSpace) private var dismissImmersiveSpace
    @Environment(\.openWindow) private var openWindow

    var body: some View {
        RealityView { content, attachments in
            let floor = ModelEntity(mesh: .generateBox(size: [9, 0.08, 9]), materials: [SimpleMaterial(color: .darkGray, isMetallic: false)])
            floor.position = [0, -1.75, -3.4]
            content.add(floor)

            let ceiling = ModelEntity(mesh: .generateBox(size: [9, 0.08, 9]), materials: [SimpleMaterial(color: .black, isMetallic: false)])
            ceiling.position = [0, 3.08, -3.4]
            content.add(ceiling)

            let backWall = ModelEntity(mesh: .generateBox(size: [9, 5.2, 0.08]), materials: [SimpleMaterial(color: .black, isMetallic: false)])
            backWall.position = [0, 0.45, -6.0]
            content.add(backWall)

            let leftWall = ModelEntity(mesh: .generateBox(size: [0.08, 5.2, 9]), materials: [SimpleMaterial(color: .black, isMetallic: false)])
            leftWall.position = [-4.45, 0.45, -2.0]
            content.add(leftWall)
            let rightWall = leftWall.clone(recursive: true)
            rightWall.position.x = 4.45
            content.add(rightWall)

            let screenBacking = ModelEntity(mesh: .generateBox(size: [5.9, 3.45, 0.08]), materials: [SimpleMaterial(color: .black, isMetallic: false)])
            screenBacking.position = [0, 0.35, -5.72]
            content.add(screenBacking)

            // Empty center aisle and an unobstructed position around the viewer.
            // Physical geometry remains intentionally non-colliding.
            for row in 0..<4 {
                for seat in [-4, -3, -2, -1, 1, 2, 3, 4] {
                    let chair = ModelEntity(mesh: .generateBox(size: [0.62, 0.62, 0.62]), materials: [SimpleMaterial(color: .darkGray, isMetallic: false)])
                    chair.position = [Float(seat) * 0.82, -1.38, Float(row) * 1.0 - 0.1]
                    content.add(chair)
                }
            }

            if let controls = attachments.entity(for: "signal-controls") {
                // A separately anchored control surface ~1.1 m away, not a tiny
                // target baked into the 5.6 m distant screen.
                controls.position = [0, -0.72, -1.15]
                content.add(controls)
            }
            if let screen = attachments.entity(for: "signal-screen") {
                screen.position = [0, 0.35, -5.62]
                screen.scale = [0.00305, 0.00305, 0.00305]
                content.add(screen)
            }
        } attachments: {
            Attachment(id: "signal-screen") {
                RootView()
                    .environmentObject(store)
                    .environmentObject(unityCore)
                    .frame(width: 1600, height: 900)
                    .clipped()
                .background(.black)
                .clipShape(RoundedRectangle(cornerRadius: 18))
            }
            Attachment(id: "signal-controls") {
                VStack(spacing: 10) {
                    Button("Exit Theater", systemImage: "rectangle.portrait.and.arrow.right") {
                        Task { @MainActor in
                            await dismissImmersiveSpace()
                            theater.immersiveActive = false
                            openWindow(id: "signal-main")
                        }
                    }
                    .buttonStyle(.borderedProminent)
                    SignalVisionControlDock()
                        .environmentObject(store)
                        .environmentObject(unityCore)
                        .environmentObject(theater)
                }
                .padding(16)
                .background(.ultraThinMaterial, in: RoundedRectangle(cornerRadius: 22))
            }
        }
        .onDisappear { theater.immersiveActive = false }
        .onChange(of: store.playbackURL) { url in
            guard theater.mode == .playback, url == nil else { return }
            Task { @MainActor in
                await dismissImmersiveSpace()
                theater.immersiveActive = false
                openWindow(id: "signal-main")
            }
        }
    }
}
