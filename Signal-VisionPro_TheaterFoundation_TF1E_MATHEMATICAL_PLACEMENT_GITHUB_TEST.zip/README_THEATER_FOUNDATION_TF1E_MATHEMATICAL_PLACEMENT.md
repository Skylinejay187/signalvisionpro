# Theater Foundation TF1E — Mathematical Placement Rebuild

TF1E replaces the previous guessed auditorium offsets with a model-space placement profile derived from the purchased theater source files.

## Root cause fixed

The purchased model is already authored at usable physical scale after its FBX/glTF hierarchy transforms are resolved. Seat rows are about 1.96 m apart. TF1B–TF1D multiplied the entire auditorium by 0.25, compressing that spacing to about 0.49 m. That made a normal seated viewpoint effectively impossible and is why physical Vision Pro testing repeatedly landed inside seat geometry.

TF1E removes the 0.25 scale entirely. The imported auditorium stays at 1.00×.

## Measured placement

- auditorium: ~33.33 m wide × 36.60 m deep × 14.98 m high
- screen: ~18.94 m wide × 9.12 m high
- screen direction in source space: +Z
- measured middle rows: z 0.238 m and 2.198 m
- collision-free gap between those seat backs: approximately z 0.692–1.744 m
- canonical eye point: x 0.544, y 2.65, z 1.218 m (center of the right-hand middle chair, ~0.55 m from auditorium centerline)

The canonical eye point is positioned at a real center-chair x coordinate but in the safe eye-volume ahead of its backrest, rather than inside the seat mesh.

## Device-pose calibration

TF1E starts an ARKit WorldTrackingProvider after the Full Space opens, queries the current Vision Pro device pose, and creates a fixed theater spawn frame:

- root position = actual current device position
- root yaw = actual horizontal device forward direction
- source +Z = theater screen direction
- imported theater position = negative canonical eye point

The theater does not follow head movement after calibration. `Recenter Theater to Me` repeats the calibration deliberately.

## Regression locks

- no floating Signal dashboard
- no second movie/app screen
- purchased architectural screen remains the single `CinemaScreen`
- no AVPlayer or VideoMaterial playback path added
- no whole-auditorium screen-size scaling
- seat controls are constrained to the measured safe gap
- controller is parented to the calibrated theater frame so it spawns near the wearer

Physical Vision Pro testing remains authoritative.
