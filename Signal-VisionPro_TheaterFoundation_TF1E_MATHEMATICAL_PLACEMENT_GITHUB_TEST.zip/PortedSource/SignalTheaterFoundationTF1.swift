#if os(visionOS)
import SwiftUI
import RealityKit
import ARKit
import QuartzCore
import UIKit

@MainActor
private final class TF1DevicePoseTracker {
    static let shared = TF1DevicePoseTracker()

    private let session = ARKitSession()
    private let worldTracking = WorldTrackingProvider()
    private var sessionStarted = false

    func startIfNeeded() async {
        guard !sessionStarted else { return }
        guard WorldTrackingProvider.isSupported else {
            print("[TF1E] WorldTrackingProvider unsupported; using deterministic fallback frame")
            return
        }
        sessionStarted = true
        do {
            try await session.run([worldTracking])
        } catch {
            sessionStarted = false
            print("[TF1E] World tracking failed: \(error)")
        }
    }

    func currentDevicePose() -> simd_float4x4? {
        guard worldTracking.state == .running else { return nil }
        guard let anchor = worldTracking.queryDeviceAnchor(atTimestamp: CACurrentMediaTime()), anchor.isTracked else {
            return nil
        }
        return anchor.originFromAnchorTransform
    }
}

@MainActor
final class SignalTheaterFoundationState: ObservableObject {
    static let shared = SignalTheaterFoundationState()

    @Published var lighting: Float = 0.32
    @Published var screenScale: Float = 1.0
    @Published var screenHeight: Float = 0.0
    // Offsets from the measured, collision-free canonical eye point in the purchased model.
    @Published var seatDepth: Float = 0.0
    @Published var seatHeight: Float = 0.0
    @Published var tabletX: Float = 0.72
    @Published var tabletY: Float = -0.08
    @Published var tabletZ: Float = 1.05
    @Published var tabletVisible = true
    @Published var recenterRevision: Int = 0
    var lastAppliedRecenterRevision: Int = 0

    func resetView() {
        lighting = 0.32
        screenScale = 1.0
        screenHeight = 0.0
        seatDepth = 0.0
        seatHeight = 0.0
    }

    func resetTablet() {
        tabletX = 0.72
        tabletY = -0.08
        tabletZ = 1.05
        persistTablet()
    }

    func loadTablet() {
        let d = UserDefaults.standard
        guard d.object(forKey: "tf1e.tablet.x") != nil else { return }
        tabletX = d.float(forKey: "tf1e.tablet.x")
        tabletY = d.float(forKey: "tf1e.tablet.y")
        tabletZ = d.float(forKey: "tf1e.tablet.z")
    }

    func persistTablet() {
        let d = UserDefaults.standard
        d.set(tabletX, forKey: "tf1e.tablet.x")
        d.set(tabletY, forKey: "tf1e.tablet.y")
        d.set(tabletZ, forKey: "tf1e.tablet.z")
    }

    func requestRecenter() {
        recenterRevision &+= 1
    }
}

struct SignalTheaterFoundationBootstrap: View {
    @Environment(\.openImmersiveSpace) private var openImmersiveSpace
    @Environment(\.dismissWindow) private var dismissWindow
    @State private var requested = false

    var body: some View {
        // This window exists only long enough to request the immersive space.
        // It must never become a second application/movie screen in the theater.
        Color.clear
            .frame(width: 1, height: 1)
            .task {
                guard !requested else { return }
                requested = true
                let result = await openImmersiveSpace(id: "signal-theater-foundation")
                if case .opened = result {
                    dismissWindow(id: "signal-main")
                }
            }
    }
}

struct SignalTheaterFoundationSpace: View {
    @StateObject private var state = SignalTheaterFoundationState.shared
    @State private var dragStartX: Float?
    @State private var dragStartY: Float?

    var body: some View {
        RealityView { content, attachments in
            let room = await TF1CinemaFactory.makeCinema()
            if let tablet = attachments.entity(for: "theater-tablet") {
                tablet.name = "TF1PersonalTablet"
                tablet.position = [state.tabletX, state.tabletY, state.tabletZ]
                // TF1E room-local +Z points toward the cinema screen. Turn the
                // tablet back toward the wearer while keeping it in that same frame.
                tablet.orientation = simd_quatf(angle: .pi, axis: [0, 1, 0])
                room.addChild(tablet)
            }
            content.add(room)
        } update: { content, attachments in
            if let room = content.entities.first(where: { $0.name == "TF1Cinema" }) {
                TF1CinemaFactory.update(room: room, state: state)
            }
            if let tablet = attachments.entity(for: "theater-tablet") {
                tablet.position = [state.tabletX, state.tabletY, state.tabletZ]
                tablet.orientation = simd_quatf(angle: .pi, axis: [0, 1, 0])
                tablet.isEnabled = state.tabletVisible
            }
        } attachments: {
            Attachment(id: "theater-tablet") {
                TF1TheaterTablet(state: state)
                    .frame(width: 620, height: 560)
                    .glassBackgroundEffect(in: RoundedRectangle(cornerRadius: 38))
                    .gesture(
                        DragGesture(minimumDistance: 0)
                            .onChanged { value in
                                if dragStartX == nil {
                                    dragStartX = state.tabletX
                                    dragStartY = state.tabletY
                                }
                                let sx = dragStartX ?? state.tabletX
                                let sy = dragStartY ?? state.tabletY
                                state.tabletX = sx + Float(value.translation.width) * 0.0015
                                state.tabletY = sy - Float(value.translation.height) * 0.0015
                            }
                            .onEnded { _ in
                                dragStartX = nil
                                dragStartY = nil
                                state.persistTablet()
                            }
                    )
            }
        }
        .onAppear { state.loadTablet() }
        .task { await calibrateTheaterToDevice() }
    }

    @MainActor
    private func calibrateTheaterToDevice() async {
        // Run world tracking only after the Full Space is active. Apple documents
        // queryDeviceAnchor for this exact device-relative placement use case.
        await TF1DevicePoseTracker.shared.startIfNeeded()
        for _ in 0..<40 {
            if TF1DevicePoseTracker.shared.currentDevicePose() != nil {
                state.requestRecenter()
                return
            }
            try? await Task.sleep(nanoseconds: 50_000_000)
        }
    }
}

private struct TF1TheaterTablet: View {
    @ObservedObject var state: SignalTheaterFoundationState
    @State private var section = "Room"

    var body: some View {
        VStack(spacing: 0) {
            HStack {
                VStack(alignment: .leading, spacing: 2) {
                    Text("SIGNAL").font(.system(size: 18, weight: .black))
                    Text("THEATER CONTROL").font(.caption).foregroundStyle(.secondary)
                }
                Spacer()
                Image(systemName: "move.3d").font(.title2)
                Text("Grab to move").font(.caption).foregroundStyle(.secondary)
            }
            .padding(24)

            Divider()

            HStack(alignment: .top, spacing: 0) {
                VStack(spacing: 10) {
                    TF1Tab("Room", icon: "theatermasks", selected: $section)
                    TF1Tab("Seat", icon: "chair.lounge", selected: $section)
                    TF1Tab("Screen", icon: "rectangle.inset.filled", selected: $section)
                    TF1Tab("Lighting", icon: "lightbulb", selected: $section)
                    Spacer()
                }
                .frame(width: 155)
                .padding(14)

                Divider()

                ScrollView {
                    VStack(alignment: .leading, spacing: 20) {
                        Text(section).font(.title2.bold())
                        if section == "Room" {
                            LabeledContent("Environment", value: "Classic Cinema")
                            Text("TF1 is a clean theater foundation. Signal UI and playback are intentionally not loaded.")
                                .font(.callout).foregroundStyle(.secondary)
                            Text("Full-scale 1.00× • measured seat geometry • device-pose calibrated")
                                .font(.caption).foregroundStyle(.secondary)
                            Button("Recenter Theater to Me") { state.requestRecenter() }
                                .buttonStyle(.borderedProminent)
                            Button("Reset Theater Controls") { state.resetView() }
                        } else if section == "Seat" {
                            TF1Slider(title: "Seat forward / back", value: $state.seatDepth, range: -0.35...0.35)
                            TF1Slider(title: "Seat height offset", value: $state.seatHeight, range: -0.35...0.45)
                            Text("Movement is constrained to the measured open gap between the two center seat rows.")
                                .font(.caption).foregroundStyle(.secondary)
                            Button("Center Seat") { state.seatDepth = 0; state.seatHeight = 0 }
                        } else if section == "Screen" {
                            LabeledContent("Cinema screen", value: "Purchased architectural screen")
                            Text("Screen transform controls stay locked until TF2 binds Signal to this exact screen surface.")
                                .font(.callout).foregroundStyle(.secondary)
                        } else {
                            TF1Slider(title: "House lights", value: $state.lighting, range: 0.08...1.0)
                        }

                        Divider()
                        Text("Tablet Position").font(.headline)
                        TF1Slider(title: "Distance", value: $state.tabletZ, range: 0.65 ... 1.8)
                        Button("Reset Tablet Position") { state.resetTablet() }
                    }
                    .padding(24)
                }
            }
        }
        .background(.black.opacity(0.22))
    }
}

private struct TF1Tab: View {
    let title: String
    let icon: String
    @Binding var selected: String
    init(_ title: String, icon: String, selected: Binding<String>) {
        self.title = title; self.icon = icon; self._selected = selected
    }
    var body: some View {
        Button { selected = title } label: {
            HStack { Image(systemName: icon); Text(title); Spacer() }
                .frame(maxWidth: .infinity)
        }
        .buttonStyle(.bordered)
        .tint(selected == title ? .primary : .secondary)
    }
}

private struct TF1Slider: View {
    let title: String
    @Binding var value: Float
    let range: ClosedRange<Float>
    var body: some View {
        VStack(alignment: .leading, spacing: 8) {
            HStack { Text(title); Spacer(); Text(String(format: "%.2f", value)).monospacedDigit().foregroundStyle(.secondary) }
            Slider(value: $value, in: range)
        }
    }
}

@MainActor
private enum TF1CinemaFactory {
    // TF1B uses the purchased Fab theater as the room itself. Nothing from the old
    // Signal theater implementation is instantiated here.
    static func makeCinema() async -> Entity {
        let root = Entity(); root.name = "TF1Cinema"

        guard let imported = loadFabCinema() else {
            let marker = ModelEntity(
                mesh: .generateBox(size: [3.6, 1.8, 0.08]),
                materials: [SimpleMaterial(color: .init(red: 0.35, green: 0.02, blue: 0.02, alpha: 1), isMetallic: false)]
            )
            marker.name = "TF1FabAssetLoadFailure"
            marker.position = [0, 0.25, -4.0]
            root.addChild(marker)
            return root
        }

        imported.name = "FabMovieTheaterEnvironment"

        // TF1E uses the authored meter scale. The source hierarchy already contains
        // the FBX centimeter conversion (0.01) and per-object compensation (100), so
        // its resolved glTF/USD geometry is physically sized: ~33.3 m wide, ~36.6 m
        // deep, with ~1.96 m seat-row spacing and a ~18.94 m screen. The old 0.25×
        // scale compressed rows to ~0.49 m and is the reason previous builds buried
        // the wearer inside the seats. Never rescale the auditorium here.
        imported.scale = [1, 1, 1]
        imported.orientation = simd_quatf(angle: 0, axis: [0, 1, 0])
        imported.position = -canonicalEyePoint
        root.addChild(imported)

        // The root is a fixed spawn frame. Its +Z axis is aligned once to the
        // wearer's forward direction; the theater itself does NOT follow head motion.
        applyFallbackSpawnFrame(to: root)

        addHouseLights(to: imported)

        // Restyle only the seat hierarchy. This leaves the purchased architecture,
        // screen, curtain, speakers and wall materials intact.
        if let seats = findEntity(namedLike: "seats", under: imported) {
            applyBlackSeatMaterial(to: seats)
        }

        // These are semantic anchors, not additional screens. TF2 will bind Signal to
        // the purchased model's screen mesh; TF3 will switch that SAME target to Aether.
        if let sourceScreen = findEntity(namedLike: "screen", under: imported) {
            sourceScreen.name = "CinemaScreen"
        }

        // Poster anchors are empty in TF1B. Later builds can populate them dynamically
        // with authorized Signal catalog artwork without baking copyrighted posters.
        let posterLeft = Entity(); posterLeft.name = "SignalPosterAnchorLeft"; posterLeft.position = [-12.0, 4.0, 18.6]
        let posterRight = Entity(); posterRight.name = "SignalPosterAnchorRight"; posterRight.position = [12.0, 4.0, 18.6]
        imported.addChild(posterLeft); imported.addChild(posterRight)

        return root
    }

    // Measured from the original purchased glTF after applying its authored node
    // transforms. Source +Z points toward the architectural screen.
    // Seat rows are centered at z = -7.602, -5.642, -3.682, -1.722, 0.238,
    // 2.198, 4.158, 6.118, 8.078 m. The center gap between the 0.238 and
    // 2.198 rows is collision-free from about z 0.692 through 1.744 m.
    // x = 0.544 is the center of the right-hand middle chair, only ~0.55 m from
    // the auditorium centerline, so the wearer is actually seated in a chair rather
    // than mathematically between two chair meshes.
    private static let canonicalEyePoint = SIMD3<Float>(0.544, 2.65, 1.218)

    static func update(room: Entity, state: SignalTheaterFoundationState) {
        guard let environment = room.findEntity(named: "FabMovieTheaterEnvironment") else { return }

        // Keep the purchased theater at its authored physical scale and orientation.
        // Seat controls move only the canonical eye point inside the measured safe
        // inter-row gap; they never move/scale the auditorium arbitrarily.
        environment.scale = .one
        environment.orientation = simd_quatf(angle: 0, axis: [0, 1, 0])
        let eye = canonicalEyePoint + SIMD3<Float>(0, state.seatHeight, state.seatDepth)
        environment.position = -eye

        if state.recenterRevision != state.lastAppliedRecenterRevision {
            if applyCurrentDeviceSpawnFrame(to: room) {
                state.lastAppliedRecenterRevision = state.recenterRevision
            }
        }

        updateHouseLights(in: room, level: state.lighting)
    }

    private static func applyFallbackSpawnFrame(to root: Entity) {
        // Deterministic fallback for the brief interval before device pose is available:
        // source +Z (the cinema screen direction) maps to RealityKit -Z.
        root.position = .zero
        root.orientation = simd_quatf(angle: .pi, axis: [0, 1, 0])
    }

    @discardableResult
    private static func applyCurrentDeviceSpawnFrame(to root: Entity) -> Bool {
        guard let pose = TF1DevicePoseTracker.shared.currentDevicePose() else { return false }

        let devicePosition = SIMD3<Float>(pose.columns.3.x, pose.columns.3.y, pose.columns.3.z)
        let rawForward = SIMD3<Float>(-pose.columns.2.x, 0, -pose.columns.2.z)
        let length = simd_length(rawForward)
        guard length > 0.0001 else { return false }
        let forward = rawForward / length

        // A Y-only rotation keeps the theater level while mapping the model's +Z
        // (toward the screen) to the wearer's actual horizontal forward direction.
        let yaw = atan2f(forward.x, forward.z)
        root.position = devicePosition
        root.orientation = simd_quatf(angle: yaw, axis: [0, 1, 0])
        return true
    }

    private static func addHouseLights(to parent: Entity) {
        let specs: [(String, SIMD3<Float>, UIColor, Float, Float)] = [
            ("TF1HouseLightFront", [0, 8.0, 14.0], UIColor(red: 0.72, green: 0.78, blue: 0.88, alpha: 1), 8000, 20.0),
            ("TF1HouseLightCenter", [0, 8.0, 2.0], UIColor(red: 0.86, green: 0.72, blue: 0.58, alpha: 1), 6500, 20.0),
            ("TF1HouseLightLeft", [-11.0, 6.0, 1.5], UIColor(red: 1.0, green: 0.58, blue: 0.30, alpha: 1), 4500, 16.0),
            ("TF1HouseLightRight", [11.0, 6.0, 1.5], UIColor(red: 1.0, green: 0.58, blue: 0.30, alpha: 1), 4500, 16.0),
            ("TF1HouseLightRear", [0, 8.0, -10.0], UIColor(red: 0.68, green: 0.72, blue: 0.80, alpha: 1), 5000, 18.0)
        ]
        for (name, position, color, intensity, radius) in specs {
            let light = Entity()
            light.name = name
            light.position = position
            light.components.set(PointLightComponent(
                color: color,
                intensity: intensity,
                attenuationRadius: radius,
                attenuationFalloffExponent: 2.0
            ))
            parent.addChild(light)
        }
    }

    private static func updateHouseLights(in root: Entity, level: Float) {
        let clamped = max(0.08, min(1.0, level))
        let specs: [(String, UIColor, Float, Float)] = [
            ("TF1HouseLightFront", UIColor(red: 0.72, green: 0.78, blue: 0.88, alpha: 1), 8000, 20.0),
            ("TF1HouseLightCenter", UIColor(red: 0.86, green: 0.72, blue: 0.58, alpha: 1), 6500, 20.0),
            ("TF1HouseLightLeft", UIColor(red: 1.0, green: 0.58, blue: 0.30, alpha: 1), 4500, 16.0),
            ("TF1HouseLightRight", UIColor(red: 1.0, green: 0.58, blue: 0.30, alpha: 1), 4500, 16.0),
            ("TF1HouseLightRear", UIColor(red: 0.68, green: 0.72, blue: 0.80, alpha: 1), 5000, 18.0)
        ]
        for (name, color, baseIntensity, radius) in specs {
            guard let light = root.findEntity(named: name) else { continue }
            light.components.set(PointLightComponent(
                color: color,
                intensity: baseIntensity * clamped,
                attenuationRadius: radius,
                attenuationFalloffExponent: 2.0
            ))
        }
    }

    private static func loadFabCinema() -> Entity? {
        let candidates = [
            "SignalFabMovieTheater",
            "SignalFabMovieTheater.usdz",
            "Cinema/SignalFabMovieTheater",
            "Cinema/SignalFabMovieTheater.usdz"
        ]
        for candidate in candidates {
            if let entity = try? Entity.load(named: candidate, in: .main) { return entity }
        }
        return nil
    }

    private static func findEntity(namedLike needle: String, under entity: Entity) -> Entity? {
        if entity.name.localizedCaseInsensitiveContains(needle) { return entity }
        for child in entity.children {
            if let match = findEntity(namedLike: needle, under: child) { return match }
        }
        return nil
    }

    private static func applyBlackSeatMaterial(to entity: Entity) {
        if let model = entity as? ModelEntity, var component = model.model {
            let count = max(1, component.materials.count)
            let charcoal = SimpleMaterial(
                color: .init(red: 0.025, green: 0.027, blue: 0.030, alpha: 1),
                roughness: 0.72,
                isMetallic: false
            )
            component.materials = Array(repeating: charcoal, count: count)
            model.model = component
        }
        for child in entity.children { applyBlackSeatMaterial(to: child) }
    }
}

#endif // os(visionOS)
