# Build 35 — Hybrid realistic environments + CC0 starter scenes + premium-ready catalog

Build 35 keeps the Build 27 immersive-space launch path and builds each free theater theme from coherent CC0 real-world-scale assets plus Signal-specific custom dressing.

## Free environments

- Classic Cinema — full Cinema Multiplex and Foyer starter scene + Signal poster art, screen-light, aisle glow and screen handoff.
- Grand Theater — full Theatre Stage and Backstage playhouse starter scene + cinema masking and Signal movie presentation.
- Home Theater — furnished living-room starter scene + dedicated cinema wall, recliners and acoustic/light treatment.
- Private Screening Room — compact luxury room using premium cinema recliners, residential dressing and custom Signal lighting.
- Drive-In — roadside diner/motel concession environment + multiple distinct CC0 road cars + custom giant screen and speaker posts.
- Rooftop Cinema — CC0 rooftop terrace modules + lounge seating, guardrails, string lights and custom screen.
- Retro Palace — playhouse architecture re-dressed as a red/gold movie palace with Signal poster lightboxes.
- Abandoned Cinema — complete Abandoned Cinema and Projection Booth starter scene with Signal playback surface.
- Cruise Deck Cinema — Cruise Ship Deck and Lounge starter scene adapted as an outdoor deck cinema.

All 3DAssets.dev resources used here are CC0 1.0 Universal and fetched during GitHub Actions from their permanent CDN URLs. The workflow fails if a required converted USD resource is absent from the compiled app.

## Future $0.99 premium environment

The requested Free3D “Movie Theater Interior” is intentionally NOT bundled. Build 35 reserves product ID `signal.vision.theater.premium.movieinterior` and suggested end-user price `$0.99` only. The asset should be enabled after purchase and after its raw files are converted/protected for in-app use. Free3D's Royalty Free License allows inclusion inside an interactive creation but restricts redistribution of the raw model in an open/extractable format.
