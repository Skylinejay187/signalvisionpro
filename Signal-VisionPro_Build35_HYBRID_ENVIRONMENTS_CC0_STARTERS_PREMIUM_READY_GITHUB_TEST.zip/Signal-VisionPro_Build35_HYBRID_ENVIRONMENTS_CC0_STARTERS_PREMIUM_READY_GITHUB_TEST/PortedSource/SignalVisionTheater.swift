import SwiftUI
import RealityKit
import UIKit
import AVFoundation

@MainActor
final class SignalVisionTheaterCoordinator: ObservableObject {
    static let shared = SignalVisionTheaterCoordinator()
    enum Mode: String { case app, playback }
    @Published var mode: Mode = .app
    @Published var immersiveActive = false
    @Published var transitionInProgress = false
    @Published var entryFailure: String?
    var didAttemptAutomaticEntry = false
    private init() {}
}


@MainActor
final class SignalVisionTheaterVideoBridge: ObservableObject {
    let player = AVPlayer()
    private var activeURL: URL?
    private var ownershipSessionID: UUID?

    init() {
        player.automaticallyWaitsToMinimizeStalling = true
        player.actionAtItemEnd = .pause
    }

    func takeOwnership(
        url: URL?,
        headers: [String: String],
        sessionID: UUID,
        diagnostics: SignalVisionDiagnostics
    ) {
        guard let url else {
            stop(reason: "no playback URL", diagnostics: diagnostics)
            return
        }
        if activeURL == url, player.currentItem != nil {
            if player.rate == 0 { player.play() }
            return
        }

        _ = AuxiliaryVideoPlaybackCoordinator.shared.releaseAll(reason: "Vision Pro RealityKit theater ownership")
        // Hard single-owner barrier. A stale PlaybackKit decoder can carry an older UUID
        // after retune/failover, so stop every active PlaybackKit session before the
        // theater AVPlayer is allowed to become audible.
        PlaybackController.shared.stop()
        diagnostics.record("playback", "Build35 stopped all prior PlaybackKit owners before RealityKit AVPlayer takeover")

        player.pause()
        player.replaceCurrentItem(with: nil)
        let options: [String: Any]? = headers.isEmpty ? nil : ["AVURLAssetHTTPHeaderFieldsKey": headers]
        let asset = AVURLAsset(url: url, options: options)
        let item = AVPlayerItem(asset: asset)
        player.replaceCurrentItem(with: item)
        activeURL = url
        ownershipSessionID = sessionID
        player.play()
        diagnostics.record("playback", "Build35 RealityKit VideoMaterial owner started url=\(url.absoluteString)")
    }

    func togglePlayback() {
        if player.rate == 0 { player.play() } else { player.pause() }
    }

    func seek(delta: Double) {
        let seconds = max(0, player.currentTime().seconds + delta)
        guard seconds.isFinite else { return }
        player.seek(to: CMTime(seconds: seconds, preferredTimescale: 600))
    }

    func stop(reason: String, diagnostics: SignalVisionDiagnostics) {
        player.pause()
        player.replaceCurrentItem(with: nil)
        activeURL = nil
        ownershipSessionID = nil
        diagnostics.record("playback", "Build35 RealityKit theater owner stopped reason=\(reason)")
    }
}

enum SignalVisionRemoteEvent {
    static let direction = Notification.Name("SignalVision.Remote.Direction")
    static let back = Notification.Name("SignalVision.Remote.Back")
    static let home = Notification.Name("SignalVision.Remote.Home")
    static let catalogDirection = Notification.Name("SignalVision.Catalog.Direction")
}

/// Build 32: the Build 27 immersive-space registration/launch path remains untouched.
/// This pass rebuilds the environment around a SEATED viewer coordinate system:
/// eye origin ~= y 0, selected seat centered around the user, floor ~1.22 m below eye level.
/// Classic Cinema, Home Theater and Drive-In are intentionally separate environments.
struct SignalVisionTheaterSpace: View {
    @EnvironmentObject private var store: CatalogStore
    @EnvironmentObject private var unityCore: UnityAppCore
    @EnvironmentObject private var theater: SignalVisionTheaterCoordinator
    @Environment(\.dismissImmersiveSpace) private var dismissImmersiveSpace
    @Environment(\.openWindow) private var openWindow
    @Environment(\.dismissWindow) private var dismissWindow

    @AppStorage("signalVisionPersistentTheaterV22") private var persistentTheater = true
    @AppStorage("signalVisionCinemaEnvironmentV28") private var cinemaEnvironment = "Classic Cinema"
    @AppStorage("signalVisionCinemaSeatRowV31") private var cinemaSeatRow = "Middle"
    @AppStorage("signalVisionCinemaSeatPositionV31") private var cinemaSeatPosition = "Center"
    @AppStorage("signalVisionCinemaSeatHeightV31") private var cinemaSeatHeight: Double = 0.0

    @State private var cinemaScreenReady = false
    @State private var seatingRevision: Int = 0
    @StateObject private var cinemaVideo = SignalVisionTheaterVideoBridge()
    private let diagnostics = SignalVisionDiagnostics.shared

    private struct PosterPlacement {
        let id: String
        let position: SIMD3<Float>
        let yaw: Float
        let scale: Float
    }

    private struct TheaterLayout {
        let screenPosition: SIMD3<Float>
        let screenScale: Float
        let controlsPosition: SIMD3<Float>
        let posters: [PosterPlacement]
    }

    var body: some View {
        let currentLayout = theaterLayout
        let identity = "Build35-\(cinemaEnvironment)-\(cinemaSeatRow)-\(cinemaSeatPosition)-\(Int((cinemaSeatHeight * 100).rounded()))-r\(seatingRevision)"
        RealityView { content, attachments in
            diagnostics.record("reality", "Build35 \(cinemaEnvironment) real-asset seated environment construction started")
            let environment = makeEnvironment()
            environment.name = "signal-environment-root"
            content.add(environment)

            // Native RealityKit video surface. It owns pixels only while playbackURL exists.
            // The normal Signal UI is a separate SwiftUI attachment on the same physical screen.
            let size = videoScreenSize
            let videoMaterial = VideoMaterial(avPlayer: cinemaVideo.player)
            let videoScreen = ModelEntity(
                mesh: .generatePlane(width: size.x, height: size.y, cornerRadius: 0.035),
                materials: [videoMaterial]
            )
            videoScreen.name = "signal-realitykit-video-screen"
            videoScreen.position = currentLayout.screenPosition
            videoScreen.isEnabled = store.playbackURL != nil
            content.add(videoScreen)

            if let dashboard = attachments.entity(for: "signal-app-screen") {
                dashboard.name = "signal-theater-app-screen"
                dashboard.position = currentLayout.screenPosition + SIMD3<Float>(0, 0, 0.014)
                let scale = dashboardScreenScale
                dashboard.scale = [scale, scale, scale]
                dashboard.isEnabled = store.playbackURL == nil
                content.add(dashboard)
            }

            if let controls = attachments.entity(for: "signal-controls") {
                controls.name = "signal-theater-controls"
                controls.position = currentLayout.controlsPosition
                controls.scale = [1.05, 1.05, 1.05]
                content.add(controls)
            }

            for posterPlacement in currentLayout.posters {
                if let poster = attachments.entity(for: posterPlacement.id) {
                    poster.position = posterPlacement.position
                    poster.orientation = simd_quatf(angle: posterPlacement.yaw, axis: [0, 1, 0])
                    poster.scale = [posterPlacement.scale, posterPlacement.scale, posterPlacement.scale]
                    content.add(poster)
                }
            }

            diagnostics.record(
                "reality",
                "Build35 theme=\(cinemaEnvironment) row=\(cinemaSeatRow) seat=\(cinemaSeatPosition) height=\(cinemaSeatHeight) screen=\(currentLayout.screenPosition)"
            )
        } update: { content, attachments in
            let playing = store.playbackURL != nil
            if let videoScreen = content.entities.first(where: { $0.name == "signal-realitykit-video-screen" }) {
                videoScreen.isEnabled = playing
                videoScreen.position = currentLayout.screenPosition
            }
            if let dashboard = attachments.entity(for: "signal-app-screen") {
                dashboard.isEnabled = !playing
                dashboard.position = currentLayout.screenPosition + SIMD3<Float>(0, 0, 0.014)
                let scale = dashboardScreenScale
                dashboard.scale = [scale, scale, scale]
            }
            if let controls = attachments.entity(for: "signal-controls") {
                controls.position = currentLayout.controlsPosition
                // Keep transport buttons available during video, but never let them sit on seats.
                controls.isEnabled = true
            }
        } attachments: {
            // Build 33: full Signal navigation lives on the theater screen while idle.
            // Its own VODPlayerScreen is disabled by visionPlaybackSurfaceAllowed; when the
            // user chooses media the attachment hides and the native VideoMaterial takes over.
            Attachment(id: "signal-app-screen") {
                RootView(visionTheaterSurface: true)
                    .frame(width: 1920, height: 1080)
                    .clipped()
                    .background(Color.black)
            }

            Attachment(id: "cinema-poster-0") { cinemaPoster(index: 0) }
            Attachment(id: "cinema-poster-1") { cinemaPoster(index: 1) }
            Attachment(id: "cinema-poster-2") { cinemaPoster(index: 2) }
            Attachment(id: "cinema-poster-3") { cinemaPoster(index: 3) }
            Attachment(id: "cinema-poster-4") { cinemaPoster(index: 4) }
            Attachment(id: "cinema-poster-5") { cinemaPoster(index: 5) }

            Attachment(id: "signal-controls") {
                VStack(spacing: 10) {
                    HStack(spacing: 10) {
                        if store.playbackURL != nil {
                            Button("Back 15", systemImage: "gobackward.15") { cinemaVideo.seek(delta: -15) }
                            Button("Play / Pause", systemImage: "playpause.fill") { cinemaVideo.togglePlayback() }
                            Button("Forward 15", systemImage: "goforward.15") { cinemaVideo.seek(delta: 15) }
                        }
                        Button(store.playbackURL == nil ? "Signal Screen" : "Back to Signal", systemImage: "rectangle.inset.filled") {
                            if store.playbackURL != nil {
                                store.closePlayer()
                            }
                        }
                        Button("Exit Theater", systemImage: "xmark.circle.fill") {
                            Task { @MainActor in
                                cinemaVideo.stop(reason: "user exited theater", diagnostics: diagnostics)
                                openWindow(id: "signal-main")
                                theater.immersiveActive = false
                                try? await Task.sleep(nanoseconds: 160_000_000)
                                await dismissImmersiveSpace()
                                diagnostics.record("lifecycle", "Build35 exit control dismissed immersive space")
                            }
                        }
                    }
                    HStack(spacing: 10) {
                        Button("Row: \(cinemaSeatRow)") { cycleSeatRow() }
                        Button("Seat: \(cinemaSeatPosition)") { cycleSeatPosition() }
                        Button("Lower") { adjustSeatHeight(by: -0.10) }
                        Button("Raise") { adjustSeatHeight(by: 0.10) }
                        Text("\(Int((cinemaSeatHeight * 100).rounded())) cm")
                            .font(.caption.monospacedDigit())
                    }
                }
                .font(.system(size: 16, weight: .semibold))
                .buttonStyle(.bordered)
                .padding(12)
                .background(.ultraThinMaterial, in: RoundedRectangle(cornerRadius: 20))
            }
        }
        .id(identity)
        .onAppear {
            theater.immersiveActive = true
            theater.transitionInProgress = false
            theater.entryFailure = nil
            theater.didAttemptAutomaticEntry = true
            diagnostics.record("lifecycle", "Build35 immersive scene onAppear")
            diagnostics.sceneSnapshot("immersive-appeared")

            if let url = store.playbackURL {
                cinemaVideo.takeOwnership(
                    url: url,
                    headers: store.playbackHTTPHeaders,
                    sessionID: store.playbackPresentationID,
                    diagnostics: diagnostics
                )
            }

            // Build 27 regression lock: the main window closes only after immersive entry.
            dismissWindow(id: "signal-main")
            Task { @MainActor in
                try? await Task.sleep(nanoseconds: 350_000_000)
                guard theater.immersiveActive else { return }
                cinemaScreenReady = true
                diagnostics.record("lifecycle", "Build35 RealityKit cinema screen ready")
            }
        }
        .onDisappear {
            cinemaVideo.stop(reason: "immersive scene disappeared", diagnostics: diagnostics)
            theater.immersiveActive = false
            cinemaScreenReady = false
            diagnostics.record("lifecycle", "Build35 immersive scene onDisappear")
            diagnostics.sceneSnapshot("immersive-disappeared")
        }
        .onChange(of: store.playbackURL) { url in
            if let url {
                theater.mode = persistentTheater ? .app : .playback
                cinemaVideo.takeOwnership(
                    url: url,
                    headers: store.playbackHTTPHeaders,
                    sessionID: store.playbackPresentationID,
                    diagnostics: diagnostics
                )
                diagnostics.record("lifecycle", "Build35 playback URL handed to RealityKit cinema screen")
                return
            }
            cinemaVideo.stop(reason: "store playback ended", diagnostics: diagnostics)
            guard theater.mode == .playback else { return }
            if persistentTheater {
                theater.mode = .app
                return
            }
            Task { @MainActor in
                openWindow(id: "signal-main")
                await dismissImmersiveSpace()
                theater.immersiveActive = false
            }
        }
    }

    private var videoScreenSize: SIMD2<Float> {
        switch cinemaEnvironment {
        case "Home Theater": return [4.40, 2.475]
        case "Private Screening Room": return [5.40, 3.0375]
        case "Drive-In": return [8.80, 4.95]
        case "Rooftop Cinema": return [6.60, 3.7125]
        case "Grand Theater": return [10.40, 4.39]
        case "Retro Palace": return [7.80, 3.29]
        case "Abandoned Cinema": return [5.60, 3.15]
        case "Cruise Deck Cinema": return [6.80, 3.825]
        default: return [5.20, 2.25]
        }
    }


    private var dashboardScreenScale: Float {
        // SwiftUI RealityView attachments are already spatially sized. A 1920pt
        // attachment is about 1.92m wide before scaling. Build 33 divided by 1920
        // again, shrinking the whole Signal UI to only a few millimetres.
        videoScreenSize.x / 1.92
    }

    private func cycleSeatRow() {
        switch cinemaSeatRow {
        case "Front": cinemaSeatRow = "Middle"
        case "Middle": cinemaSeatRow = "Back"
        default: cinemaSeatRow = "Front"
        }
        seatingRevision &+= 1
    }

    private func cycleSeatPosition() {
        switch cinemaSeatPosition {
        case "Left": cinemaSeatPosition = "Center"
        case "Center": cinemaSeatPosition = "Right"
        default: cinemaSeatPosition = "Left"
        }
        seatingRevision &+= 1
    }

    private func adjustSeatHeight(by delta: Double) {
        // Ten-centimetre steps are intentionally obvious on-headset. Rebuilding the
        // RealityView guarantees the entire room/screen moves around the fixed head origin.
        cinemaSeatHeight = min(0.50, max(-0.50, cinemaSeatHeight + delta))
        seatingRevision &+= 1
        diagnostics.record("seating", "Build35 seat height changed to \(Int((cinemaSeatHeight * 100).rounded()))cm")
    }

    private var environmentSymbol: String {
        switch cinemaEnvironment {
        case "Home Theater": return "house.fill"
        case "Private Screening Room": return "sofa.fill"
        case "Drive-In": return "car.fill"
        case "Rooftop Cinema": return "building.2.crop.circle"
        case "Grand Theater": return "building.columns.fill"
        case "Retro Palace": return "sparkles.rectangle.stack"
        case "Abandoned Cinema": return "film.stack.fill"
        case "Cruise Deck Cinema": return "ferry.fill"
        default: return "theatermasks.fill"
        }
    }

    private var seatHeightOffset: Float { Float(cinemaSeatHeight) }

    private var classicSelectedRowIndex: Int {
        switch cinemaSeatRow {
        case "Front": return 1
        case "Back": return 5
        default: return 3
        }
    }

    private var homeSelectedRowIndex: Int {
        switch cinemaSeatRow {
        case "Front": return 0
        case "Back": return 2
        default: return 1
        }
    }

    private var driveSelectedRowIndex: Int {
        switch cinemaSeatRow {
        case "Front": return 0
        case "Back": return 2
        default: return 1
        }
    }

    private var classicSelectedSeatX: Float {
        // CC0 tier row has four seats on a 0.75 m pitch. Two 3.08 m modules meet
        // at the auditorium center; the nearest real chair centers are ±0.415 m.
        // Center therefore means the inner-right physical chair, not the aisle seam.
        switch cinemaSeatPosition {
        case "Left": return -1.915
        case "Right": return 1.915
        default: return 0.415
        }
    }

    private var homeSelectedSeatX: Float {
        // Premium recliner row uses a 1 m pitch with an actual center chair.
        switch cinemaSeatPosition {
        case "Left": return -1.0
        case "Right": return 1.0
        default: return 0
        }
    }

    /// Positions are derived from the SAME canonical geometry used by the builders,
    /// so the screen and wall art move with the selected physical seat instead of
    /// leaving the viewer standing in an aisle or floating above a row.
    private var theaterLayout: TheaterLayout {
        let yShift = -seatHeightOffset
        switch cinemaEnvironment {
        case "Home Theater":
            let canonicalRows: [Float] = [-1.45, 0.10, 1.65]
            let row = homeSelectedRowIndex
            let zShift = 0.18 - canonicalRows[row]
            let xShift = -homeSelectedSeatX
            let screenZ: Float = -5.55 + zShift
            return TheaterLayout(
                screenPosition: [xShift, 0.12 + yShift, screenZ + 0.035],
                screenScale: 0.00285,
                controlsPosition: [0.0, -0.47, -1.05],
                posters: [
                    PosterPlacement(id: "cinema-poster-0", position: [-3.47 + xShift, 0.45 + yShift, -1.30 + zShift], yaw: .pi / 2, scale: 1.65),
                    PosterPlacement(id: "cinema-poster-1", position: [ 3.47 + xShift, 0.45 + yShift, -1.30 + zShift], yaw: -.pi / 2, scale: 1.65)
                ]
            )

        case "Drive-In":
            let canonicalRows: [Float] = [0.0, 3.15, 6.30]
            let row = driveSelectedRowIndex
            let zShift = 0.20 - canonicalRows[row]
            let horizontal: Float
            switch cinemaSeatPosition {
            case "Left": horizontal = 0.55
            case "Right": horizontal = -0.55
            default: horizontal = 0
            }
            return TheaterLayout(
                screenPosition: [horizontal, 1.02 + yShift, -11.75 + zShift],
                screenScale: 0.00475,
                controlsPosition: [0.0, -0.47, -1.05],
                posters: []
            )

        case "Private Screening Room":
            let rowMap: [String: Float] = ["Front": -1.2, "Middle": 0.0, "Back": 1.2]
            let xMap: [String: Float] = ["Left": -1.15, "Center": 0.0, "Right": 1.15]
            let zShift = -(rowMap[cinemaSeatRow] ?? 0)
            let xShift = -(xMap[cinemaSeatPosition] ?? 0)
            return TheaterLayout(
                screenPosition: [xShift, 0.18 + yShift, -5.10 + zShift],
                screenScale: 0.00325, controlsPosition: [0, -0.47, -1.0],
                posters: [
                    PosterPlacement(id: "cinema-poster-0", position: [-2.95 + xShift, 0.35 + yShift, -2.0 + zShift], yaw: .pi/2, scale: 1.45),
                    PosterPlacement(id: "cinema-poster-1", position: [ 2.95 + xShift, 0.35 + yShift, -2.0 + zShift], yaw: -.pi/2, scale: 1.45)
                ])

        case "Rooftop Cinema":
            let rowMap: [String: Float] = ["Front": -1.0, "Middle": 0.0, "Back": 1.0]
            let xMap: [String: Float] = ["Left": -1.6, "Center": 0.0, "Right": 1.6]
            let zShift = -(rowMap[cinemaSeatRow] ?? 0)
            let xShift = -(xMap[cinemaSeatPosition] ?? 0)
            return TheaterLayout(screenPosition: [xShift, 0.75 + yShift, -7.8 + zShift], screenScale: 0.0042, controlsPosition: [0,-0.47,-1.0], posters: [])

        case "Retro Palace":
            let rowMap: [String: Float] = ["Front": -2.4, "Middle": 0.0, "Back": 2.4]
            let xMap: [String: Float] = ["Left": -2.0, "Center": 0.0, "Right": 2.0]
            let zShift = -(rowMap[cinemaSeatRow] ?? 0)
            let xShift = -(xMap[cinemaSeatPosition] ?? 0)
            return TheaterLayout(screenPosition: [xShift, 0.50 + yShift, -8.8 + zShift], screenScale: 0.0046, controlsPosition: [0,-0.50,-1.05], posters: [
                PosterPlacement(id: "cinema-poster-0", position: [-4.6+xShift,0.55+yShift,-2.6+zShift], yaw: .pi/2, scale: 1.8),
                PosterPlacement(id: "cinema-poster-1", position: [ 4.6+xShift,0.55+yShift,-2.6+zShift], yaw: -.pi/2, scale: 1.8)
            ])

        case "Abandoned Cinema":
            let rowMap: [String: Float] = ["Front": -2.0, "Middle": 0.0, "Back": 2.0]
            let xMap: [String: Float] = ["Left": -1.6, "Center": 0.0, "Right": 1.6]
            let zShift = -(rowMap[cinemaSeatRow] ?? 0)
            let xShift = -(xMap[cinemaSeatPosition] ?? 0)
            return TheaterLayout(screenPosition: [xShift, 0.28 + yShift, -7.25 + zShift], screenScale: 0.00355, controlsPosition: [0,-0.47,-1.0], posters: [])

        case "Cruise Deck Cinema":
            let rowMap: [String: Float] = ["Front": -1.2, "Middle": 0.0, "Back": 1.2]
            let xMap: [String: Float] = ["Left": -1.7, "Center": 0.0, "Right": 1.7]
            let zShift = -(rowMap[cinemaSeatRow] ?? 0)
            let xShift = -(xMap[cinemaSeatPosition] ?? 0)
            return TheaterLayout(screenPosition: [xShift, 0.72 + yShift, -7.3 + zShift], screenScale: 0.00425, controlsPosition: [0,-0.47,-1.0], posters: [])

        case "Grand Theater":
            let rowMap: [String: Float] = ["Front": -4.2, "Middle": 0.0, "Back": 4.2]
            let xMap: [String: Float] = ["Left": -2.25, "Center": 0.0, "Right": 2.25]
            let zShift = -(rowMap[cinemaSeatRow] ?? 0.0)
            let xShift = -(xMap[cinemaSeatPosition] ?? 0.0)
            let screenZ: Float = -12.30 + zShift
            return TheaterLayout(
                screenPosition: [xShift, 0.42 + yShift, screenZ + 0.06],
                screenScale: 0.0054,
                controlsPosition: [0.0, -0.52, -1.05],
                posters: [
                    PosterPlacement(id: "cinema-poster-0", position: [-6.20 + xShift, 0.70 + yShift, -3.2 + zShift], yaw: .pi / 2, scale: 2.05),
                    PosterPlacement(id: "cinema-poster-1", position: [-6.20 + xShift, 0.70 + yShift, 0.0 + zShift], yaw: .pi / 2, scale: 2.05),
                    PosterPlacement(id: "cinema-poster-2", position: [-6.20 + xShift, 0.70 + yShift, 3.2 + zShift], yaw: .pi / 2, scale: 2.05),
                    PosterPlacement(id: "cinema-poster-3", position: [ 6.20 + xShift, 0.70 + yShift, -3.2 + zShift], yaw: -.pi / 2, scale: 2.05),
                    PosterPlacement(id: "cinema-poster-4", position: [ 6.20 + xShift, 0.70 + yShift, 0.0 + zShift], yaw: -.pi / 2, scale: 2.05),
                    PosterPlacement(id: "cinema-poster-5", position: [ 6.20 + xShift, 0.70 + yShift, 3.2 + zShift], yaw: -.pi / 2, scale: 2.05)
                ]
            )

        default:
            let canonicalRows: [Float] = [-3.30, -2.20, -1.10, 0.0, 1.10, 2.20, 3.30]
            let row = classicSelectedRowIndex
            let zShift = 0.18 - canonicalRows[row]
            let xShift = -classicSelectedSeatX
            let screenZ: Float = -6.55 + zShift
            return TheaterLayout(
                screenPosition: [xShift, 0.18 + yShift, screenZ + 0.045],
                screenScale: 0.00335,
                controlsPosition: [0.0, -0.47, -1.05],
                posters: [
                    PosterPlacement(id: "cinema-poster-0", position: [-4.30 + xShift, 0.52 + yShift, -0.80 + zShift], yaw: .pi / 2, scale: 1.75),
                    PosterPlacement(id: "cinema-poster-1", position: [-4.30 + xShift, 0.52 + yShift, -2.35 + zShift], yaw: .pi / 2, scale: 1.75),
                    PosterPlacement(id: "cinema-poster-2", position: [-4.30 + xShift, 0.52 + yShift, -3.90 + zShift], yaw: .pi / 2, scale: 1.75),
                    PosterPlacement(id: "cinema-poster-3", position: [ 4.30 + xShift, 0.52 + yShift, -0.80 + zShift], yaw: -.pi / 2, scale: 1.75),
                    PosterPlacement(id: "cinema-poster-4", position: [ 4.30 + xShift, 0.52 + yShift, -2.35 + zShift], yaw: -.pi / 2, scale: 1.75),
                    PosterPlacement(id: "cinema-poster-5", position: [ 4.30 + xShift, 0.52 + yShift, -3.90 + zShift], yaw: -.pi / 2, scale: 1.75)
                ]
            )
        }
    }

    @ViewBuilder
    private func cinemaPoster(index: Int) -> some View {
        let items = store.rows.flatMap { $0.items }
        let item: MediaItem? = index < items.count ? items[index] : nil
        ZStack {
            RoundedRectangle(cornerRadius: 12, style: .continuous)
                .fill(Color(red: 0.035, green: 0.035, blue: 0.042))
            if let raw = item?.posterURL, let url = URL(string: raw) {
                AsyncImage(url: url) { phase in
                    switch phase {
                    case .success(let image): image.resizable().scaledToFill()
                    default:
                        LinearGradient(colors: [.black, .red.opacity(0.42), .black], startPoint: .top, endPoint: .bottom)
                    }
                }
            } else {
                LinearGradient(colors: [.black, .red.opacity(0.42), .black], startPoint: .top, endPoint: .bottom)
            }
            VStack {
                Spacer()
                Text(item?.title ?? "SIGNAL CINEMA")
                    .font(.system(size: 22, weight: .bold))
                    .foregroundStyle(.white)
                    .lineLimit(2)
                    .padding(12)
                    .frame(maxWidth: .infinity)
                    .background(.black.opacity(0.72))
            }
        }
        .frame(width: 390, height: 585)
        .clipShape(RoundedRectangle(cornerRadius: 12, style: .continuous))
        .overlay(RoundedRectangle(cornerRadius: 12).stroke(.white.opacity(0.28), lineWidth: 5))
        .overlay(RoundedRectangle(cornerRadius: 16).stroke(.yellow.opacity(0.26), lineWidth: 9).padding(-8))
        .shadow(radius: 18)
        .allowsHitTesting(false)
    }

    private func makeEnvironment() -> Entity {
        switch cinemaEnvironment {
        case "Home Theater": return makeHomeTheater()
        case "Private Screening Room": return makePrivateScreeningRoom()
        case "Drive-In": return makeDriveIn()
        case "Rooftop Cinema": return makeRooftopCinema()
        case "Grand Theater": return makeGrandTheater()
        case "Retro Palace": return makeRetroPalace()
        case "Abandoned Cinema": return makeAbandonedCinema()
        case "Cruise Deck Cinema": return makeCruiseDeckCinema()
        default: return makeClassicCinema()
        }
    }

    // MARK: - RealityKit geometry helpers

    private func addBox(
        to parent: Entity,
        _ size: SIMD3<Float>,
        at position: SIMD3<Float>,
        color: UIColor,
        roughness: Float = 0.78,
        metallic: Bool = false
    ) {
        let material = SimpleMaterial(color: color, roughness: .float(roughness), isMetallic: metallic)
        let entity = ModelEntity(mesh: .generateBox(size: size), materials: [material])
        entity.position = position
        parent.addChild(entity)
    }

    private func addGlowBox(to parent: Entity, _ size: SIMD3<Float>, at position: SIMD3<Float>, color: UIColor) {
        let entity = ModelEntity(mesh: .generateBox(size: size), materials: [UnlitMaterial(color: color)])
        entity.position = position
        parent.addChild(entity)
    }

    private func addOval(to parent: Entity, _ size: SIMD3<Float>, at position: SIMD3<Float>, color: UIColor, roughness: Float = 0.72) {
        let entity = ModelEntity(
            mesh: .generateSphere(radius: 0.5),
            materials: [SimpleMaterial(color: color, roughness: .float(roughness), isMetallic: false)]
        )
        entity.scale = size
        entity.position = position
        parent.addChild(entity)
    }

    private func addPointLight(to parent: Entity, at position: SIMD3<Float>, color: UIColor, lumens: Float, radius: Float) {
        let light = Entity()
        light.components.set(
            PointLightComponent(
                color: color,
                intensity: lumens,
                attenuationRadius: radius,
                attenuationFalloffExponent: 2.0
            )
        )
        light.position = position
        parent.addChild(light)
    }

    private func addSeat(to parent: Entity, asset: Entity?, at position: SIMD3<Float>, scale: Float = 1.0) {
        if let asset {
            let seat = asset.clone(recursive: true)
            seat.position = position
            seat.scale = [scale, scale, scale]
            parent.addChild(seat)
            return
        }

        // Fallback stays curved and physically proportioned around a seated eye point.
        let burgundy = UIColor(red: 0.25, green: 0.025, blue: 0.045, alpha: 1)
        let dark = UIColor(red: 0.025, green: 0.026, blue: 0.032, alpha: 1)
        addOval(to: parent, [0.72 * scale, 0.80 * scale, 0.30 * scale], at: [position.x, position.y + 0.94 * scale, position.z + 0.34 * scale], color: burgundy)
        addOval(to: parent, [0.69 * scale, 0.22 * scale, 0.67 * scale], at: [position.x, position.y + 0.48 * scale, position.z - 0.08 * scale], color: burgundy)
        for side: Float in [-1, 1] {
            addOval(to: parent, [0.10 * scale, 0.18 * scale, 0.62 * scale], at: [position.x + side * 0.40 * scale, position.y + 0.62 * scale, position.z - 0.04 * scale], color: dark)
        }
    }

    private func addCC0Asset(
        _ asset: Entity?,
        to parent: Entity,
        at position: SIMD3<Float>,
        scale: SIMD3<Float> = [1, 1, 1],
        yaw: Float = 0
    ) {
        guard let asset else { return }
        let instance = asset.clone(recursive: true)
        instance.position = position
        instance.scale = scale
        instance.orientation = simd_quatf(angle: yaw, axis: [0, 1, 0])
        parent.addChild(instance)
    }


    /// Build 33: Xcode can preserve resource folders differently depending on whether the
    /// generated USDA came from a folder reference or an individual resource entry. Try the
    /// basename plus the known bundle subpaths so the real CC0 model wins over all fallbacks.
    private func loadCinemaAsset(_ basename: String) -> Entity? {
        // Build 34: GitHub was generating the CC0 USDA files correctly, but RealityKit
        // could still miss them when Xcode preserved the Cinema directory as a folder.
        // Try every bundle spelling, including explicit .usda extensions, before any fallback.
        let candidates = [
            basename,
            "\(basename).usda",
            "Cinema/\(basename)",
            "Cinema/\(basename).usda",
            "CC0/\(basename)",
            "CC0/\(basename).usda",
            "Cinema/CC0/\(basename)",
            "Cinema/CC0/\(basename).usda"
        ]
        for candidate in candidates {
            if let entity = try? Entity.load(named: candidate, in: .main) {
                diagnostics.record("assets", "Build35 loaded bundled cinema asset \(candidate)")
                return entity
            }
        }
        diagnostics.record("assets", "Build35 MISSING bundled cinema asset \(basename)")
        return nil
    }

    // MARK: - Classic Cinema

    private func makeClassicCinema() -> Entity {
        let room = Entity()
        let selectedRow = classicSelectedRowIndex
        let canonicalRows: [Float] = [-3.30, -2.20, -1.10, 0.0, 1.10, 2.20, 3.30]
        let zShift = 0.18 - canonicalRows[selectedRow]
        let xShift = -classicSelectedSeatX
        let heightShift = -seatHeightOffset
        let floorAtViewer: Float = -1.22 + heightShift
        let screenZ: Float = -6.55 + zShift
        let frontWallZ = screenZ - 0.23
        let rearWallZ: Float = 4.68 + zShift
        let ceilingY: Float = 2.20 + heightShift

        let charcoal = UIColor(red: 0.035, green: 0.038, blue: 0.050, alpha: 1)
        let wall = UIColor(red: 0.070, green: 0.065, blue: 0.083, alpha: 1)
        let acoustic = UIColor(red: 0.095, green: 0.085, blue: 0.105, alpha: 1)
        let carpet = UIColor(red: 0.095, green: 0.030, blue: 0.040, alpha: 1)
        let deepRed = UIColor(red: 0.19, green: 0.018, blue: 0.030, alpha: 1)
        let timber = UIColor(red: 0.18, green: 0.095, blue: 0.045, alpha: 1)
        let brass = UIColor(red: 0.42, green: 0.25, blue: 0.075, alpha: 1)
        let black = UIColor(red: 0.008, green: 0.009, blue: 0.013, alpha: 1)
        let warmGlow = UIColor(red: 1.0, green: 0.48, blue: 0.12, alpha: 1)
        let exitGlow = UIColor(red: 0.15, green: 0.95, blue: 0.43, alpha: 1)
        let coolScreen = UIColor(red: 0.62, green: 0.74, blue: 1.0, alpha: 1)

        // Build 35: use the complete CC0 Cinema Multiplex starter scene as the
        // architectural base. The procedural pieces below are now hybrid enhancement/
        // fallback only: Signal posters, screen-light, aisle glow and seat anchoring.
        if let starter = loadCinemaAsset("ClassicCinemaStarter") {
            let complete = starter.clone(recursive: true)
            complete.name = "classic-cinema-starter"
            complete.position = [xShift + 4.30, floorAtViewer, -0.55 + zShift]
            room.addChild(complete)
            diagnostics.record("assets", "Build35 mounted complete Cinema Multiplex starter scene")
        }

        // Build 32: real CC0 multiplex modules downloaded by GitHub Actions from
        // 3DAssets.dev and converted to static USDA before XcodeGen. Procedural room
        // geometry remains only as a fallback/shell when a module cannot load.
        let tieredRowAsset = loadCinemaAsset("CinemaTieredSeating")
        let premiumRowAsset = loadCinemaAsset("CinemaPremiumRecliner")
        let screenMaskAsset = loadCinemaAsset("CinemaScreenMask")
        let acousticWallAsset = loadCinemaAsset("CinemaAcousticWall")
        let exitDoorAsset = loadCinemaAsset("CinemaExitDoor")
        let sideLightAsset = loadCinemaAsset("CinemaSideLight")
        let projectionPanelAsset = loadCinemaAsset("CinemaProjectionPanel")
        let aisleFloorAsset = loadCinemaAsset("CinemaAisleFloor")
        let surroundSpeakerAsset = loadCinemaAsset("CinemaSurroundSpeaker")
        let aisleStepAsset = loadCinemaAsset("CinemaAisleStep")
        let posterLightboxAsset = loadCinemaAsset("CinemaPosterLightbox")
        diagnostics.record(
            "assets",
            "Build35 CC0 cinema modules tier=\(tieredRowAsset != nil) screen=\(screenMaskAsset != nil) acoustic=\(acousticWallAsset != nil) exit=\(exitDoorAsset != nil)"
        )

        // Seven physical tiers. The selected tier's top is exactly ~1.22m below the
        // headset eye origin, which places the viewer inside the chosen chair.
        for row in 0..<canonicalRows.count {
            let delta = row - selectedRow
            let rowZ = canonicalRows[row] + zShift
            let rowTop = floorAtViewer + Float(delta) * 0.30
            addBox(to: room, [7.15, 0.18, 1.08], at: [xShift, rowTop - 0.09, rowZ], color: carpet, roughness: 0.96)
            // Amber step nosing on both side aisles and the front edge of every tier.
            addGlowBox(to: room, [7.0, 0.012, 0.025], at: [xShift, rowTop + 0.008, rowZ - 0.525], color: UIColor(red: 0.72, green: 0.33, blue: 0.05, alpha: 1))
        }

        // Side aisles: no center aisle. The user's selected seat is an actual seat at x/z 0.
        let aisleCenterX: Float = 3.72
        let floorLength = rearWallZ - frontWallZ
        let floorCenterZ = (rearWallZ + frontWallZ) * 0.5
        for side: Float in [-1, 1] {
            addBox(to: room, [0.88, 0.10, floorLength], at: [xShift + side * aisleCenterX, floorAtViewer - 0.05, floorCenterZ], color: carpet, roughness: 0.96)
            addGlowBox(to: room, [0.035, 0.015, floorLength - 0.35], at: [xShift + side * (aisleCenterX - 0.36), floorAtViewer + 0.018, floorCenterZ], color: UIColor(red: 0.62, green: 0.24, blue: 0.045, alpha: 1))
        }

        // CC0 carpet/guide-line tiles and surround speakers add real auditorium detail.
        if let aisleFloorAsset {
            for side: Float in [-1, 1] {
                for tile in 0..<5 {
                    let z = screenZ + 1.25 + Float(tile) * 2.0
                    addCC0Asset(aisleFloorAsset, to: room, at: [xShift + side * aisleCenterX, floorAtViewer + 0.015, z])
                }
            }
        }
        if let surroundSpeakerAsset {
            for side: Float in [-1, 1] {
                for speaker in 0..<4 {
                    let z = screenZ + 1.7 + Float(speaker) * 2.25
                    addCC0Asset(surroundSpeakerAsset, to: room, at: [xShift + side * 4.06, floorAtViewer + 2.05, z], yaw: side > 0 ? -.pi / 2 : .pi / 2)
                }
            }
        }

        // Real tiered-row modules replace the repeated hand-built seat bank whenever
        // the CC0 kit is available. The selected row deliberately leaves the center
        // position open so the headset occupies the chair rather than looking at a seat back.
        let fallbackSeatAsset = loadCinemaAsset("CinemaSeat")
        for row in 0..<canonicalRows.count {
            let delta = row - selectedRow
            let rowZ = canonicalRows[row] + zShift + 0.10
            let rowFloor = floorAtViewer + Float(delta) * 0.30
            if let tieredRowAsset {
                // Build 33: use the REAL 3DAssets.dev tier on every row, including the
                // selected row. xShift aligns a real physical seat center with the headset,
                // so the viewer is seated in the chair instead of standing in an empty gap.
                addCC0Asset(tieredRowAsset, to: room, at: [xShift - 1.54, rowFloor, rowZ], yaw: .pi)
                addCC0Asset(tieredRowAsset, to: room, at: [xShift + 1.54, rowFloor, rowZ], yaw: .pi)
            } else {
                // Emergency-only fallback. This path should never be reached after the
                // Build 33 bundle checks; keep it so a missing resource cannot crash entry.
                let seatXs: [Float] = [-2.65, -1.90, -1.15, -0.40, 0.40, 1.15, 1.90, 2.65]
                for canonicalX in seatXs {
                    addSeat(to: room, asset: fallbackSeatAsset, at: [canonicalX + xShift, rowFloor, rowZ], scale: 0.86)
                }
            }

            if let aisleStepAsset {
                addCC0Asset(aisleStepAsset, to: room, at: [xShift - 3.72, rowFloor, rowZ - 0.48], yaw: .pi)
                addCC0Asset(aisleStepAsset, to: room, at: [xShift + 3.72, rowFloor, rowZ - 0.48], yaw: .pi)
            }
        }

        // Premium recliners at the very back make the room read like a modern multiplex.
        if let premiumRowAsset {
            let premiumZ = canonicalRows.last! + zShift + 1.20
            let premiumFloor = floorAtViewer + Float(canonicalRows.count - selectedRow) * 0.30
            addCC0Asset(premiumRowAsset, to: room, at: [xShift - 1.55, premiumFloor, premiumZ], yaw: .pi)
            addCC0Asset(premiumRowAsset, to: room, at: [xShift + 1.55, premiumFloor, premiumZ], yaw: .pi)
        }

        // Imported screen masking frame, rear projection panel and exit door make the
        // room read as a working cinema rather than a decorative box.
        addCC0Asset(screenMaskAsset, to: room, at: [xShift, 0.18 + heightShift, screenZ - 0.035], scale: [0.94, 1.18, 0.94])
        addCC0Asset(projectionPanelAsset, to: room, at: [xShift, floorAtViewer, rearWallZ - 0.08], yaw: .pi)
        addCC0Asset(exitDoorAsset, to: room, at: [xShift + 2.55, floorAtViewer, rearWallZ - 0.06], yaw: .pi)

        // Side walls and acoustic treatment inspired by real modular multiplex dimensions:
        // ~2m panel rhythm, fabric flutes, dark dado, warm wall-wash strips.
        let wallX: Float = 4.28
        let wallHeight = ceilingY - floorAtViewer
        for side: Float in [-1, 1] {
            addBox(to: room, [0.14, wallHeight, floorLength + 0.20], at: [xShift + side * wallX, floorAtViewer + wallHeight * 0.5, floorCenterZ], color: wall, roughness: 0.90)
            addBox(to: room, [0.05, 0.58, floorLength - 0.30], at: [xShift + side * (wallX - 0.09), floorAtViewer + 0.34, floorCenterZ], color: deepRed, roughness: 0.95)
            addBox(to: room, [0.035, 0.035, floorLength - 0.30], at: [xShift + side * (wallX - 0.12), floorAtViewer + 0.67, floorCenterZ], color: brass, roughness: 0.45, metallic: true)

            for module in 0..<5 {
                let z = screenZ + 1.45 + Float(module) * 2.0
                addCC0Asset(acousticWallAsset, to: room, at: [xShift + side * (wallX - 0.10), floorAtViewer, z], yaw: side > 0 ? -.pi / 2 : .pi / 2)
                if module == 1 || module == 3 {
                    addCC0Asset(sideLightAsset, to: room, at: [xShift + side * (wallX - 0.16), floorAtViewer + 0.55, z], yaw: side > 0 ? -.pi / 2 : .pi / 2)
                }
                if module == 0 || module == 4 {
                    addCC0Asset(posterLightboxAsset, to: room, at: [xShift + side * (wallX - 0.20), floorAtViewer + 0.65, z], yaw: side > 0 ? -.pi / 2 : .pi / 2)
                }
            }

            for bay in 0..<6 {
                let z = screenZ + 1.25 + Float(bay) * 1.45
                addBox(to: room, [0.035, 1.92, 1.14], at: [xShift + side * (wallX - 0.11), floorAtViewer + 1.58, z], color: acoustic, roughness: 0.98)
                for flute in 0..<7 {
                    let fluteZ = z - 0.48 + Float(flute) * 0.16
                    addBox(to: room, [0.025, 1.74, 0.045], at: [xShift + side * (wallX - 0.14), floorAtViewer + 1.58, fluteZ], color: charcoal, roughness: 0.94)
                }
                if bay == 1 || bay == 4 {
                    addGlowBox(to: room, [0.028, 0.90, 0.075], at: [xShift + side * (wallX - 0.18), floorAtViewer + 1.70, z], color: warmGlow)
                    addPointLight(to: room, at: [xShift + side * (wallX - 0.48), floorAtViewer + 1.72, z], color: UIColor(red: 1.0, green: 0.43, blue: 0.17, alpha: 1), lumens: 520, radius: 4.2)
                }
            }
        }

        // Ceiling with dark acoustic rafts and restrained warm coves.
        addBox(to: room, [8.70, 0.10, floorLength + 0.25], at: [xShift, ceilingY, floorCenterZ], color: charcoal, roughness: 0.94)
        for raft in 0..<6 {
            let z = screenZ + 1.0 + Float(raft) * 1.55
            addBox(to: room, [6.6, 0.07, 0.72], at: [xShift, ceilingY - 0.10, z], color: acoustic, roughness: 0.98)
            addGlowBox(to: room, [5.8, 0.014, 0.028], at: [xShift, ceilingY - 0.16, z + 0.32], color: UIColor(red: 0.42, green: 0.18, blue: 0.045, alpha: 1))
        }

        // Front proscenium. The live SwiftUI Signal screen attachment sits just in front.
        addBox(to: room, [8.55, wallHeight, 0.16], at: [xShift, floorAtViewer + wallHeight * 0.5, frontWallZ], color: black, roughness: 0.92)
        addBox(to: room, [6.28, 3.46, 0.10], at: [xShift, 0.18 + heightShift, screenZ - 0.07], color: charcoal, roughness: 0.90)
        addBox(to: room, [6.00, 0.12, 0.18], at: [xShift, 1.76 + heightShift, screenZ + 0.01], color: timber, roughness: 0.62)
        addBox(to: room, [6.00, 0.12, 0.18], at: [xShift, -1.40 + heightShift, screenZ + 0.01], color: timber, roughness: 0.62)
        for side: Float in [-1, 1] {
            addBox(to: room, [0.14, 3.28, 0.17], at: [xShift + side * 2.98, 0.18 + heightShift, screenZ + 0.01], color: timber, roughness: 0.62)
            addBox(to: room, [0.46, 2.70, 0.30], at: [xShift + side * 3.48, 0.05 + heightShift, screenZ + 0.08], color: black, roughness: 0.88)
        }
        addBox(to: room, [6.45, 0.14, 0.90], at: [xShift, floorAtViewer + 0.02, screenZ + 0.22], color: charcoal, roughness: 0.90)

        // Back wall: projection ports, double exit doors and lit exit signs are visible
        // when the viewer looks around, so the auditorium reads as a complete room.
        addBox(to: room, [8.55, wallHeight, 0.16], at: [xShift, floorAtViewer + wallHeight * 0.5, rearWallZ], color: wall, roughness: 0.92)
        addBox(to: room, [1.50, 0.62, 0.05], at: [xShift, floorAtViewer + 2.28, rearWallZ - 0.10], color: black, roughness: 0.25)
        addBox(to: room, [0.58, 0.38, 0.04], at: [xShift + 1.22, floorAtViewer + 2.30, rearWallZ - 0.11], color: black, roughness: 0.25)
        for side: Float in [-1, 1] {
            let doorX = xShift + side * 2.75
            addBox(to: room, [1.45, 2.18, 0.08], at: [doorX, floorAtViewer + 1.09, rearWallZ - 0.10], color: charcoal, roughness: 0.76)
            addBox(to: room, [1.20, 0.06, 0.08], at: [doorX, floorAtViewer + 1.15, rearWallZ - 0.16], color: brass, roughness: 0.42, metallic: true)
            addGlowBox(to: room, [0.78, 0.23, 0.055], at: [doorX, floorAtViewer + 2.36, rearWallZ - 0.18], color: exitGlow)
        }

        // Screen spill + restrained house lighting: dark enough for cinema, bright enough
        // to read upholstery, aisle geometry and wall treatments in Vision Pro.
        addPointLight(to: room, at: [xShift, 0.28 + heightShift, screenZ + 1.15], color: coolScreen, lumens: 2600, radius: 8.5)
        for z in [screenZ + 2.0, screenZ + 5.0, rearWallZ - 1.0] {
            addPointLight(to: room, at: [xShift - 2.25, ceilingY - 0.35, z], color: UIColor(red: 1.0, green: 0.62, blue: 0.34, alpha: 1), lumens: 2100, radius: 6.8)
            addPointLight(to: room, at: [xShift + 2.25, ceilingY - 0.35, z], color: UIColor(red: 1.0, green: 0.62, blue: 0.34, alpha: 1), lumens: 2100, radius: 6.8)
        }

        return room
    }

    // MARK: - Grand Theater

    private func makeGrandTheater() -> Entity {
        let room = Entity()
        let rowMap: [String: Float] = ["Front": -4.2, "Middle": 0.0, "Back": 4.2]
        let xMap: [String: Float] = ["Left": -2.25, "Center": 0.0, "Right": 2.25]
        let zShift = -(rowMap[cinemaSeatRow] ?? 0.0)
        let xShift = -(xMap[cinemaSeatPosition] ?? 0.0)
        let heightShift = -seatHeightOffset
        let floorY: Float = -1.22 + heightShift
        let screenZ: Float = -12.30 + zShift
        let rearZ: Float = 8.80 + zShift
        let ceilingY: Float = 4.15 + heightShift
        let wallX: Float = 6.80
        let depth = rearZ - screenZ
        let centerZ = (rearZ + screenZ) * 0.5

        let black = UIColor(red: 0.008, green: 0.009, blue: 0.014, alpha: 1)
        let wall = UIColor(red: 0.055, green: 0.045, blue: 0.060, alpha: 1)
        let carpet = UIColor(red: 0.085, green: 0.018, blue: 0.028, alpha: 1)
        let velvet = UIColor(red: 0.26, green: 0.018, blue: 0.035, alpha: 1)
        let gold = UIColor(red: 0.48, green: 0.27, blue: 0.06, alpha: 1)
        let warm = UIColor(red: 1.0, green: 0.43, blue: 0.12, alpha: 1)
        let cool = UIColor(red: 0.60, green: 0.72, blue: 1.0, alpha: 1)

        // Build 35: full playhouse starter scene (stage, proscenium, raked stalls,
        // circle front, side boxes and backstage) supplies the believable Grand Theater.
        if let starter = loadCinemaAsset("GrandTheaterStarter") {
            let playhouse = starter.clone(recursive: true)
            playhouse.name = "grand-theater-starter"
            // The source house faces the stage toward -Z. Put a middle-house seat at origin.
            playhouse.position = [xShift + 2.28, floorY, -5.20 + zShift]
            room.addChild(playhouse)
            diagnostics.record("assets", "Build35 mounted complete Theatre Stage and Backstage starter scene")
        }

        let tiered = loadCinemaAsset("CinemaTieredSeating")
        let premium = loadCinemaAsset("CinemaPremiumRecliner")
        let screenMask = loadCinemaAsset("CinemaScreenMask")
        let acoustic = loadCinemaAsset("CinemaAcousticWall")
        let sideLight = loadCinemaAsset("CinemaSideLight")
        let surround = loadCinemaAsset("CinemaSurroundSpeaker")
        let posterBox = loadCinemaAsset("CinemaPosterLightbox")
        let exitDoor = loadCinemaAsset("CinemaExitDoor")
        let aisleStep = loadCinemaAsset("CinemaAisleStep")

        addBox(to: room, [13.9, 0.12, depth], at: [xShift, floorY - 0.06, centerZ], color: carpet, roughness: 0.98)
        addBox(to: room, [13.9, 0.12, depth], at: [xShift, ceilingY, centerZ], color: black, roughness: 0.96)
        for side: Float in [-1, 1] {
            addBox(to: room, [0.16, ceilingY - floorY, depth], at: [xShift + side * wallX, floorY + (ceilingY - floorY) * 0.5, centerZ], color: wall, roughness: 0.96)
        }
        addBox(to: room, [13.9, ceilingY - floorY, 0.18], at: [xShift, floorY + (ceilingY - floorY) * 0.5, rearZ], color: wall, roughness: 0.96)

        // Eleven stepped rows; substantially larger than Classic Cinema.
        for row in 0..<11 {
            let canonicalZ = -5.0 + Float(row) * 1.15
            let rowZ = canonicalZ + zShift
            let rowFloor = floorY + Float(row - 5) * 0.24
            addBox(to: room, [11.8, 0.16, 1.10], at: [xShift, rowFloor - 0.08, rowZ], color: carpet, roughness: 0.98)
            addGlowBox(to: room, [11.6, 0.014, 0.025], at: [xShift, rowFloor + 0.01, rowZ - 0.52], color: UIColor(red: 0.68, green: 0.28, blue: 0.04, alpha: 1))
            if let tiered {
                for moduleX: Float in [-4.62, -1.54, 1.54, 4.62] {
                    addCC0Asset(tiered, to: room, at: [xShift + moduleX, rowFloor, rowZ], yaw: .pi)
                }
            }
            if let aisleStep {
                for aisleX: Float in [-6.0, 0.0, 6.0] {
                    addCC0Asset(aisleStep, to: room, at: [xShift + aisleX, rowFloor, rowZ - 0.48], yaw: .pi)
                }
            }
        }
        if let premium {
            for moduleX: Float in [-3.1, 0.0, 3.1] {
                addCC0Asset(premium, to: room, at: [xShift + moduleX, floorY + 1.52, rearZ - 1.65], yaw: .pi)
            }
        }

        // 10.4m grand screen, stage, velvet proscenium and side columns.
        addBox(to: room, [13.7, 5.5, 0.20], at: [xShift, 1.25 + heightShift, screenZ - 0.22], color: black, roughness: 0.94)
        addBox(to: room, [11.4, 4.95, 0.10], at: [xShift, 0.85 + heightShift, screenZ - 0.04], color: UIColor(red: 0.025, green: 0.025, blue: 0.03, alpha: 1), roughness: 0.92)
        addCC0Asset(screenMask, to: room, at: [xShift, 0.85 + heightShift, screenZ - 0.01], scale: [1.70, 1.70, 1.70])
        for side: Float in [-1, 1] {
            addBox(to: room, [0.72, 5.0, 0.22], at: [xShift + side * 5.65, 1.25 + heightShift, screenZ + 0.02], color: velvet, roughness: 0.98)
        }
        addBox(to: room, [12.0, 0.65, 0.24], at: [xShift, 3.58 + heightShift, screenZ + 0.02], color: velvet, roughness: 0.98)
        addBox(to: room, [12.1, 0.12, 1.25], at: [xShift, floorY + 0.02, screenZ + 0.42], color: black, roughness: 0.92)

        for side: Float in [-1, 1] {
            for bay in 0..<7 {
                let z = screenZ + 2.0 + Float(bay) * 2.4
                addCC0Asset(acoustic, to: room, at: [xShift + side * (wallX - 0.12), floorY + 0.05, z], yaw: side > 0 ? -.pi / 2 : .pi / 2)
                if bay == 1 || bay == 5 { addCC0Asset(posterBox, to: room, at: [xShift + side * (wallX - 0.18), floorY + 0.72, z], yaw: side > 0 ? -.pi / 2 : .pi / 2) }
                if bay == 2 || bay == 4 { addCC0Asset(sideLight, to: room, at: [xShift + side * (wallX - 0.16), floorY + 0.60, z], yaw: side > 0 ? -.pi / 2 : .pi / 2) }
                if bay % 2 == 0 { addCC0Asset(surround, to: room, at: [xShift + side * (wallX - 0.20), floorY + 2.55, z], yaw: side > 0 ? -.pi / 2 : .pi / 2) }
            }
            // Balcony/box rail gives Grand Theater a different silhouette.
            addBox(to: room, [0.16, 0.80, 8.4], at: [xShift + side * 5.55, floorY + 2.05, 4.4 + zShift], color: gold, roughness: 0.48, metallic: true)
            addBox(to: room, [1.75, 0.14, 8.4], at: [xShift + side * 5.12, floorY + 1.68, 4.4 + zShift], color: wall, roughness: 0.92)
        }
        addCC0Asset(exitDoor, to: room, at: [xShift - 5.2, floorY, rearZ - 0.08], yaw: .pi)
        addCC0Asset(exitDoor, to: room, at: [xShift + 5.2, floorY, rearZ - 0.08], yaw: .pi)
        addPointLight(to: room, at: [xShift, 0.8 + heightShift, screenZ + 1.5], color: cool, lumens: 4200, radius: 14)
        for z in [screenZ + 3.0, -1.0 + zShift, 4.5 + zShift, rearZ - 1.2] {
            addPointLight(to: room, at: [xShift - 4.4, ceilingY - 0.55, z], color: warm, lumens: 2300, radius: 8.5)
            addPointLight(to: room, at: [xShift + 4.4, ceilingY - 0.55, z], color: warm, lumens: 2300, radius: 8.5)
        }
        return room
    }

    // MARK: - Home Theater

    private func makeHomeTheater() -> Entity {
        let room = Entity()
        let selectedRow = homeSelectedRowIndex
        let canonicalRows: [Float] = [-1.45, 0.10, 1.65]
        let zShift = 0.18 - canonicalRows[selectedRow]
        let xShift = -homeSelectedSeatX
        let heightShift = -seatHeightOffset
        let floorY: Float = -1.22 + heightShift
        let screenZ: Float = -5.55 + zShift
        let rearZ: Float = 3.25 + zShift
        let ceilingY: Float = 1.82 + heightShift
        let roomCenterZ = (screenZ + rearZ) * 0.5
        let roomDepth = rearZ - screenZ

        let plaster = UIColor(red: 0.12, green: 0.105, blue: 0.095, alpha: 1)
        let walnut = UIColor(red: 0.22, green: 0.105, blue: 0.045, alpha: 1)
        let black = UIColor(red: 0.018, green: 0.019, blue: 0.024, alpha: 1)
        let rug = UIColor(red: 0.075, green: 0.055, blue: 0.060, alpha: 1)
        let warm = UIColor(red: 1.0, green: 0.55, blue: 0.24, alpha: 1)
        let cool = UIColor(red: 0.64, green: 0.76, blue: 1.0, alpha: 1)

        // Build 35: the furnished-flat CC0 starter contributes real sofas, tables, lamps,
        // curtains, rugs, bookcase and residential wall/floor detail. Signal adds the
        // dedicated cinema wall, acoustics and recliners on top.
        if let starter = loadCinemaAsset("HomeLivingStarter") {
            let furnished = starter.clone(recursive: true)
            furnished.name = "home-living-starter"
            furnished.position = [xShift - 2.55, floorY, -0.30 + zShift]
            room.addChild(furnished)
            diagnostics.record("assets", "Build35 mounted furnished living-room starter scene")
        }

        // A residential room, not the commercial cinema shell reused with fewer chairs.
        addBox(to: room, [7.25, 0.10, roomDepth], at: [xShift, floorY - 0.05, roomCenterZ], color: walnut, roughness: 0.78)
        addBox(to: room, [5.70, 0.028, 5.10], at: [xShift, floorY + 0.01, -0.10 + zShift], color: rug, roughness: 0.98)
        addBox(to: room, [7.25, 0.10, roomDepth], at: [xShift, ceilingY, roomCenterZ], color: black, roughness: 0.92)
        for side: Float in [-1, 1] {
            addBox(to: room, [0.12, ceilingY - floorY, roomDepth], at: [xShift + side * 3.58, floorY + (ceilingY - floorY) * 0.5, roomCenterZ], color: plaster, roughness: 0.92)
        }
        addBox(to: room, [7.25, ceilingY - floorY, 0.12], at: [xShift, floorY + (ceilingY - floorY) * 0.5, rearZ], color: plaster, roughness: 0.92)
        addBox(to: room, [7.25, ceilingY - floorY, 0.14], at: [xShift, floorY + (ceilingY - floorY) * 0.5, screenZ - 0.18], color: black, roughness: 0.92)

        // Warm timber/acoustic front wall with speaker towers.
        for slat in 0..<22 {
            let slatX = xShift - 3.25 + Float(slat) * 0.31
            addBox(to: room, [0.045, 2.70, 0.07], at: [slatX, 0.10 + heightShift, screenZ - 0.08], color: walnut, roughness: 0.62)
        }
        addBox(to: room, [4.82, 2.88, 0.11], at: [xShift, 0.12 + heightShift, screenZ - 0.02], color: black, roughness: 0.89)
        for side: Float in [-1, 1] {
            addBox(to: room, [0.40, 1.35, 0.36], at: [xShift + side * 2.82, floorY + 0.68, screenZ + 0.22], color: black, roughness: 0.52)
            addOval(to: room, [0.17, 0.17, 0.06], at: [xShift + side * 2.82, floorY + 0.92, screenZ + 0.02], color: UIColor(red: 0.12, green: 0.12, blue: 0.13, alpha: 1), roughness: 0.4)
            addOval(to: room, [0.10, 0.10, 0.05], at: [xShift + side * 2.82, floorY + 0.48, screenZ + 0.02], color: UIColor(red: 0.12, green: 0.12, blue: 0.13, alpha: 1), roughness: 0.4)
        }

        // Three real premium-recliner rows. The center recliner in the selected row is
        // aligned to the headset, so Home Theater now feels like sitting in a private room
        // rather than floating between hand-built oval cushions.
        let premiumAsset = loadCinemaAsset("CinemaPremiumRecliner")
        let fallbackSeat = loadCinemaAsset("CinemaSeat")
        for row in 0..<canonicalRows.count {
            let rowZ = canonicalRows[row] + zShift + 0.10
            let rowFloor = floorY + Float(row - selectedRow) * 0.16
            addBox(to: room, [4.55, 0.10, 1.30], at: [xShift, rowFloor - 0.05, rowZ], color: rug, roughness: 0.96)
            if let premiumAsset {
                addCC0Asset(premiumAsset, to: room, at: [xShift, rowFloor, rowZ], yaw: .pi)
            } else {
                for seatX: Float in [-1.0, 0, 1.0] {
                    addSeat(to: room, asset: fallbackSeat, at: [seatX + xShift, rowFloor, rowZ], scale: 1.02)
                }
            }
            for side: Float in [-1, 1] {
                addBox(to: room, [0.34, 0.38, 0.44], at: [xShift + side * 2.05, rowFloor + 0.19, rowZ], color: walnut, roughness: 0.60)
            }
        }

        // Cove lighting and recessed pools.
        for side: Float in [-1, 1] {
            addGlowBox(to: room, [0.035, 0.025, roomDepth - 0.8], at: [xShift + side * 3.18, ceilingY - 0.12, roomCenterZ], color: warm)
        }
        for z in [screenZ + 1.6, screenZ + 4.2, rearZ - 0.9] {
            addPointLight(to: room, at: [xShift - 1.65, ceilingY - 0.22, z], color: warm, lumens: 900, radius: 4.5)
            addPointLight(to: room, at: [xShift + 1.65, ceilingY - 0.22, z], color: warm, lumens: 900, radius: 4.5)
        }
        addPointLight(to: room, at: [xShift, 0.10 + heightShift, screenZ + 0.95], color: cool, lumens: 1100, radius: 5.8)

        return room
    }

    // MARK: - Private Screening Room

    private func makePrivateScreeningRoom() -> Entity {
        let room = Entity()
        let heightShift = -seatHeightOffset
        let floorY: Float = -1.22 + heightShift
        let xShift: Float = cinemaSeatPosition == "Left" ? 1.15 : (cinemaSeatPosition == "Right" ? -1.15 : 0)
        let zShift: Float = cinemaSeatRow == "Front" ? 1.2 : (cinemaSeatRow == "Back" ? -1.2 : 0)
        let walnut = UIColor(red: 0.17, green: 0.075, blue: 0.035, alpha: 1)
        let charcoal = UIColor(red: 0.025, green: 0.026, blue: 0.032, alpha: 1)
        let warm = UIColor(red: 1.0, green: 0.50, blue: 0.22, alpha: 1)
        let premium = loadCinemaAsset("CinemaPremiumRecliner")
        // compact upscale room shell
        addBox(to: room,[6.4,0.10,8.0],at:[xShift,floorY-0.05,-1.2+zShift],color:walnut,roughness:0.70)
        addBox(to: room,[6.4,0.10,8.0],at:[xShift,1.85+heightShift,-1.2+zShift],color:charcoal,roughness:0.92)
        for side: Float in [-1,1] { addBox(to: room,[0.12,3.0,8.0],at:[xShift+side*3.15,0.30+heightShift,-1.2+zShift],color:charcoal,roughness:0.90) }
        addBox(to: room,[6.4,3.0,0.12],at:[xShift,0.30+heightShift,-5.25+zShift],color:charcoal,roughness:0.90)
        for row in 0..<2 {
            let rz = Float(row)*1.55 + zShift
            if let premium { addCC0Asset(premium,to:room,at:[xShift,floorY+Float(row)*0.15,rz],yaw:.pi) }
        }
        // residential dressing pulled from the complete furnished-flat scene, offset behind viewer.
        if let starter = loadCinemaAsset("HomeLivingStarter") {
            addCC0Asset(starter,to:room,at:[xShift-2.4,floorY,2.2+zShift],scale:[0.62,0.62,0.62])
        }
        for side: Float in [-1,1] { addPointLight(to: room, at:[xShift+side*2.2,1.45+heightShift,-1.0+zShift],color:warm,lumens:850,radius:4.5) }
        return room
    }

    // MARK: - Rooftop Cinema

    private func makeRooftopCinema() -> Entity {
        let scene = Entity()
        let heightShift = -seatHeightOffset
        let floorY: Float = -1.22 + heightShift
        let xShift: Float = cinemaSeatPosition == "Left" ? 1.6 : (cinemaSeatPosition == "Right" ? -1.6 : 0)
        let zShift: Float = cinemaSeatRow == "Front" ? 1.0 : (cinemaSeatRow == "Back" ? -1.0 : 0)
        if let terrace = loadCinemaAsset("RooftopTerrace") {
            for gx in -1...1 { for gz in -1...1 { addCC0Asset(terrace,to:scene,at:[xShift+Float(gx)*4.0,floorY,-1.0+zShift+Float(gz)*4.0]) } }
        }
        let deck = UIColor(red:0.10,green:0.11,blue:0.12,alpha:1)
        let steel = UIColor(red:0.20,green:0.22,blue:0.24,alpha:1)
        let warm = UIColor(red:1.0,green:0.62,blue:0.30,alpha:1)
        addBox(to: scene,[14,0.12,13],at:[xShift,floorY-0.06,-1.0+zShift],color:deck,roughness:0.90)
        addBox(to: scene,[7.1,4.1,0.16],at:[xShift,0.72+heightShift,-7.9+zShift],color:steel,roughness:0.72,metallic:true)
        for side: Float in [-1,1] { addBox(to:scene,[0.14,1.05,12],at:[xShift+side*6.7,floorY+0.52,-1.0+zShift],color:steel,roughness:0.55,metallic:true) }
        // lounge islands using real cinema recliners rather than primitive blobs
        if let recliner = loadCinemaAsset("CinemaPremiumRecliner") {
            addCC0Asset(recliner,to:scene,at:[xShift,floorY,0.2+zShift],yaw:.pi,scale:[0.90,0.90,0.90])
            addCC0Asset(recliner,to:scene,at:[xShift,floorY,2.0+zShift],yaw:.pi,scale:[0.90,0.90,0.90])
        }
        for i in -4...4 { addGlowBox(to:scene,[0.06,0.06,0.06],at:[xShift+Float(i)*1.35,2.15+heightShift,-3.0+zShift],color:warm) }
        return scene
    }

    // MARK: - Retro Palace

    private func makeRetroPalace() -> Entity {
        let room = Entity()
        let heightShift = -seatHeightOffset
        let floorY: Float = -1.22 + heightShift
        let xShift: Float = cinemaSeatPosition == "Left" ? 2.0 : (cinemaSeatPosition == "Right" ? -2.0 : 0)
        let zShift: Float = cinemaSeatRow == "Front" ? 2.4 : (cinemaSeatRow == "Back" ? -2.4 : 0)
        // Reuse the coherent playhouse geometry, but dress it as a movie palace.
        if let starter = loadCinemaAsset("GrandTheaterStarter") {
            addCC0Asset(starter,to:room,at:[xShift+2.28,floorY,-5.0+zShift])
        }
        let gold = UIColor(red:0.52,green:0.28,blue:0.06,alpha:1)
        let velvet = UIColor(red:0.30,green:0.015,blue:0.035,alpha:1)
        let warm = UIColor(red:1.0,green:0.43,blue:0.12,alpha:1)
        // large movie screen masking inside the stage opening
        addBox(to:room,[8.2,3.55,0.12],at:[xShift,0.50+heightShift,-8.92+zShift],color:.black,roughness:0.96)
        for side: Float in [-1,1] { addBox(to:room,[0.45,4.6,0.45],at:[xShift+side*4.6,0.60+heightShift,-8.75+zShift],color:gold,roughness:0.40,metallic:true) }
        addBox(to:room,[9.6,0.55,0.45],at:[xShift,2.62+heightShift,-8.75+zShift],color:gold,roughness:0.40,metallic:true)
        for side: Float in [-1,1] { addBox(to:room,[1.15,4.3,0.18],at:[xShift+side*4.0,0.50+heightShift,-8.60+zShift],color:velvet,roughness:0.92) }
        for x in [-3.3,-1.1,1.1,3.3] { addPointLight(to:room,at:[xShift+Float(x),2.4+heightShift,-3.5+zShift],color:warm,lumens:1100,radius:5.2) }
        return room
    }

    // MARK: - Abandoned Cinema

    private func makeAbandonedCinema() -> Entity {
        let room = Entity()
        let heightShift = -seatHeightOffset
        let floorY: Float = -1.22 + heightShift
        let xShift: Float = cinemaSeatPosition == "Left" ? 1.6 : (cinemaSeatPosition == "Right" ? -1.6 : 0)
        let zShift: Float = cinemaSeatRow == "Front" ? 2.0 : (cinemaSeatRow == "Back" ? -2.0 : 0)
        if let starter = loadCinemaAsset("AbandonedCinemaStarter") {
            // Starter is 18x16m; center the auditorium and put its screen forward.
            addCC0Asset(starter,to:room,at:[xShift,floorY,-1.1+zShift])
        }
        let sickly = UIColor(red:0.44,green:0.47,blue:0.38,alpha:1)
        addPointLight(to:room,at:[xShift,1.55+heightShift,-5.5+zShift],color:sickly,lumens:900,radius:8)
        return room
    }

    // MARK: - Cruise Deck Cinema

    private func makeCruiseDeckCinema() -> Entity {
        let scene = Entity()
        let heightShift = -seatHeightOffset
        let floorY: Float = -1.22 + heightShift
        let xShift: Float = cinemaSeatPosition == "Left" ? 1.7 : (cinemaSeatPosition == "Right" ? -1.7 : 0)
        let zShift: Float = cinemaSeatRow == "Front" ? 1.2 : (cinemaSeatRow == "Back" ? -1.2 : 0)
        if let starter = loadCinemaAsset("CruiseDeckStarter") {
            addCC0Asset(starter,to:scene,at:[xShift,floorY,-1.0+zShift],scale:[0.72,0.72,0.72])
        }
        let steel=UIColor(red:0.18,green:0.21,blue:0.24,alpha:1)
        let cool=UIColor(red:0.58,green:0.74,blue:1.0,alpha:1)
        addBox(to:scene,[7.3,4.1,0.16],at:[xShift,0.72+heightShift,-7.42+zShift],color:steel,roughness:0.62,metallic:true)
        addPointLight(to:scene,at:[xShift,1.2+heightShift,-6.0+zShift],color:cool,lumens:1800,radius:9)
        return scene
    }

    // MARK: - Drive-In

    private func makeDriveIn() -> Entity {
        let scene = Entity()
        let selectedRow = driveSelectedRowIndex
        let canonicalRows: [Float] = [0.0, 3.15, 6.30]
        let zShift = 0.20 - canonicalRows[selectedRow]
        let heightShift = -seatHeightOffset
        let floorY: Float = -1.22 + heightShift
        let screenZ: Float = -11.75 + zShift
        let lateralShift: Float
        switch cinemaSeatPosition {
        case "Left": lateralShift = 0.55
        case "Right": lateralShift = -0.55
        default: lateralShift = 0
        }

        let night = UIColor(red: 0.010, green: 0.014, blue: 0.027, alpha: 1)
        let asphalt = UIColor(red: 0.045, green: 0.048, blue: 0.055, alpha: 1)
        let steel = UIColor(red: 0.13, green: 0.15, blue: 0.17, alpha: 1)
        let carDark = UIColor(red: 0.055, green: 0.060, blue: 0.070, alpha: 1)
        let dashboard = UIColor(red: 0.025, green: 0.027, blue: 0.032, alpha: 1)
        let screenFrame = UIColor(red: 0.24, green: 0.26, blue: 0.28, alpha: 1)
        let cool = UIColor(red: 0.62, green: 0.75, blue: 1.0, alpha: 1)
        let redLight = UIColor(red: 0.95, green: 0.06, blue: 0.03, alpha: 1)
        let amber = UIColor(red: 1.0, green: 0.48, blue: 0.08, alpha: 1)

        // Build 35: a CC0 mid-century roadside diner/motel scene becomes the concession
        // and entrance side of the drive-in lot. It is deliberately placed off-axis so it
        // enriches the environment without blocking the giant screen.
        if let roadside = loadCinemaAsset("RetroRoadsideStarter") {
            let venue = roadside.clone(recursive: true)
            venue.name = "drive-in-roadside-venue"
            venue.position = [-15.0, floorY, -4.5 + zShift]
            venue.scale = [0.62, 0.62, 0.62]
            scene.addChild(venue)
        }

        // Open-air horizon and asphalt lot. No cinema walls/ceiling are reused here.
        addBox(to: scene, [38, 0.10, 34], at: [0, floorY - 0.05, -5.5 + zShift], color: asphalt, roughness: 0.98)
        addBox(to: scene, [40, 6.0, 0.20], at: [0, 1.35 + heightShift, screenZ - 4.0], color: night, roughness: 1.0)

        // Large freestanding outdoor screen with steel posts and bottom truss.
        addBox(to: scene, [8.55, 4.90, 0.16], at: [lateralShift, 1.04 + heightShift, screenZ - 0.10], color: screenFrame, roughness: 0.78, metallic: true)
        addBox(to: scene, [8.05, 4.50, 0.09], at: [lateralShift, 1.04 + heightShift, screenZ + 0.01], color: .black, roughness: 0.95)
        for side: Float in [-1, 1] {
            addBox(to: scene, [0.30, 4.50, 0.34], at: [lateralShift + side * 4.0, floorY + 1.70, screenZ - 0.35], color: steel, roughness: 0.65, metallic: true)
            addBox(to: scene, [1.35, 0.18, 1.80], at: [lateralShift + side * 4.0, floorY + 0.10, screenZ - 0.35], color: steel, roughness: 0.75)
        }

        // The viewer is physically INSIDE a car: seat behind, dashboard/hood below,
        // windshield frame around the view. Geometry intentionally avoids the screen center.
        addBox(to: scene, [2.30, 0.36, 0.82], at: [0, floorY + 0.34, -0.60], color: dashboard, roughness: 0.70)
        addBox(to: scene, [2.46, 0.12, 1.35], at: [0, floorY + 0.14, -1.48], color: carDark, roughness: 0.42, metallic: true)
        addBox(to: scene, [2.10, 0.11, 0.36], at: [0, 1.02 + heightShift, -0.10], color: carDark, roughness: 0.48, metallic: true)
        for side: Float in [-1, 1] {
            addBox(to: scene, [0.11, 1.78, 0.16], at: [side * 1.08, -0.02 + heightShift, -0.20], color: carDark, roughness: 0.48, metallic: true)
            addBox(to: scene, [0.18, 0.48, 1.55], at: [side * 1.12, floorY + 0.48, 0.10], color: carDark, roughness: 0.52, metallic: true)
        }
        // seat/back around viewer, low enough to never block the forward picture
        addOval(to: scene, [0.76, 0.78, 0.30], at: [0, floorY + 0.92, 0.55], color: UIColor(red: 0.09, green: 0.09, blue: 0.10, alpha: 1), roughness: 0.78)
        addOval(to: scene, [0.74, 0.20, 0.66], at: [0, floorY + 0.45, -0.02], color: UIColor(red: 0.09, green: 0.09, blue: 0.10, alpha: 1), roughness: 0.78)

        // Rows of ACTUAL CC0 road cars. Build 32's stretched boxes/spheres were the
        // "spaceships" seen in the headset screenshots. The 3DAssets.dev saloon is a
        // real 4.82 m four-door vehicle; clone it around the viewer and face every car
        // toward the drive-in screen (-Z).
        let fleet = [
            loadCinemaAsset("DriveInCityCar"),
            loadCinemaAsset("DriveInHatchback"),
            loadCinemaAsset("DriveInSaloon"),
            loadCinemaAsset("DriveInEstate"),
            loadCinemaAsset("DriveInSedan")
        ]
        let rowZs: [Float] = [-2.8, 0.65, 4.10]
        var carIndex = 0
        for (row, canonicalZ) in rowZs.enumerated() {
            for side: Float in [-1, 1] {
                for column in 0..<2 {
                    let x = side * (3.15 + Float(column) * 2.65)
                    let z = canonicalZ + zShift + Float(row % 2) * 0.20
                    let source = fleet[carIndex % fleet.count]
                    carIndex += 1
                    if let source {
                        let car = source.clone(recursive: true)
                        car.position = [x, floorY, z]
                        // Road Showroom cars point +Z; rotate them toward the screen at -Z.
                        car.orientation = simd_quatf(angle: .pi, axis: [0, 1, 0])
                        car.scale = [0.96, 0.96, 0.96]
                        scene.addChild(car)
                    } else {
                        // Emergency fallback is car-shaped, never the old oval spaceship.
                        addBox(to: scene, [2.0, 0.62, 4.55], at: [x, floorY + 0.36, z], color: carDark, roughness: 0.45, metallic: true)
                        addBox(to: scene, [1.72, 0.58, 1.90], at: [x, floorY + 0.87, z - 0.18], color: UIColor(red: 0.035, green: 0.040, blue: 0.052, alpha: 1), roughness: 0.38)
                    }
                }
            }
        }

        // Old-school drive-in speaker posts beside the car.
        for side: Float in [-1, 1] {
            addBox(to: scene, [0.10, 1.25, 0.10], at: [side * 1.62, floorY + 0.62, 0.72], color: steel, roughness: 0.58, metallic: true)
            addBox(to: scene, [0.30, 0.42, 0.18], at: [side * 1.62, floorY + 1.18, 0.65], color: steel, roughness: 0.50, metallic: true)
            addGlowBox(to: scene, [0.18, 0.06, 0.02], at: [side * 1.62, floorY + 1.28, 0.55], color: amber)
        }

        // Deterministic star field: tiny unlit points at large depth, no random runtime work.
        for i in 0..<30 {
            let fi = Float(i)
            let x = -12.0 + (fi.truncatingRemainder(dividingBy: 10.0)) * 2.65
            let y = 2.2 + Float((i * 7) % 9) * 0.34
            let z = screenZ - 3.5 - Float((i * 3) % 7) * 0.45
            addOval(to: scene, [0.028, 0.028, 0.028], at: [x, y + heightShift, z], color: .white, roughness: 0.0)
        }

        addPointLight(to: scene, at: [lateralShift, 0.90 + heightShift, screenZ + 1.6], color: cool, lumens: 1650, radius: 9.5)
        return scene
    }
}
