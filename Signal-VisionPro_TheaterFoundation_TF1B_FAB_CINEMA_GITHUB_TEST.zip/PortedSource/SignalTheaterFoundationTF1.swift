#if os(visionOS)
import SwiftUI
import RealityKit
import UIKit

@MainActor
final class SignalTheaterFoundationState: ObservableObject {
    static let shared = SignalTheaterFoundationState()

    @Published var lighting: Float = 0.32
    @Published var screenScale: Float = 1.0
    @Published var screenHeight: Float = 0.0
    @Published var seatDepth: Float = 0.0
    @Published var tabletX: Float = 0.72
    @Published var tabletY: Float = 0.02
    @Published var tabletZ: Float = -1.05
    @Published var tabletVisible = true

    func resetView() {
        lighting = 0.32
        screenScale = 1.0
        screenHeight = 0.0
        seatDepth = 0.0
    }

    func resetTablet() {
        tabletX = 0.72
        tabletY = 0.02
        tabletZ = -1.05
        persistTablet()
    }

    func loadTablet() {
        let d = UserDefaults.standard
        guard d.object(forKey: "tf1.tablet.x") != nil else { return }
        tabletX = d.float(forKey: "tf1.tablet.x")
        tabletY = d.float(forKey: "tf1.tablet.y")
        tabletZ = d.float(forKey: "tf1.tablet.z")
    }

    func persistTablet() {
        let d = UserDefaults.standard
        d.set(tabletX, forKey: "tf1.tablet.x")
        d.set(tabletY, forKey: "tf1.tablet.y")
        d.set(tabletZ, forKey: "tf1.tablet.z")
    }
}

struct SignalTheaterFoundationBootstrap: View {
    @Environment(\.openImmersiveSpace) private var openImmersiveSpace
    @State private var requested = false

    var body: some View {
        ZStack {
            Color.black.ignoresSafeArea()
            VStack(spacing: 16) {
                Text("SIGNAL THEATER")
                    .font(.system(size: 42, weight: .black, design: .rounded))
                Text("Entering cinema…")
                    .foregroundStyle(.secondary)
            }
        }
        .task {
            guard !requested else { return }
            requested = true
            _ = await openImmersiveSpace(id: "signal-theater-foundation")
        }
    }
}

struct SignalTheaterFoundationSpace: View {
    @StateObject private var state = SignalTheaterFoundationState.shared
    @State private var dragStartX: Float?
    @State private var dragStartY: Float?

    var body: some View {
        RealityView { content, attachments in
            let room = await TF1CinemaFactory.makeCinema()
            content.add(room)
            if let tablet = attachments.entity(for: "theater-tablet") {
                tablet.name = "TF1PersonalTablet"
                content.add(tablet)
            }
        } update: { content, attachments in
            if let room = content.entities.first(where: { $0.name == "TF1Cinema" }) {
                TF1CinemaFactory.update(room: room, state: state)
            }
            if let tablet = attachments.entity(for: "theater-tablet") {
                tablet.position = [state.tabletX, state.tabletY, state.tabletZ]
                tablet.isEnabled = state.tabletVisible
            }
        } attachments: {
            Attachment(id: "theater-tablet") {
                TF1TheaterTablet(state: state)
                    .frame(width: 620, height: 560)
                    .glassBackgroundEffect(in: RoundedRectangle(cornerRadius: 38))
                    .gesture(
                        DragGesture(minimumDistance: 0)
                            .onChanged { value in
                                if dragStartX == nil {
                                    dragStartX = state.tabletX
                                    dragStartY = state.tabletY
                                }
                                let sx = dragStartX ?? state.tabletX
                                let sy = dragStartY ?? state.tabletY
                                state.tabletX = sx + Float(value.translation.width) * 0.0015
                                state.tabletY = sy - Float(value.translation.height) * 0.0015
                            }
                            .onEnded { _ in
                                dragStartX = nil
                                dragStartY = nil
                                state.persistTablet()
                            }
                    )
            }
        }
        .onAppear { state.loadTablet() }
    }
}

private struct TF1TheaterTablet: View {
    @ObservedObject var state: SignalTheaterFoundationState
    @State private var section = "Room"

    var body: some View {
        VStack(spacing: 0) {
            HStack {
                VStack(alignment: .leading, spacing: 2) {
                    Text("SIGNAL").font(.system(size: 18, weight: .black))
                    Text("THEATER CONTROL").font(.caption).foregroundStyle(.secondary)
                }
                Spacer()
                Image(systemName: "move.3d").font(.title2)
                Text("Grab to move").font(.caption).foregroundStyle(.secondary)
            }
            .padding(24)

            Divider()

            HStack(alignment: .top, spacing: 0) {
                VStack(spacing: 10) {
                    TF1Tab("Room", icon: "theatermasks", selected: $section)
                    TF1Tab("Seat", icon: "chair.lounge", selected: $section)
                    TF1Tab("Screen", icon: "rectangle.inset.filled", selected: $section)
                    TF1Tab("Lighting", icon: "lightbulb", selected: $section)
                    Spacer()
                }
                .frame(width: 155)
                .padding(14)

                Divider()

                ScrollView {
                    VStack(alignment: .leading, spacing: 20) {
                        Text(section).font(.title2.bold())
                        if section == "Room" {
                            LabeledContent("Environment", value: "Classic Cinema")
                            Text("TF1 is a clean theater foundation. Signal UI and playback are intentionally not loaded.")
                                .font(.callout).foregroundStyle(.secondary)
                            Button("Reset Theater") { state.resetView() }
                                .buttonStyle(.borderedProminent)
                        } else if section == "Seat" {
                            TF1Slider(title: "Seat position", value: $state.seatDepth, range: -1.2...1.2)
                            Button("Center Seat") { state.seatDepth = 0 }
                        } else if section == "Screen" {
                            TF1Slider(title: "Screen size", value: $state.screenScale, range: 0.78...1.22)
                            TF1Slider(title: "Screen height", value: $state.screenHeight, range: -0.65...0.65)
                        } else {
                            TF1Slider(title: "House lights", value: $state.lighting, range: 0.08...1.0)
                        }

                        Divider()
                        Text("Tablet Position").font(.headline)
                        TF1Slider(title: "Distance", value: $state.tabletZ, range: -1.8 ... -0.65)
                        Button("Reset Tablet Position") { state.resetTablet() }
                    }
                    .padding(24)
                }
            }
        }
        .background(.black.opacity(0.22))
    }
}

private struct TF1Tab: View {
    let title: String
    let icon: String
    @Binding var selected: String
    init(_ title: String, icon: String, selected: Binding<String>) {
        self.title = title; self.icon = icon; self._selected = selected
    }
    var body: some View {
        Button { selected = title } label: {
            HStack { Image(systemName: icon); Text(title); Spacer() }
                .frame(maxWidth: .infinity)
        }
        .buttonStyle(.bordered)
        .tint(selected == title ? .primary : .secondary)
    }
}

private struct TF1Slider: View {
    let title: String
    @Binding var value: Float
    let range: ClosedRange<Float>
    var body: some View {
        VStack(alignment: .leading, spacing: 8) {
            HStack { Text(title); Spacer(); Text(String(format: "%.2f", value)).monospacedDigit().foregroundStyle(.secondary) }
            Slider(value: $value, in: range)
        }
    }
}

@MainActor
private enum TF1CinemaFactory {
    // TF1B uses the purchased Fab theater as the room itself. Nothing from the old
    // Signal theater implementation is instantiated here.
    static func makeCinema() async -> Entity {
        let root = Entity(); root.name = "TF1Cinema"

        guard let imported = loadFabCinema() else {
            let marker = ModelEntity(
                mesh: .generateBox(size: [3.6, 1.8, 0.08]),
                materials: [SimpleMaterial(color: .init(red: 0.35, green: 0.02, blue: 0.02, alpha: 1), isMetallic: false)]
            )
            marker.name = "TF1FabAssetLoadFailure"
            marker.position = [0, 0.25, -4.0]
            root.addChild(marker)
            return root
        }

        imported.name = "FabMovieTheaterEnvironment"
        // The source auditorium is roughly 33 x 37 x 15 model units. At 0.25 scale
        // that becomes an ~8.3m x 9.1m room with a ~4.7m-wide architectural screen.
        // The source origin is intentionally kept near the premium/front-middle seat
        // and its screen is authored at negative depth.
        imported.scale = [0.25, 0.25, 0.25]
        imported.position = [0, -1.12, 0]
        root.addChild(imported)

        // Restyle only the seat hierarchy. This leaves the purchased architecture,
        // screen, curtain, speakers and wall materials intact.
        if let seats = findEntity(namedLike: "seats", under: imported) {
            applyBlackSeatMaterial(to: seats)
        }

        // These are semantic anchors, not additional screens. TF2 will bind Signal to
        // the purchased model's screen mesh; TF3 will switch that SAME target to Aether.
        if let sourceScreen = findEntity(namedLike: "screen", under: imported) {
            sourceScreen.name = "CinemaScreen"
        }

        // Poster anchors are empty in TF1B. Later builds can populate them dynamically
        // with authorized Signal catalog artwork without baking copyrighted posters.
        let posterLeft = Entity(); posterLeft.name = "SignalPosterAnchorLeft"; posterLeft.position = [-3.55, 0.25, -1.2]
        let posterRight = Entity(); posterRight.name = "SignalPosterAnchorRight"; posterRight.position = [3.55, 0.25, -1.2]
        root.addChild(posterLeft); root.addChild(posterRight)

        return root
    }

    static func update(room: Entity, state: SignalTheaterFoundationState) {
        guard let environment = room.findEntity(named: "FabMovieTheaterEnvironment") else { return }
        // In TF1B the screen-size control is intentionally interpreted as auditorium
        // presentation scale until TF2 owns the actual screen material/surface.
        let scale = max(0.215, min(0.285, 0.25 * state.screenScale))
        environment.scale = [scale, scale, scale]
        environment.position.y = -1.12 + state.screenHeight * 0.16
        room.position.z = state.seatDepth
        _ = state.lighting
    }

    private static func loadFabCinema() -> Entity? {
        let candidates = [
            "SignalFabMovieTheater",
            "SignalFabMovieTheater.usdz",
            "Cinema/SignalFabMovieTheater",
            "Cinema/SignalFabMovieTheater.usdz"
        ]
        for candidate in candidates {
            if let entity = try? Entity.load(named: candidate, in: .main) { return entity }
        }
        return nil
    }

    private static func findEntity(namedLike needle: String, under entity: Entity) -> Entity? {
        if entity.name.localizedCaseInsensitiveContains(needle) { return entity }
        for child in entity.children {
            if let match = findEntity(namedLike: needle, under: child) { return match }
        }
        return nil
    }

    private static func applyBlackSeatMaterial(to entity: Entity) {
        if let model = entity as? ModelEntity, var component = model.model {
            let count = max(1, component.materials.count)
            let charcoal = SimpleMaterial(
                color: .init(red: 0.025, green: 0.027, blue: 0.030, alpha: 1),
                roughness: 0.72,
                isMetallic: false
            )
            component.materials = Array(repeating: charcoal, count: count)
            model.model = component
        }
        for child in entity.children { applyBlackSeatMaterial(to: child) }
    }
}
