import SwiftUI

/// Build 25: independently managed, fixed-position Signal visual/focus surfaces.
/// These are composited inside ONE window, not movable visionOS system windows;
/// using separate system windows would not guarantee exact pixel registration.
enum SignalVisionLayer: String {
    case base = "Live TV / Signal"
    case catalog = "Home / Movies / Shows"
    case detail = "Media Information"

    var fixedDepth: CGFloat {
        switch self {
        case .base: return 0
        case .catalog: return 18
        case .detail: return 36
        }
    }
}

struct SignalVisionLayerSurface: ViewModifier {
    let level: SignalVisionLayer
    let active: Bool
    let visible: Bool

    func body(content: Content) -> some View {
        content
            // Genuinely separate depth planes, but fixed to identical x/y canvas
            // coordinates. Unlike independent system windows, these can't drift.
            .offset(z: visible ? level.fixedDepth : 0)
            .allowsHitTesting(active && visible)
            .accessibilityHidden(!active || !visible)
            .onAppear { print("[SignalVisionLayers] mounted \(level.rawValue)") }
    }
}
