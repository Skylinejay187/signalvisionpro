import Foundation
import UIKit

/// Safe external bridge to Sandwich Vision Theater.
///
/// Theater advertises partner deep-link support, but its arbitrary-media
/// partner payload is not publicly documented. This implementation does not
/// guess a private playback route. It preserves Signal playback, copies the
/// resolved stream URL, publishes a continuation activity, and attempts the
/// public Theater universal-link domain.
@MainActor
enum SignalTheaterExternalHandoff {
    private static let theaterURL = URL(string: "https://in.theater/")!

    static func open(mediaURL: URL) {
        UIPasteboard.general.url = mediaURL

        let activity = NSUserActivity(activityType: "com.signal.theater.external-playback")
        activity.title = "Continue Signal playback in Theater"
        activity.webpageURL = theaterURL
        activity.userInfo = [
            "signalMediaURL": mediaURL.absoluteString,
            "signalHandoffVersion": 1
        ]
        activity.isEligibleForHandoff = true
        activity.isEligibleForSearch = false
        activity.isEligibleForPublicIndexing = false
        activity.becomeCurrent()

        UIApplication.shared.open(
            theaterURL,
            options: [.universalLinksOnly: true]
        ) { openedAsUniversalLink in
            guard !openedAsUniversalLink else { return }
            UIApplication.shared.open(theaterURL)
        }
    }
}
