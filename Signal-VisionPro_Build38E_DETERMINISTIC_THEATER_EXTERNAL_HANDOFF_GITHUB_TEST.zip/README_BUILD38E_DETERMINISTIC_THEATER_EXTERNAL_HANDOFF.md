# Build 38E — deterministic theater + external Theater app probe

Base: user-supplied Build 38B only.

Changes:
1. Media Information visionOS background restored to Build 25A behavior:
   no 0.82 opaque black foundation; Live TV/catalog remains visible behind it.
2. GitHub no longer downloads/caches/converts the large external 3DAssets.dev
   cinema kit. Internal rooms use the existing procedural construction plus the
   small bundled CinemaSeat fallback.
3. The floating `signal-playback-surface` SwiftUI attachment is removed.
   Internal immersive playback uses a RealityKit `VideoMaterial` plane aligned
   directly to the architectural theater screen.
4. The source Signal player is paused while internal theater playback owns the
   visible movie, then restored when leaving theater.
5. External Theater app handoff no longer opens Safari. It probes multiple
   app-only custom-scheme candidates, then Universal Links using
   `universalLinksOnly`. If none are accepted, Signal remains in place and the
   resolved stream URL stays copied.
6. No Build 39 code is used.

Note: Sandwich Vision publicly states Theater has partner deep-link support,
but its arbitrary-media partner contract is not publicly documented. The route
probe is therefore experimental and intentionally never uses a browser fallback.
