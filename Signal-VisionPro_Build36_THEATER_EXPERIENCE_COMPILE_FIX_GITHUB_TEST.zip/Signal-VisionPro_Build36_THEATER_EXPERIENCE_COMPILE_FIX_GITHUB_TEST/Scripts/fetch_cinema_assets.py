#!/usr/bin/env python3
"""Fetch the CC0 3DAssets.dev cinema kit and convert static GLB geometry to USDA.

This runs in GitHub Actions before XcodeGen. 3DAssets.dev publishes the files as
CC0 1.0 Universal. We deliberately flatten animation/scene transforms because
Signal uses the assets as static RealityKit set dressing.
"""
from __future__ import annotations
import argparse, hashlib, os, re, sys, urllib.request
from pathlib import Path

ASSETS = {
    "CinemaTieredSeating": ("https://cdn.3dassets.dev/assets/34650/v1/model.glb", "Tiered Seating Row Module"),
    "CinemaPremiumRecliner": ("https://cdn.3dassets.dev/assets/34651/v1/model.glb", "Premium Recliner Row Module"),
    "CinemaScreenMask": ("https://cdn.3dassets.dev/assets/34649/v1/model.glb", "Cinema Screen and Masking Frame"),
    "CinemaAcousticWall": ("https://cdn.3dassets.dev/assets/34652/v1/model.glb", "Acoustic Wall Panel Module"),
    "CinemaExitDoor": ("https://cdn.3dassets.dev/assets/34653/v1/model.glb", "Exit Door Module with Sign"),
    "CinemaSideLight": ("https://cdn.3dassets.dev/assets/34654/v1/model.glb", "Side Wall Light Strip"),
    "CinemaProjectionPanel": ("https://cdn.3dassets.dev/assets/34655/v1/model.glb", "Projection Port Wall Panel"),
    "CinemaAisleFloor": ("https://cdn.3dassets.dev/assets/34656/v1/model.glb", "Auditorium Aisle Floor Tile"),
    "CinemaSurroundSpeaker": ("https://cdn.3dassets.dev/assets/34660/v1/model.glb", "Wall Mounted Surround Speaker"),
    "CinemaAisleStep": ("https://cdn.3dassets.dev/assets/34648/v1/model.glb", "Aisle Step Module"),
    "CinemaPosterLightbox": ("https://cdn.3dassets.dev/assets/34681/v1/model.glb", "Wall Mounted Poster Light Box"),
    "CinemaMultiplexFloor": ("https://cdn.3dassets.dev/assets/34689/v1/model.glb", "Cinema Multiplex Floor"),
    # Build 36: complete CC0 environment starters. These are intentionally kept as
    # separate resources so RealityKit can use the full authored layout instead of
    # reconstructing every room from primitives.
    "ClassicCinemaStarter": ("https://cdn.3dassets.dev/assets/34689/v1/model.glb", "Cinema Multiplex and Foyer starter scene"),
    "GrandTheaterStarter": ("https://cdn.3dassets.dev/assets/35925/v1/model.glb", "Theatre Stage and Backstage playhouse starter scene"),
    "HomeLivingStarter": ("https://cdn.3dassets.dev/assets/38818/v1/model.glb", "Furnished Bedroom and Living Room starter scene"),
    "AbandonedCinemaStarter": ("https://cdn.3dassets.dev/assets/29736/v1/model.glb", "Abandoned Cinema and Projection Booth starter scene"),
    "RetroRoadsideStarter": ("https://cdn.3dassets.dev/assets/37370/v1/model.glb", "Retro Diner and Roadside Motel starter scene"),
    "CruiseDeckStarter": ("https://cdn.3dassets.dev/assets/38462/v1/model.glb", "Cruise Ship Deck and Lounge starter scene"),
    "RooftopTerrace": ("https://cdn.3dassets.dev/assets/27699/v1/model.glb", "Rooftop Terrace With Rail 4m"),
    # Several distinct CC0 cars keep the drive-in from looking like cloned props.
    "DriveInCityCar": ("https://cdn.3dassets.dev/assets/15105/v1/model.glb", "City car (Road Car Showroom Lineup)"),
    "DriveInHatchback": ("https://cdn.3dassets.dev/assets/15109/v1/model.glb", "Five-door hatchback (Road Car Showroom Lineup)"),
    "DriveInSaloon": ("https://cdn.3dassets.dev/assets/15104/v1/model.glb", "Contemporary saloon (Road Car Showroom Lineup)"),
    "DriveInEstate": ("https://cdn.3dassets.dev/assets/15103/v1/model.glb", "Long-roof estate (Road Car Showroom Lineup)"),
    "DriveInSedan": ("https://cdn.3dassets.dev/assets/32490/v1/model.glb", "Four-door saloon (Car Park and Road Vehicle Fleet)"),
}


def safe_name(value: str) -> str:
    value = re.sub(r"[^A-Za-z0-9_]", "_", value)
    if not value or value[0].isdigit(): value = "_" + value
    return value


def fmt(v: float) -> str:
    if abs(v) < 1e-8: v = 0.0
    return f"{v:.7g}"


def material_color(mesh):
    # trimesh's PBR/Simple material API varies slightly by version. Prefer its
    # resolved main color and fall back to the average vertex/face color.
    try:
        mat = getattr(mesh.visual, "material", None)
        c = getattr(mat, "main_color", None)
        if c is not None and len(c) >= 3:
            vals = [float(x) / 255.0 for x in c[:4]]
            while len(vals) < 4: vals.append(1.0)
            return vals
    except Exception:
        pass
    try:
        c = mesh.visual.vertex_colors
        if c is not None and len(c):
            import numpy as np
            m = np.asarray(c, dtype=float).mean(axis=0) / 255.0
            vals = list(m[:4])
            while len(vals) < 4: vals.append(1.0)
            return vals
    except Exception:
        pass
    return [0.28, 0.28, 0.30, 1.0]



def material_texture(mesh):
    """Return a PIL image for the material's base-color texture when available."""
    try:
        mat = getattr(mesh.visual, "material", None)
        for attr in ("baseColorTexture", "image"):
            image = getattr(mat, attr, None)
            if image is not None:
                return image
    except Exception:
        pass
    return None

def convert_glb_to_usda(glb: Path, out: Path, root_name: str) -> tuple[int, int]:
    import trimesh
    loaded = trimesh.load(str(glb), force="scene", process=False)
    if isinstance(loaded, trimesh.Trimesh):
        meshes = [loaded]
    else:
        dumped = loaded.dump(concatenate=False)
        meshes = [m for m in dumped if isinstance(m, trimesh.Trimesh)]
    if not meshes:
        raise RuntimeError(f"no triangle meshes decoded from {glb}")

    out.parent.mkdir(parents=True, exist_ok=True)
    tris = 0
    verts = 0
    with out.open("w", encoding="utf-8") as f:
        f.write('#usda 1.0\n(\n    metersPerUnit = 1\n    upAxis = "Y"\n)\n\n')
        root = safe_name(root_name)
        f.write(f'def Xform "{root}" {{\n')
        f.write('    def Scope "Looks" {\n')
        colors = []
        texture_files = {}
        for i, mesh in enumerate(meshes):
            c = material_color(mesh)
            colors.append(c)
            image = material_texture(mesh)
            uv = getattr(mesh.visual, "uv", None)
            has_texture = image is not None and uv is not None and len(uv) == len(mesh.vertices)
            texture_name = None
            if has_texture:
                try:
                    texture_name = f"{safe_name(root_name)}_M{i}_BaseColor.png"
                    image.convert("RGBA").save(out.parent / texture_name, format="PNG", optimize=True)
                    texture_files[i] = texture_name
                except Exception as exc:
                    print(f"Texture export fallback for {root_name} mesh {i}: {exc}")
                    texture_name = None

            f.write(f'        def Material "M{i}" {{\n')
            f.write(f'            token outputs:surface.connect = </{root}/Looks/M{i}/PreviewSurface.outputs:surface>\n')
            if texture_name:
                f.write('            def Shader "UVReader" {\n')
                f.write('                uniform token info:id = "UsdPrimvarReader_float2"\n')
                f.write('                token inputs:varname = "st"\n')
                f.write('                float2 outputs:result\n')
                f.write('            }\n')
                f.write('            def Shader "BaseColorTexture" {\n')
                f.write('                uniform token info:id = "UsdUVTexture"\n')
                f.write(f'                asset inputs:file = @{texture_name}@\n')
                f.write('                float2 inputs:st.connect = </'+root+f'/Looks/M{i}/UVReader.outputs:result>\n')
                f.write('                token inputs:sourceColorSpace = "sRGB"\n')
                f.write('                float3 outputs:rgb\n')
                f.write('                float outputs:a\n')
                f.write('            }\n')
            f.write(f'            def Shader "PreviewSurface" {{\n')
            f.write('                uniform token info:id = "UsdPreviewSurface"\n')
            if texture_name:
                f.write('                color3f inputs:diffuseColor.connect = </'+root+f'/Looks/M{i}/BaseColorTexture.outputs:rgb>\n')
                f.write('                float inputs:opacity.connect = </'+root+f'/Looks/M{i}/BaseColorTexture.outputs:a>\n')
            else:
                f.write(f'                color3f inputs:diffuseColor = ({fmt(c[0])}, {fmt(c[1])}, {fmt(c[2])})\n')
                f.write(f'                float inputs:opacity = {fmt(c[3])}\n')
            f.write('                float inputs:roughness = 0.68\n')
            f.write('                float inputs:metallic = 0.03\n')
            f.write('                token outputs:surface\n')
            f.write('            }\n        }\n')
        f.write('    }\n')

        for i, mesh in enumerate(meshes):
            v = mesh.vertices
            faces = mesh.faces
            if len(v) == 0 or len(faces) == 0: continue
            verts += len(v); tris += len(faces)
            f.write(f'    def Mesh "Mesh_{i}" {{\n')
            f.write('        point3f[] points = [\n')
            for p in v:
                f.write(f'            ({fmt(float(p[0]))}, {fmt(float(p[1]))}, {fmt(float(p[2]))}),\n')
            f.write('        ]\n')
            uv = getattr(mesh.visual, "uv", None)
            if i in texture_files and uv is not None and len(uv) == len(v):
                f.write('        texCoord2f[] primvars:st = [\n')
                for t in uv:
                    f.write(f'            ({fmt(float(t[0]))}, {fmt(float(t[1]))}),\n')
                f.write('        ] (\n            interpolation = "vertex"\n        )\n')
            f.write(f'        int[] faceVertexCounts = [{", ".join(["3"] * len(faces))}]\n')
            flat = faces.reshape(-1)
            # Chunk long index arrays so generated USDA stays parser-friendly.
            f.write('        int[] faceVertexIndices = [\n')
            for j in range(0, len(flat), 36):
                f.write('            ' + ', '.join(str(int(x)) for x in flat[j:j+36]) + ',\n')
            f.write('        ]\n')
            f.write('        uniform token subdivisionScheme = "none"\n')
            f.write('        bool doubleSided = true\n')
            f.write(f'        rel material:binding = </{root}/Looks/M{i}>\n')
            f.write('    }\n')
        f.write('}\n')
    return verts, tris


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument('--output', default='Resources/Cinema')
    ap.add_argument('--cache', default='.cinema-asset-cache')
    ap.add_argument('--only', action='append', default=[])
    args = ap.parse_args()
    out_dir = Path(args.output)
    cache = Path(args.cache)
    cache.mkdir(parents=True, exist_ok=True)
    wanted = args.only or list(ASSETS)
    missing = [x for x in wanted if x not in ASSETS]
    if missing: raise SystemExit(f"unknown cinema asset(s): {missing}")

    print('3DAssets.dev cinema assets are CC0 1.0 Universal; no attribution required.')
    manifest = []
    for name in wanted:
        url, human = ASSETS[name]
        glb = cache / f'{name}.glb'
        if not glb.exists() or glb.stat().st_size < 100:
            print(f'Downloading {human}: {url}')
            req = urllib.request.Request(url, headers={'User-Agent':'SignalVisionPro-Build36/1.0'})
            with urllib.request.urlopen(req, timeout=60) as r, glb.open('wb') as w:
                w.write(r.read())
        digest = hashlib.sha256(glb.read_bytes()).hexdigest()
        out = out_dir / f'{name}.usda'
        verts, tris = convert_glb_to_usda(glb, out, name)
        print(f'Converted {human}: {verts} vertices / {tris} triangles -> {out}')
        manifest.append(f'{name}\t{human}\t{url}\tsha256={digest}\tvertices={verts}\ttriangles={tris}')
    out_dir.mkdir(parents=True, exist_ok=True)
    (out_dir / 'ASSET_SOURCES.txt').write_text(
        'Signal Vision Pro CC0 cinema asset sources\n'
        'License: CC0 1.0 Universal (https://creativecommons.org/publicdomain/zero/1.0/)\n\n' +
        '\n'.join(manifest) + '\n', encoding='utf-8')
    return 0

if __name__ == '__main__':
    raise SystemExit(main())
