import SwiftUI

// visionOS does not expose tvOS MoveCommandDirection/onMoveCommand.
// Preserve the original Unity directional routing for hardware keyboard arrows
// without modifying the unported Apple TV source. Native gaze/pinch selection
// continues through SwiftUI's existing focus and button interaction system.
enum SignalMoveDirection: Equatable {
    case up, down, left, right
}

extension View {
    func signalMoveCommand(perform action: @escaping (SignalMoveDirection) -> Void) -> some View {
        onKeyPress(keys: [.upArrow, .downArrow, .leftArrow, .rightArrow]) { press in
            switch press.key {
            case .upArrow: action(.up)
            case .downArrow: action(.down)
            case .leftArrow: action(.left)
            case .rightArrow: action(.right)
            default: return .ignored
            }
            return .handled
        }
    }
}
