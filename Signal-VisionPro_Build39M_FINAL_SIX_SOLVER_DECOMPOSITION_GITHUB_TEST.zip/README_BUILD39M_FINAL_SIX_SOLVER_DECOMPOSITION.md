# Build 39M — targeted decomposition of all six remaining solver failures

Patched directly from 39L after its GitHub log reduced the remaining Swift compiler
type-check failures from eight to six.

All six reported expressions were structurally decomposed:
- TopMenuBar: render tree separated from lifecycle/onChange chain.
- MediaInfoPopup connected episodes: season selector and episode cards separated.
- ManualEpisodesRow: header, season strip and episode strip separated.
- SourceIntelligenceSatelliteLinkRow: badge, metadata and row decoration separated.
- EmbeddedSourceProviderStrip: provider chip extracted into its own View.
- PanelOptionChip: conditional colors/widths moved out of the View expression.

This pass does not depend on merely increasing the solver timeout. It reduces the
generic expression graphs Xcode must infer.

No Aether, theater playback ownership, membership, or intended UI behavior changes.
Continue using Universal Workflow v4C.
