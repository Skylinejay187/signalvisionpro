# RESET7 — Head Anchor + Paid Asset Swap

Version 0.9.0-RESET7, build 52.

- Tablet now uses RealityKit `AnchorEntity(.head, trackingMode: .once)` rather than inheriting cinema/world placement.
- Default tablet offset is 0.30m right, 0.18m below head center, 0.75m forward.
- Recenter reanchors to the current head pose with `.once`; it does not continuously follow the wearer.
- Tablet remains independently draggable through its RealityKit input/collision handle.
- Paid cinema loading resolves the exact bundled USDZ URL (Cinema subdirectory or flattened bundle) and uses async `Entity(contentsOf:)`.
- Clean room remains visible until the selected paid asset actually loads and is inserted.
- RESET6 watchdog-safe delayed async loading is retained.
- Physical Vision Pro testing remains authoritative.
