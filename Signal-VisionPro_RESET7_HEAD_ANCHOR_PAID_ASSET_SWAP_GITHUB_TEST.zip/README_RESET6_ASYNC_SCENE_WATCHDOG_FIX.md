# RESET6 — Async Scene Watchdog Fix

Build 51 / 0.9.0-RESET6.

Physical RESET5 result: black immersive scene followed by process termination. The supplied IPS identified a 0x8BADF00D scene-update watchdog termination.

RESET6 removes synchronous Entity.load(named:) calls from RealityView scene establishment. The immersive root, clean fallback room and tablet are created immediately. Paid USDZ environments are loaded with RealityKit's async Entity(named:in:) initializer after the immersive scene has had time to commit. Calibration is applied only after each asynchronous load completes. The clean room remains visible while the selected paid environment is not ready.

No theater asset or coordinate calibration was reverted. This build specifically addresses startup/watchdog behavior.
