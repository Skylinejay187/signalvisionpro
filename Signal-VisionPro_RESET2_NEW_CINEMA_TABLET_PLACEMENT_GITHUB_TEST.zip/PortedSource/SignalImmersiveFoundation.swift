#if os(visionOS)
import Foundation
import SwiftUI
import RealityKit
import ARKit
import QuartzCore
import simd

@MainActor
final class SignalImmersiveFoundationState: ObservableObject {
    static let shared = SignalImmersiveFoundationState()
    @Published var tabletX: Float = 0
    @Published var tabletY: Float = -0.16
    @Published var tabletZ: Float = -1.0
    @Published var recenterRevision = 0
    @Published var foundationReady = false
    func resetTablet() { tabletX = 0; tabletY = -0.16; tabletZ = -1.0 }
    func requestRecenter() { recenterRevision &+= 1 }
}

@MainActor
private final class SignalDevicePoseTracker {
    static let shared = SignalDevicePoseTracker()
    private let session = ARKitSession()
    private let worldTracking = WorldTrackingProvider()
    private var started = false
    func startIfNeeded() async {
        guard !started, WorldTrackingProvider.isSupported else { return }
        started = true
        do { try await session.run([worldTracking]) }
        catch { started = false; print("[SignalCinema] world tracking start failed: \(error)") }
    }
    func pose() -> simd_float4x4? {
        guard worldTracking.state == .running,
              let anchor = worldTracking.queryDeviceAnchor(atTimestamp: CACurrentMediaTime()), anchor.isTracked else { return nil }
        return anchor.originFromAnchorTransform
    }
}

struct SignalImmersiveBootstrap: View {
    @Environment(\.openImmersiveSpace) private var openImmersiveSpace
    @Environment(\.dismissWindow) private var dismissWindow
    @State private var requested = false
    var body: some View {
        Color.clear.frame(width: 1, height: 1).task {
            guard !requested else { return }; requested = true
            if case .opened = await openImmersiveSpace(id: "signal-cinema") { dismissWindow(id: "signal-main") }
        }
    }
}

struct SignalImmersiveFoundationSpace: View {
    @StateObject private var state = SignalImmersiveFoundationState.shared
    @State private var lastAppliedRecenter = -1
    @State private var dragStartX: Float?
    @State private var dragStartY: Float?

    var body: some View {
        RealityView { content, attachments in
            let root = Entity(); root.name = "SignalCinemaRoot"; content.add(root)
            root.addChild(Self.makeCinema())
            if let tablet = attachments.entity(for: "signal-control-tablet") {
                tablet.name = "SignalControlTablet"; tablet.isEnabled = false; root.addChild(tablet)
            }
        } update: { content, attachments in
            guard let root = content.entities.first(where: { $0.name == "SignalCinemaRoot" }) else { return }
            if state.recenterRevision != lastAppliedRecenter, let pose = SignalDevicePoseTracker.shared.pose() {
                root.transform = Self.horizontalSpawnTransform(from: pose)
                lastAppliedRecenter = state.recenterRevision
                state.foundationReady = true
            }
            if let tablet = attachments.entity(for: "signal-control-tablet") {
                tablet.isEnabled = state.foundationReady
                tablet.position = [state.tabletX, state.tabletY, state.tabletZ]
                tablet.orientation = simd_quatf(angle: 0, axis: [0,1,0])
            }
        } attachments: {
            Attachment(id: "signal-control-tablet") {
                SignalCinemaControlTablet(state: state)
                    .frame(width: 560, height: 330)
                    .glassBackgroundEffect(in: RoundedRectangle(cornerRadius: 34))
                    .gesture(DragGesture(minimumDistance: 0)
                        .onChanged { value in
                            if dragStartX == nil { dragStartX = state.tabletX; dragStartY = state.tabletY }
                            state.tabletX = (dragStartX ?? state.tabletX) + Float(value.translation.width) * 0.0015
                            state.tabletY = (dragStartY ?? state.tabletY) - Float(value.translation.height) * 0.0015
                        }
                        .onEnded { _ in dragStartX = nil; dragStartY = nil })
            }
        }
        .task {
            await SignalDevicePoseTracker.shared.startIfNeeded()
            // Never expose the tablet at world-origin/floor height. Wait for a tracked head pose first.
            for _ in 0..<125 {
                if SignalDevicePoseTracker.shared.pose() != nil { state.resetTablet(); state.requestRecenter(); return }
                try? await Task.sleep(nanoseconds: 40_000_000)
            }
        }
    }

    private static func horizontalSpawnTransform(from pose: simd_float4x4) -> Transform {
        let p = SIMD3<Float>(pose.columns.3.x, pose.columns.3.y, pose.columns.3.z)
        var f = SIMD3<Float>(-pose.columns.2.x, 0, -pose.columns.2.z)
        f = simd_length_squared(f) < 0.0001 ? SIMD3<Float>(0,0,-1) : simd_normalize(f)
        return Transform(scale: .one, rotation: simd_quatf(angle: atan2(f.x, -f.z), axis: [0,1,0]), translation: p)
    }

    // RESET2 cinema is deliberately authored in meters around the calibrated wearer origin.
    // Eye origin = (0,0,0), floor = -1.25m, screen center = 6.6m forward.
    // No imported model transform or legacy seat coordinate can move the wearer.
    private static func makeCinema() -> Entity {
        let room = Entity(); room.name = "SignalCinemaEnvironment"
        func box(_ name: String, _ size: SIMD3<Float>, _ pos: SIMD3<Float>, _ material: SimpleMaterial) {
            let e = ModelEntity(mesh: .generateBox(size: size), materials: [material]); e.name = name; e.position = pos; room.addChild(e)
        }
        let dark = SimpleMaterial(color: .init(white: 0.035, alpha: 1), roughness: 0.82, isMetallic: false)
        let wall = SimpleMaterial(color: .init(red: 0.07, green: 0.055, blue: 0.06, alpha: 1), roughness: 0.9, isMetallic: false)
        let seat = SimpleMaterial(color: .init(white: 0.018, alpha: 1), roughness: 0.68, isMetallic: false)
        let screen = SimpleMaterial(color: .init(white: 0.72, alpha: 1), roughness: 0.96, isMetallic: false)
        box("Floor", [12,0.12,15], [0,-1.30,-1.0], dark)
        box("Ceiling", [12,0.12,15], [0,3.4,-1.0], dark)
        box("LeftWall", [0.15,4.8,15], [-6,1.05,-1.0], wall)
        box("RightWall", [0.15,4.8,15], [6,1.05,-1.0], wall)
        box("FrontWall", [12,4.8,0.15], [0,1.05,-8.25], wall)
        box("BackWall", [12,4.8,0.15], [0,1.05,6.25], wall)
        box("MainScreen", [7.8,3.45,0.08], [0,0.65,-8.10], screen)
        // Proscenium frame.
        box("ScreenTop", [8.3,0.18,0.18], [0,2.46,-7.98], dark)
        box("ScreenBottom", [8.3,0.18,0.18], [0,-1.16,-7.98], dark)
        box("ScreenLeft", [0.18,3.8,0.18], [-4.06,0.65,-7.98], dark)
        box("ScreenRight", [0.18,3.8,0.18], [4.06,0.65,-7.98], dark)
        // Seating starts behind the wearer and to the sides; there is no geometry at the calibrated head/body origin.
        for row in 0..<4 {
            let z = Float(1.5 + Double(row) * 1.15)
            let y = Float(-0.72 + Double(row) * 0.12)
            for col in -4...4 where col != 0 {
                let x = Float(col) * 0.82
                box("Seat_\(row)_\(col)_base", [0.62,0.34,0.58], [x,y,z], seat)
                box("Seat_\(row)_\(col)_back", [0.62,0.78,0.18], [x,y+0.43,z+0.23], seat)
            }
        }
        return room
    }
}

private struct SignalCinemaControlTablet: View {
    @ObservedObject var state: SignalImmersiveFoundationState
    var body: some View {
        VStack(alignment: .leading, spacing: 16) {
            HStack { VStack(alignment: .leading, spacing: 3) { Text("SIGNAL").font(.system(size: 19, weight: .black)); Text("VISION CINEMA").font(.caption).foregroundStyle(.secondary) }; Spacer(); Image(systemName: "move.3d"); Text("Drag me").font(.caption).foregroundStyle(.secondary) }
            Divider()
            Text("Cinema environment active").font(.headline)
            Text("The environment and tablet are placed from the tracked Vision Pro pose. Recenter rebuilds the wearer-relative origin.").font(.callout).foregroundStyle(.secondary)
            HStack { Button("Recenter") { state.resetTablet(); state.requestRecenter() }.buttonStyle(.borderedProminent); Button("Reset Tablet") { state.resetTablet() }; Spacer(); Text(String(format: "x %.2f   y %.2f   z %.2f", state.tabletX,state.tabletY,state.tabletZ)).font(.caption.monospacedDigit()).foregroundStyle(.secondary) }
        }.padding(24).background(.black.opacity(0.18))
    }
}
#endif
