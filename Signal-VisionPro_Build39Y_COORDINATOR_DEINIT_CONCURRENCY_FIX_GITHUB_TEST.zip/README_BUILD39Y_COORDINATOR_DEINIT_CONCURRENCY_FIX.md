# Build 39Y — Coordinator deinit concurrency fix

Base: Build 39X.

Removes only the actor-invalid `deinit { teardown() }` from the exact
@MainActor trailer Coordinator. Cleanup remains in the @MainActor
`dismantleUIView` lifecycle already fixed in 39X.

All 39T runtime-restoration hooks and Build 39 Aether architecture remain.
Build 40 external handoff remains excluded.
