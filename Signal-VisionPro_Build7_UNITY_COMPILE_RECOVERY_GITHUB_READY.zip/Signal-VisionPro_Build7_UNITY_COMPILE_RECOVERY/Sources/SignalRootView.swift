import SwiftUI
import AVKit

// Native visionOS presentation. All displayed catalog/channel records are loaded
// through VisionSourceBridge from the SAME vBRDC357 official manifest/M3U contracts;
// the underlying MediaItem/MediaRow/LiveTVChannel are the original tvOS models.
private enum SignalSection: String, CaseIterable, Identifiable {
    case home = "Home"
    case movies = "Movies"
    case shows = "Shows"
    case liveTV = "Live TV"
    case player = "Player"
    case settings = "Settings"
    var id: String { rawValue }
    var symbol: String {
        switch self {
        case .home: "house.fill"
        case .movies: "film.fill"
        case .shows: "play.tv.fill"
        case .liveTV: "tv.fill"
        case .player: "play.rectangle.fill"
        case .settings: "gearshape.fill"
        }
    }
}

struct SignalRootView: View {
    @State private var selection: SignalSection? = .home
    @AppStorage("signal.backendURL") private var backendURL = ""
    @AppStorage("signal.streamURL") private var streamURL = ""
    @AppStorage("signal.catalogManifestURL") private var catalogManifestURL = VisionSourceBridge.officialManifest
    @AppStorage("signal.livePlaylistURL") private var livePlaylistURL = ""
    @State private var backendStatus = "Not checked"
    @State private var checking = false
    @State private var catalogLoading = false
    @State private var catalogStatus = "Not loaded"
    @State private var catalogRows: [MediaRow] = []
    @State private var liveLoading = false
    @State private var liveStatus = "No lineup loaded"
    @State private var channels: [LiveTVChannel] = []
    @State private var category = "All"
    @State private var query = ""
    @State private var selectedMedia: MediaItem?
    @State private var player: AVPlayer?
    @State private var playingTitle = ""
    @State private var playbackError = ""
    @State private var traktStatus = TraktSyncManager.shared.lastStatus
    @State private var traktLinkCode: TraktDeviceLinkCode?
    @State private var traktBusy = false
    @State private var restoreCode = ""
    @State private var restoreBusy = false
    @State private var restoreStatus = "Enter an existing Apple TV restore code."

    // The Apple TV Unity navigation geometry is retained; native visionOS
    // focus/hover is supplied by SwiftUI instead of tvOS remote commands.
    var body: some View {
        VStack(spacing: 0) {
            unityTopMenu
            Group {
                switch selection ?? .home {
                case .home: catalogScreen(kind: nil)
                case .movies: catalogScreen(kind: "movie")
                case .shows: catalogScreen(kind: "series")
                case .liveTV: liveTV
                case .player: playback
                case .settings: settings
                }
            }
            .frame(maxWidth: .infinity, maxHeight: .infinity)
            .padding(.horizontal, 28)
            .padding(.bottom, 18)
        }
        .background(Color.black)
        .foregroundStyle(.white)
        .sheet(item: $selectedMedia) { item in
            mediaDetails(item)
                .frame(minWidth: 650, minHeight: 470)
                .background(Color.black)
                .foregroundStyle(.white)
        }
        .task {
            if catalogRows.isEmpty { await loadCatalogs() }
        }
        .onDisappear { player?.pause() }
    }

    private var unityTopMenu: some View {
        HStack(spacing: 4) {
            ForEach(SignalSection.allCases) { section in
                Button {
                    selection = section
                } label: {
                    HStack(spacing: 5) {
                        Image(systemName: section.symbol).font(.system(size: 11))
                        Text(section.rawValue).font(.system(size: 12, weight: .semibold))
                    }
                    .padding(.horizontal, 11)
                    .padding(.vertical, 6)
                    .foregroundStyle(selection == section ? Color.black : Color.white.opacity(0.85))
                    .background(
                        Capsule().fill(selection == section ? Color.cyan : Color.clear)
                    )
                }
                .buttonStyle(.plain)
                .hoverEffect(.highlight)
                .accessibilityLabel(section.rawValue)
            }
        }
        .padding(4)
        .background(Capsule().fill(Color(white: 0.08)))
        .overlay(Capsule().stroke(Color.white.opacity(0.16), lineWidth: 0.8))
        .padding(.top, 18)
        .padding(.bottom, 15)
    }

    private var branding: some View {
        HStack(spacing: 16) {
            Image("SignalChromeWordmark")
                .resizable().scaledToFit().frame(width: 230, height: 90)
                .accessibilityLabel("Signal")
            VStack(alignment: .leading, spacing: 4) {
                Text("SIGNAL").font(.title2.bold())
                Text("UNITY").font(.caption.weight(.semibold))
                    .foregroundStyle(.white.opacity(0.55))
            }
            Spacer()
        }
    }

    private func catalogScreen(kind: String?) -> some View {
        ScrollView {
            LazyVStack(alignment: .leading, spacing: 26) {
                branding
                HStack {
                    Text(kind == nil ? "Home" : (kind == "movie" ? "Movies" : "Shows"))
                        .font(.system(size: 25, weight: .bold, design: .rounded))
                    Spacer()
                    if catalogLoading { ProgressView() }
                    Button("Refresh catalogs", systemImage: "arrow.clockwise") {
                        Task { await loadCatalogs() }
                    }.disabled(catalogLoading)
                }
                Text(catalogStatus).font(.caption).foregroundStyle(.secondary)
                if let error = catalogError { Text(error).foregroundStyle(.orange) }
                let rows = catalogRows.filter { row in
                    kind == nil || row.items.contains(where: { normalizedKind($0.type) == kind })
                }
                ForEach(rows) { row in
                    let visible = row.items.filter { kind == nil || normalizedKind($0.type) == kind }
                    if !visible.isEmpty {
                        VStack(alignment: .leading, spacing: 12) {
                            Text(row.title).font(.system(size: 19, weight: .bold, design: .rounded))
                            ScrollView(.horizontal) {
                                LazyHStack(spacing: 16) {
                                    ForEach(visible) { item in
                                        Button { selectedMedia = item } label: {
                                            VStack(alignment: .leading, spacing: 7) {
                                                AsyncImage(url: URL(string: item.posterURL ?? "")) { image in
                                                    image.resizable().scaledToFill()
                                                } placeholder: {
                                                    RoundedRectangle(cornerRadius: 14)
                                                        .fill(.quaternary)
                                                        .overlay { Image(systemName: "film") }
                                                }
                                                .frame(width: 154, height: 228)
                                                .clipShape(RoundedRectangle(cornerRadius: 14))
                                                .overlay {
                                                    UnityCatalogCardChrome(item: item, focused: false, cornerRadius: 14)
                                                }
                                                Text(item.title).font(.caption.bold()).lineLimit(2)
                                                    .frame(width: 154, alignment: .leading)
                                                Text(item.year).font(.caption2).foregroundStyle(.secondary)
                                            }
                                        }
                                        .buttonStyle(.plain)
                                        .accessibilityLabel("Open \(item.title)")
                                    }
                                }.padding(8)
                            }.scrollIndicators(.hidden)
                        }
                    }
                }
                if !catalogLoading && rows.isEmpty {
                    ContentUnavailableView("No catalogs loaded", systemImage: "square.stack",
                        description: Text("Check the catalog manifest URL in Settings and reload."))
                }
            }
            .frame(maxWidth: .infinity, alignment: .leading)
        }
        .navigationTitle(kind == nil ? "Home" : (kind == "movie" ? "Movies" : "Shows"))
    }

    private var catalogError: String? {
        catalogStatus.hasPrefix("Error:") ? catalogStatus : nil
    }
    private func normalizedKind(_ raw: String) -> String {
        ["series", "show", "tv", "episode"].contains(raw.lowercased()) ? "series" : "movie"
    }

    private func mediaDetails(_ item: MediaItem) -> some View {
        HStack(alignment: .top, spacing: 24) {
            AsyncImage(url: URL(string: CatalogArtworkCacheManager.preferredBackdropURL(for: item) ?? "")) { image in
                image.resizable().scaledToFit()
            } placeholder: { Image(systemName: "film").font(.largeTitle) }
                .frame(width: 210, height: 320)
            VStack(alignment: .leading, spacing: 14) {
                Text(item.title).font(.largeTitle.bold())
                Text([item.year, item.rating, item.catalog].filter { !$0.isEmpty }.joined(separator: " • "))
                    .font(.subheadline).foregroundStyle(.secondary)
                Text(item.description.isEmpty ? "No description available." : item.description)
                if !item.genres.isEmpty { Text(item.genres.joined(separator: " • ")).font(.caption) }
                Text("The vBRDC357 source resolver and player-engine handoff are not yet compiled for visionOS. Do not treat this screen as full VOD playback.")
                    .font(.caption).foregroundStyle(.secondary)
                Button("Close") { selectedMedia = nil }
                Spacer()
            }
        }
        .padding(28)
    }

    private var liveTV: some View {
        VStack(alignment: .leading, spacing: 16) {
            branding
            HStack {
                Text("Live TV").font(.largeTitle.bold())
                Spacer()
                if liveLoading { ProgressView() }
                Button("Reload lineup", systemImage: "arrow.clockwise") { Task { await loadLineup() } }
                    .disabled(liveLoading || livePlaylistURL.isEmpty)
            }
            Text(liveStatus).font(.caption).foregroundStyle(.secondary)
            if channels.isEmpty {
                ContentUnavailableView("No channels loaded", systemImage: "tv",
                    description: Text("Enter your existing M3U playlist URL in Settings, then reload the lineup."))
            } else {
                TextField("Find channel", text: $query)
                let categories = ["All"] + Array(Set(channels.map(\.category))).sorted()
                Picker("Category", selection: $category) {
                    ForEach(categories, id: \.self) { Text($0).tag($0) }
                }.pickerStyle(.menu)
                ScrollView {
                    LazyVGrid(columns: Array(repeating: GridItem(.flexible(), spacing: 18), count: 4), spacing: 18) {
                        ForEach(channels.filter { channel in
                            (category == "All" || channel.category == category) &&
                            (query.isEmpty || channel.name.localizedCaseInsensitiveContains(query) || channel.number.contains(query))
                        }) { channel in
                            Button {
                                streamURL = channel.streamURL
                                startPlayback(title: channel.name)
                            } label: {
                                ZStack(alignment: .bottomLeading) {
                                    RoundedRectangle(cornerRadius: 22)
                                        .fill(Color(white: 0.10))
                                    AsyncImage(url: URL(string: channel.iconURL)) { image in
                                        image.resizable().scaledToFit()
                                    } placeholder: {
                                        Image(systemName: "tv")
                                            .font(.system(size: 40))
                                            .foregroundStyle(.white.opacity(0.45))
                                    }
                                    .frame(maxWidth: .infinity, maxHeight: .infinity)
                                    .padding(19)
                                    LinearGradient(colors: [.clear, .black.opacity(0.90)],
                                                   startPoint: .center, endPoint: .bottom)
                                    VStack(alignment: .leading, spacing: 3) {
                                        Text(channel.name).font(.system(size: 13, weight: .semibold))
                                            .lineLimit(1)
                                        Text(channel.number + "  " + channel.category)
                                            .font(.system(size: 10))
                                            .foregroundStyle(.white.opacity(0.65))
                                            .lineLimit(1)
                                    }
                                    .padding(14)
                                }
                                .frame(height: 162)
                                .clipShape(RoundedRectangle(cornerRadius: 22))
                                .overlay {
                                    RoundedRectangle(cornerRadius: 22)
                                        .stroke(Color.white.opacity(0.16), lineWidth: 0.8)
                                }
                            }
                            .buttonStyle(.plain)
                            .hoverEffect(.lift)
                        }
                    }
                }
            }
        }
        .navigationTitle("Live TV")
        .task { if channels.isEmpty && !livePlaylistURL.isEmpty { await loadLineup() } }
    }

    private var playback: some View {
        VStack(alignment: .leading, spacing: 16) {
            Text(playingTitle.isEmpty ? "Player" : playingTitle).font(.largeTitle.bold())
            if let player {
                VideoPlayer(player: player)
                    .frame(minHeight: 440)
                    .clipShape(RoundedRectangle(cornerRadius: 16))
                Button("Stop playback") { player.pause(); self.player = nil }
            } else {
                ContentUnavailableView("No stream selected", systemImage: "play.rectangle",
                    description: Text("Select a channel in Live TV or enter a direct stream in Settings."))
            }
            if !playbackError.isEmpty { Text(playbackError).foregroundStyle(.orange) }
            Spacer(minLength: 0)
        }
        .navigationTitle("Player")
    }

    private var settings: some View {
        Form {
            Section("Backend") {
                TextField("Backend URL", text: $backendURL)
                    .textInputAutocapitalization(.never).autocorrectionDisabled()
                Button(checking ? "Checking…" : "Check backend") { Task { await checkBackend() } }
                    .disabled(checking)
                Text(backendStatus).font(.caption).foregroundStyle(.secondary)
            }
            Section("Official Signal catalogs") {
                TextField("Manifest URL", text: $catalogManifestURL)
                    .textInputAutocapitalization(.never).autocorrectionDisabled()
                Button("Load catalogs") { Task { await loadCatalogs() } }.disabled(catalogLoading)
                Text("Defaults to the same internal all-in-one manifest URL as Apple TV vBRDC357.")
                    .font(.caption).foregroundStyle(.secondary)
            }
            Section("Live TV") {
                TextField("Your M3U playlist URL", text: $livePlaylistURL)
                    .textInputAutocapitalization(.never).autocorrectionDisabled()
                Button("Load channel lineup") { Task { await loadLineup() } }
                    .disabled(livePlaylistURL.isEmpty || liveLoading)
                Text("Playlist credentials remain in local app settings. Xtream, Channels DVR, guide/EPG, and provider-specific playback adapters need additional porting.")
                    .font(.caption).foregroundStyle(.secondary)
                TextField("Direct HTTP(S) playback URL", text: $streamURL)
                    .textInputAutocapitalization(.never).autocorrectionDisabled()
                Button("Play direct stream") { startPlayback(title: "Direct stream") }
            }
            Section("Trakt — original Apple TV integration") {
                Text(traktStatus).font(.caption).foregroundStyle(.secondary)
                if let traktLinkCode {
                    Text("Enter code: \(traktLinkCode.userCode)").font(.title3.monospaced())
                        .textSelection(.enabled)
                    if let link = URL(string: traktLinkCode.verificationURL) {
                        Link("Authorize on Trakt", destination: link)
                    }
                }
                if TraktSyncManager.shared.isConnected {
                    Text("Account: \(TraktSyncManager.shared.connectedAccountName)")
                    Button("Refresh Trakt shelves") { Task { await loadCatalogs() } }
                        .disabled(catalogLoading || traktBusy)
                    Button("Disconnect Trakt") {
                        TraktSyncManager.shared.disconnect()
                        traktLinkCode = nil
                        traktStatus = TraktSyncManager.shared.lastStatus
                        Task { await loadCatalogs() }
                    }.disabled(traktBusy)
                } else {
                    Button(traktBusy ? "Connecting…" : "Connect Trakt") {
                        Task { await connectTrakt() }
                    }.disabled(traktBusy)
                }
                Text("Uses the original vBRDC357 Trakt account client, personal catalog and persistent resume cache. A new Vision Pro install requires its own Trakt authorization.")
                    .font(.caption).foregroundStyle(.secondary)
            }
            Section("Backup / Restore — Apple TV transport") {
                TextField("Restore code", text: $restoreCode)
                    .textInputAutocapitalization(.characters)
                    .autocorrectionDisabled()
                    .privacySensitive()
                Button(restoreBusy ? "Restoring…" : "Restore Code") {
                    Task { await restorePortableProfile() }
                }
                .disabled(restoreBusy || restoreCode.isEmpty || backendURL.isEmpty)
                Text(restoreStatus).font(.caption).foregroundStyle(.secondary)
                Text("This milestone restores compatible backend, catalog and M3U fields only. Full Apple TV settings, encrypted credential-store restoration, and Favorites rehydration require the remaining vBRDC357 services. The restore code must be protected like a password.")
                    .font(.caption).foregroundStyle(.secondary)
            }
            Section("Port information") {
                LabeledContent("Build", value: "Vision Pro Build 6 · Phase 1 Unity migration")
                LabeledContent("Apple TV source", value: "vBRDC357 (unchanged reference)")
                LabeledContent("Compiled", value: "Catalogs, M3U, Trakt, original Unity catalog chrome, original backup transport")
                LabeledContent("Pending", value: "Exact full Unity shell, full restore application, VOD, EPG, membership, Aether / KS")
            }
        }.navigationTitle("Settings")
    }

    @MainActor
    private func restorePortableProfile() async {
        guard !restoreBusy else { return }
        let code = restoreCode.uppercased().filter { $0.isLetter || $0.isNumber || $0 == "-" }
        guard !code.isEmpty else {
            restoreStatus = "Enter a valid restore code."
            return
        }
        restoreBusy = true
        defer { restoreBusy = false }
        restoreStatus = "Downloading profile…"
        do {
            // Exact vBRDC357 networking and response-envelope implementation.
            let response = try await BackendProfileBackupClient.restore(baseURL: backendURL, code: code)
            guard response.ok, let profile = response.profile else {
                restoreStatus = response.message ?? "The backend did not return a usable profile."
                return
            }
            let settings = (profile["settings"] as? [String: Any]) ?? profile
            var restored: [String] = []
            if let value = settings["backendBaseURL"] as? String,
               let url = URL(string: value), ["http", "https"].contains(url.scheme?.lowercased() ?? ""),
               url.host != nil {
                backendURL = value
                restored.append("backend")
            }
            if let value = settings["stremioManifestURL"] as? String,
               let url = URL(string: value), ["http", "https"].contains(url.scheme?.lowercased() ?? ""),
               url.host != nil {
                catalogManifestURL = value
                restored.append("catalog manifest")
            } else if let urls = settings["stremioManifestURLs"] as? [String],
                      let value = urls.first,
                      let url = URL(string: value), ["http", "https"].contains(url.scheme?.lowercased() ?? ""),
                      url.host != nil {
                catalogManifestURL = value
                restored.append("catalog manifest")
            }
            if let value = settings["liveM3UURL"] as? String,
               let url = URL(string: value), ["http", "https"].contains(url.scheme?.lowercased() ?? ""),
               url.host != nil {
                livePlaylistURL = value
                restored.append("M3U")
            }
            restoreStatus = restored.isEmpty
                ? "Profile found, but no currently supported settings could be applied. Other profile fields were not imported."
                : "Restored: \(restored.joined(separator: ", ")). Full Apple TV profile parity is still pending."
            if restored.contains("catalog manifest") { await loadCatalogs() }
            if restored.contains("M3U") { await loadLineup() }
        } catch {
            restoreStatus = "Restore failed: \(error.localizedDescription)"
        }
    }

    @MainActor
    private func loadCatalogs() async {
        guard !catalogLoading else { return }
        catalogLoading = true
        catalogStatus = "Loading original Signal catalog manifest…"
        defer { catalogLoading = false }
        do {
            let rows = try await VisionSourceBridge.catalogs(manifest: catalogManifestURL)
            let traktRows: [MediaRow]
            if TraktSyncManager.shared.isConnected {
                traktRows = await TraktCatalogService.shared.fetchCatalogRows(
                    existingItems: rows.flatMap(\.items), tmdbApiKey: "")
            } else { traktRows = [] }
            catalogRows = traktRows + rows
            catalogStatus = "\(catalogRows.count) catalog rows • \(catalogRows.reduce(0) { $0 + $1.items.count }) titles"
            traktStatus = TraktSyncManager.shared.lastStatus
        } catch { catalogStatus = "Error: \(error.localizedDescription)" }
    }

    @MainActor
    private func connectTrakt() async {
        guard !traktBusy else { return }
        traktBusy = true
        defer { traktBusy = false }
        do {
            let code = try await TraktSyncManager.shared.beginDeviceLink()
            traktLinkCode = code
            traktStatus = "Authorize using the code shown below. Waiting for Trakt…"
            let account = try await TraktSyncManager.shared.pollDeviceAuthorization(code)
            traktLinkCode = nil
            traktStatus = "Connected: \(account)"
            await loadCatalogs()
        } catch {
            traktLinkCode = nil
            traktStatus = "Trakt: \(error.localizedDescription)"
        }
    }

    @MainActor
    private func loadLineup() async {
        guard !liveLoading else { return }
        liveLoading = true
        liveStatus = "Loading lineup…"
        defer { liveLoading = false }
        do {
            channels = try await VisionSourceBridge.channels(playlist: livePlaylistURL)
            if !channels.contains(where: { $0.category == category }) { category = "All" }
            liveStatus = "\(channels.count) channels • M3U source"
        } catch { liveStatus = "Error: \(error.localizedDescription)" }
    }

    private func startPlayback(title: String) {
        let trimmed = streamURL.trimmingCharacters(in: .whitespacesAndNewlines)
        guard let url = URL(string: trimmed), ["https", "http"].contains(url.scheme?.lowercased() ?? ""), url.host != nil else {
            playbackError = "Enter a valid HTTP or HTTPS stream URL."
            selection = .player
            return
        }
        playbackError = ""
        player?.pause()
        player = AVPlayer(url: url)
        playingTitle = title
        selection = .player
        player?.play()
    }

    @MainActor
    private func checkBackend() async {
        guard !checking else { return }
        checking = true
        defer { checking = false }
        guard let url = URL(string: backendURL.trimmingCharacters(in: .whitespacesAndNewlines)),
              ["https", "http"].contains(url.scheme?.lowercased() ?? ""), url.host != nil else {
            backendStatus = "Enter a valid backend URL."
            return
        }
        var request = URLRequest(url: url.appendingPathComponent("health"), timeoutInterval: 12)
        request.setValue("application/json", forHTTPHeaderField: "Accept")
        do {
            let (_, response) = try await URLSession.shared.data(for: request)
            if let http = response as? HTTPURLResponse {
                backendStatus = "HTTP \(http.statusCode) • \(url.host ?? "backend")"
            } else { backendStatus = "Server responded" }
        } catch { backendStatus = "Unreachable: \(error.localizedDescription)" }
    }
}
