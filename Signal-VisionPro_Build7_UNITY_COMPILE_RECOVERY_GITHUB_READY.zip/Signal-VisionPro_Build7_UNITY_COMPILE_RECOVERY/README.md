# SIGNAL Vision Pro — Build 6 / Unity migration (NOT feature parity)

**Source baseline:** user-supplied Apple TV vBRDC357, preserved in `AppleTVSource_vBRDC357/` byte-for-byte for the main source file. Apple TV repository is not modified.

## What is newly compiled into the visionOS target
- `SharedFromAppleTV/UnityCatalogVisualSystem.swift` — original vBRDC357 Unity catalogue visuals, copied byte-for-byte and attached to poster cards.
- `SharedFromAppleTV/BackendProfileBackupClient.swift` — original vBRDC357 restore-code backend client, copied byte-for-byte.
- `Sources/SignalRootView.swift` — replaced the unrelated visionOS NavigationSplitView/sidebar with a black Unity-style compact top navigation, original Signal wordmark, dark posters, and a four-column Live TV channel grid using real M3U data.
- A visible Backup / Restore section uses the original transport to retrieve a restore code. **Only backend, catalog manifest, and M3U source are applied by this build.** The rest of the profile is NOT applied and is not advertised as restored.
- Original Trakt, models, and existing Build 5 source pipeline retained.

## What is not yet working / not compiled
The actual `DebridChannelsTVOSApp.swift` 3MB app UI and `CatalogStore.swift` are **still reference-only**: tvOS-specific navigation, UIKit/TVServices APIs, player bridge, and dependencies require a real visionOS port. The exact original Live TV Preview Mirror, full EPG, source resolver, membership UX, sports/favorites UI, all settings, full backup/restore semantics, AetherEngine and KSPlayer are **NOT** integrated. Do not install this as a claimed 100% port. This is a visual and transport migration milestone only.

## External player / SKYBOX
SKYBOX advertises native visionOS playback and cinema environments, plus SMB/DLNA/WebDAV streaming. We have **not verified a public visionOS deep-link API** that can open a specific third-party HTTPS VOD stream from SIGNAL. Therefore no speculative SKYBOX launch URL or fake 'handoff' button has been added. It cannot replace Signal's own player and its Trakt/resume lifecycle unless verified and tested.

## Build
Extract all files into the separate Signal-VisionPro repository. The universal GitHub Actions workflow accepts extracted source or ONE ZIP whose name begins `Signal-VisionPro_Build6`. Simulator and unsigned device build artifacts are produced only if the respective Xcode builds succeed. No Xcode or real-device test was available in this environment.

## Subsequent phased work
1. Port original Unity shell and feature services one-by-one, compile and compare screen-by-screen against vBRDC357; complete full restore including secure credential migration.
2. Confirm visionOS platform availability and actual device/simulator slices for both playback engines. Preserve Aether primary, KS fallback where supported.
3. Validate full app on physical Vision Pro with real media, restore code, Live TV/EPG and look-and-pinch navigation.
4. Add separate immersive cinema after parity and playback testing, reusing the same playback ownership/state.
