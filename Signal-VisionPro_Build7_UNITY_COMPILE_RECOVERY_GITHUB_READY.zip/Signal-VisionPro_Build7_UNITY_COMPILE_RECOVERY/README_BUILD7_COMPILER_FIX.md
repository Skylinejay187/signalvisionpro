# Build 7: Unity visual compiler recovery

Based on Build 6. The GitHub build log identified missing `RemoteImageFit` and `SettingsRoundedFocusVisual` used in the copied Unity visual source, plus two SwiftUI type-check timeout diagnostics likely cascading from the missing types.

- Added visionOS-specific adapters for the absent UI types, retaining the original `UnityCatalogVisualSystem.swift` untouched.
- Original Apple TV source under `AppleTVSource_vBRDC357/` is untouched.
- `RemoteImageFit` currently uses native `AsyncImage`, **not** the original tvOS image loader, cache, or playback-priority controls. This is a compile recovery only, not feature or image-pipeline parity.
- Updated workflow ZIP detection to Build 7 and added a source presence check.
- Version 0.7.0 (7).

The error log had Swift compiler timeout diagnostics in the same expressions that referenced missing UI types. Re-run GitHub build to establish whether any independent type-check errors remain. Device IPA is generated only if both simulator and device steps succeed. No Xcode or real-headset test was performed here.
