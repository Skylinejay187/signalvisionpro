import SwiftUI

// visionOS adapter for tvOS image rendering dependencies. This retains the original
// Unity composition but does NOT yet port the Apple TV custom image/cache pipeline.
struct RemoteImageFit: View {
    enum Mode { case fill, fit, stretch }
    let url: String?
    var mode: Mode = .fill
    var showPlaceholder: Bool = true

    @ViewBuilder private func sized(_ image: Image) -> some View {
        switch mode {
        case .fill: image.resizable().scaledToFill()
        case .fit: image.resizable().scaledToFit()
        case .stretch: image.resizable()
        }
    }

    var body: some View {
        if let raw = url, let resolved = URL(string: raw),
           let scheme = resolved.scheme?.lowercased(), ["https", "http"].contains(scheme) {
            AsyncImage(url: resolved) { phase in
                switch phase {
                case .success(let image): sized(image)
                case .empty, .failure:
                    if showPlaceholder { Color.white.opacity(0.035) } else { Color.clear }
                @unknown default: Color.clear
                }
            }
        } else {
            if showPlaceholder { Color.white.opacity(0.035) } else { Color.clear }
        }
    }
}

// tvOS's button-style modifier is unavailable as-is on visionOS. Keep the
// original rounded shape and let visionOS own native look-and-pinch focus.
struct SettingsRoundedFocusVisual: ViewModifier {
    let cornerRadius: CGFloat
    func body(content: Content) -> some View {
        let shape = RoundedRectangle(cornerRadius: cornerRadius, style: .continuous)
        content.buttonStyle(.plain).contentShape(shape).clipShape(shape)
    }
}
