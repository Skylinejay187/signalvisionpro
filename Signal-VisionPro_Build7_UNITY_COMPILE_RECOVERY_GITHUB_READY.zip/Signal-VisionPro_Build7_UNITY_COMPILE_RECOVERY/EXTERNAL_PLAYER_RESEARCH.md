# SKYBOX handoff verification
SKYBOX App Store: https://apps.apple.com/us/app/skybox-media-player/id6499200560
Native Vision Pro player with cinema environments; supports local files, SMB, UPnP/DLNA and WebDAV per store listing/release notes.
No official public visionOS URL scheme, callback API, documented stream-URL handoff contract or playback position return was found during research. A forum request for external handoff and a developer comment about reworking external-player features are not proof of an available visionOS API. Do not invent a `skybox://` URL or offer a nonworking handoff button.
Apple TV's vBRDC357 `ExternalPlayerSupport.swift` supports Infuse, VLC and SenPlayer via documented-in-project custom schemes; it has no SKYBOX target. Those schemes are not automatically valid on visionOS. Await vendor's supported handoff contract before integration.
