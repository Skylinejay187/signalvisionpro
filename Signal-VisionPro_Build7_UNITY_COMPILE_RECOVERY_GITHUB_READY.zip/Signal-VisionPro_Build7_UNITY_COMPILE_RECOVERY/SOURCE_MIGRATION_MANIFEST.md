# vBRDC357 source usage
- Original reference: `AppleTVSource_vBRDC357/Sources/DebridChannelsTVOSApp.swift` = vBRDC357 bytes, unchanged, not compiled into visionOS.
- Original compiled file: `SharedFromAppleTV/UnityCatalogVisualSystem.swift` = vBRDC357 bytes, unchanged.
- Original compiled file: `SharedFromAppleTV/BackendProfileBackupClient.swift` = vBRDC357 bytes, unchanged.
- Prior compiled files: original Trakt manager, Trakt catalogs, resume cache, models and artwork cache from Build 5.
- Adapted visionOS views: `Sources/SignalRootView.swift`, which is not identical to original tvOS UI.
Missing original compiled shell, resolver, EPG and player integration: clearly incomplete.
