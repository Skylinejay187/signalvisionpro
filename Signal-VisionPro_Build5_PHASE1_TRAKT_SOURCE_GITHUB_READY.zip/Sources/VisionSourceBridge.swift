import Foundation
import SwiftUI

// visionOS adaptation of vBRDC357 CatalogStore's official Stremio manifest + batch-row
// transport and LiveTVSourceModel's M3U ingest. Uses the unchanged MediaItem,
// MediaRow and LiveTVChannel types compiled from AppleTVSource_vBRDC357.
// Does not claim parity with CatalogStore's customization/cache/source logic.
enum VisionSourceBridge {
    static let officialManifest = "https://catalog.skylinejay187.it.com/manifest.json"

    private static func json(at url: URL, maxBytes: Int = 12_000_000) async throws -> Any {
        guard ["https", "http"].contains(url.scheme?.lowercased() ?? ""), url.host != nil else { throw URLError(.badURL) }
        var request = URLRequest(url: url, timeoutInterval: 18)
        request.setValue("application/json", forHTTPHeaderField: "Accept")
        let (data, response) = try await URLSession.shared.data(for: request)
        guard let response = response as? HTTPURLResponse, (200...299).contains(response.statusCode) else { throw URLError(.badServerResponse) }
        guard data.count <= maxBytes else { throw URLError(.dataLengthExceedsMaximum) }
        return try JSONSerialization.jsonObject(with: data)
    }

    private static func object(_ value: Any?) -> [String: Any] { value as? [String: Any] ?? [:] }
    private static func string(_ value: Any?) -> String? {
        if let text = value as? String { return text }
        if let number = value as? NSNumber { return number.stringValue }
        return nil
    }
    private static func text(_ obj: [String: Any], _ key: String) -> String? { string(obj[key]) }
    private static func webURL(_ raw: String?, relativeTo base: URL) -> URL? {
        guard let raw, let url = URL(string: raw, relativeTo: base)?.absoluteURL,
              ["https", "http"].contains(url.scheme?.lowercased() ?? ""), url.host != nil else { return nil }
        return url
    }
    private static func media(_ raw: [String: Any], kind: String, title: String, addon: String) -> MediaItem? {
        guard let id = text(raw, "id"), !id.isEmpty,
              let name = text(raw, "name"), !name.isEmpty else { return nil }
        let poster = text(raw, "poster")
        // Same core identity as original CatalogStore: id, declared type and row.
        let release = text(raw, "releaseInfo") ?? ""
        let year = String(release.prefix(4))
        return MediaItem(
            id: id, tmdbId: text(raw, "tmdbId") ?? text(raw, "tmdb_id"),
            imdbId: text(raw, "imdbId") ?? text(raw, "imdb_id"),
            tvdbId: text(raw, "tvdbId") ?? text(raw, "tvdb_id"),
            title: name, year: year, type: kind, catalog: title,
            description: text(raw, "description") ?? "",
            genres: raw["genres"] as? [String] ?? [],
            rating: text(raw, "imdbRating") ?? "—",
            posterURL: poster, landscapeURL: text(raw, "background") ?? poster,
            logoURL: text(raw, "logo"), addonName: addon
        )
    }

    static func catalogs(manifest rawURL: String) async throws -> [MediaRow] {
        guard let manifestURL = URL(string: rawURL.trimmingCharacters(in: .whitespacesAndNewlines)),
              manifestURL.host != nil else { throw URLError(.badURL) }
        let manifest = object(try await json(at: manifestURL, maxBytes: 1_500_000))
        let addon = text(manifest, "name") ?? "Signal Catalog"
        let catalogs = (manifest["catalogs"] as? [Any] ?? []).map { object($0) }
        guard !catalogs.isEmpty else { throw URLError(.cannotParseResponse) }
        let base = manifestURL.deletingLastPathComponent()
        let extensionInfo = object(manifest["debridChannels"])

        // Original vBRDC357 CatalogStore takes the same all-in-one batch endpoint first.
        if let batchURL = webURL(text(extensionInfo, "batchRowsURL"), relativeTo: base),
           let payload = try? await json(at: batchURL),
           let batch = object(payload)["rows"] as? [Any] {
            var rows: [MediaRow] = []
            for entry in batch {
                let row = object(entry)
                let rawName = text(row, "name") ?? text(row, "id") ?? "Catalog"
                let rawID = text(row, "id") ?? rawName
                let declared = catalogs.first { text($0, "name") == rawName && text($0, "id") == rawID }
                    ?? catalogs.first { text($0, "name") == rawName }
                let kind = text(declared ?? [:], "type") ?? text(row, "type") ?? "movie"
                let metas = row["metas"] as? [Any] ?? []
                let items = metas.compactMap { media(object($0), kind: kind, title: rawName, addon: addon) }
                if !items.isEmpty {
                    rows.append(MediaRow(id: "\(kind)-\(rawID)-\(addon)", title: rawName, items: items))
                }
            }
            if !rows.isEmpty { return rows }
        }

        // Standards-compatible fallback: bounded manifest catalog endpoints.
        var rows: [MediaRow] = []
        for entry in catalogs.prefix(24) {
            if Task.isCancelled { break }
            guard let id = text(entry, "id"), let kind = text(entry, "type") else { continue }
            let name = text(entry, "name") ?? id
            let safeKind = kind.addingPercentEncoding(withAllowedCharacters: .urlPathAllowed) ?? kind
            let safeID = id.addingPercentEncoding(withAllowedCharacters: .urlPathAllowed) ?? id
            guard let endpoint = webURL("catalog/\(safeKind)/\(safeID).json", relativeTo: base),
                  let payload = try? await json(at: endpoint, maxBytes: 3_000_000) else { continue }
            let metas = object(payload)["metas"] as? [Any] ?? []
            let items = metas.compactMap { media(object($0), kind: kind, title: name, addon: addon) }
            if !items.isEmpty { rows.append(MediaRow(id: "\(kind)-\(id)-\(addon)", title: name, items: items)) }
        }
        guard !rows.isEmpty else { throw URLError(.cannotParseResponse) }
        return rows
    }

    static func channels(playlist rawURL: String) async throws -> [LiveTVChannel] {
        guard let url = URL(string: rawURL.trimmingCharacters(in: .whitespacesAndNewlines)),
              ["https", "http"].contains(url.scheme?.lowercased() ?? ""), url.host != nil else { throw URLError(.badURL) }
        var request = URLRequest(url: url, timeoutInterval: 20)
        request.setValue("audio/x-mpegurl,application/x-mpegURL,text/plain,*/*", forHTTPHeaderField: "Accept")
        let (data, response) = try await URLSession.shared.data(for: request)
        guard let response = response as? HTTPURLResponse, (200...299).contains(response.statusCode),
              data.count <= 12_000_000, let body = String(data: data, encoding: .utf8) else { throw URLError(.badServerResponse) }
        var results: [LiveTVChannel] = []
        var attributes: [String: String] = [:]
        var pendingName = ""
        for rawLine in body.components(separatedBy: .newlines) {
            let line = rawLine.trimmingCharacters(in: .whitespacesAndNewlines)
            if line.hasPrefix("#EXTINF:") {
                let metadata = String(line.dropFirst("#EXTINF:".count))
                pendingName = metadata.components(separatedBy: ",").dropFirst().joined(separator: ",").trimmingCharacters(in: .whitespacesAndNewlines)
                attributes = [:]
                let pattern = #"([A-Za-z0-9_-]+)="([^"]*)""#
                if let regex = try? NSRegularExpression(pattern: pattern) {
                    let range = NSRange(metadata.startIndex..<metadata.endIndex, in: metadata)
                    for match in regex.matches(in: metadata, range: range) where match.numberOfRanges == 3 {
                        if let key = Range(match.range(at: 1), in: metadata), let value = Range(match.range(at: 2), in: metadata) {
                            attributes[String(metadata[key])] = String(metadata[value])
                        }
                    }
                }
            } else if !line.isEmpty && !line.hasPrefix("#"), !pendingName.isEmpty,
                      let stream = webURL(line, relativeTo: url) {
                let category = attributes["group-title"] ?? "Channels"
                let number = attributes["tvg-chno"] ?? String(results.count + 1)
                let name = attributes["tvg-name"] ?? pendingName
                let logo = attributes["tvg-logo"] ?? ""
                results.append(LiveTVChannel(id: results.count + 1, logo: "tv", number: number,
                    name: name, category: category, now: "", next: "", description: "",
                    accent: .blue, streamURL: stream.absoluteString, iconURL: logo,
                    tvgID: attributes["tvg-id"] ?? "", source: "M3U"))
                pendingName = ""
                if results.count >= 10_000 { break }
            }
        }
        guard !results.isEmpty else { throw URLError(.cannotParseResponse) }
        return results
    }
}
