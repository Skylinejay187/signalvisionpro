import SwiftUI

@main
struct SignalVisionProApp: App {
    var body: some Scene {
        WindowGroup {
            SignalRootView()
        }
        .defaultSize(width: 1160, height: 780)
    }
}
