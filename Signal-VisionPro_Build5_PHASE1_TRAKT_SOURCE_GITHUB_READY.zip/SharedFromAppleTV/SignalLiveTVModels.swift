import SwiftUI
import Foundation

// Verbatim vBRDC357 Live TV channel and guide model declarations.
struct LiveTVChannel: Identifiable, Hashable {
    let id: Int
    let logo: String
    let number: String
    let name: String
    let category: String
    let now: String
    let next: String
    let description: String
    let accent: Color
    var streamURL: String = ""
    var iconURL: String = ""
    var tvgID: String = ""
    var source: String = "Demo"
}

extension LiveTVChannel {
    var bestArtworkURL: String? {
        let cleanIcon = iconURL.trimmingCharacters(in: .whitespacesAndNewlines)
        if cleanIcon.hasPrefix("http://") || cleanIcon.hasPrefix("https://") { return cleanIcon }
        return nil
    }

    var isXtreamSource: Bool {
        source.lowercased().contains("xtream") || streamURL.lowercased().contains("/live/")
    }
}

struct LiveProgram: Identifiable, Hashable, Sendable {
    // vBRDC119: UUID-per-initialization made every guide cell look brand new to SwiftUI on
    // every provider refresh — and even on fallback `programs(for:)` calls created during a
    // normal body evaluation. Stable content identity lets tvOS retain the same program-cell
    // views until the actual schedule row changes instead of destroying/recreating them.
    let id: UInt64
    let title: String
    let width: CGFloat
    let isLive: Bool
    var description: String = ""
    var startText: String = ""
    var endText: String = ""
    var imageURL: String = ""
    // v276: keep real guide timing so the renderer uses current/future listings
    // instead of the first programs in the XMLTV file. This fixes partially
    // populated guide rows after real channels load.
    var startDate: Date? = nil
    var endDate: Date? = nil

    init(
        title: String,
        width: CGFloat,
        isLive: Bool,
        description: String = "",
        startText: String = "",
        endText: String = "",
        imageURL: String = "",
        startDate: Date? = nil,
        endDate: Date? = nil
    ) {
        self.title = title
        self.width = width
        self.isLive = isLive
        self.description = description
        self.startText = startText
        self.endText = endText
        self.imageURL = imageURL
        self.startDate = startDate
        self.endDate = endDate
        self.id = Self.makeStableID(
            title: title,
            width: width,
            startText: startText,
            endText: endText,
            startDate: startDate,
            endDate: endDate
        )
    }

    private static func makeStableID(
        title: String,
        width: CGFloat,
        startText: String,
        endText: String,
        startDate: Date?,
        endDate: Date?
    ) -> UInt64 {
        var hash: UInt64 = 1469598103934665603
        @inline(__always) func mixByte(_ byte: UInt8, into hash: inout UInt64) {
            hash ^= UInt64(byte)
            hash &*= 1099511628211
        }
        func mixString(_ value: String, into hash: inout UInt64) {
            for byte in value.utf8 { mixByte(byte, into: &hash) }
            mixByte(0xff, into: &hash)
        }
        func mixUInt64(_ value: UInt64, into hash: inout UInt64) {
            var value = value
            for _ in 0..<8 {
                mixByte(UInt8(truncatingIfNeeded: value), into: &hash)
                value >>= 8
            }
        }

        // Identity represents the schedule slot, not presentation metadata. Artwork,
        // description enrichment, width correction, and the live/not-live boundary may
        // legitimately change while SwiftUI should keep the same guide cell alive.
        mixString(title, into: &hash)
        if let startDate {
            mixUInt64(startDate.timeIntervalSince1970.bitPattern, into: &hash)
        } else {
            mixString(startText, into: &hash)
        }
        if let endDate {
            mixUInt64(endDate.timeIntervalSince1970.bitPattern, into: &hash)
        } else {
            mixString(endText, into: &hash)
            mixUInt64(Double(width).bitPattern, into: &hash)
        }
        return hash
    }

    func progress(at now: Date) -> CGFloat {
        guard let startDate, let endDate, endDate > startDate else { return 0.5 }
        let duration = endDate.timeIntervalSince(startDate)
        guard duration > 0 else { return 0.5 }
        let elapsed = now.timeIntervalSince(startDate)
        return CGFloat(min(max(elapsed / duration, 0.0), 1.0))
    }

    var liveProgress: CGFloat { progress(at: Date()) }

    func secondsRemaining(at now: Date) -> TimeInterval? {
        guard let endDate else { return nil }
        return max(0, endDate.timeIntervalSince(now))
    }

    func secondsUntilStart(at now: Date) -> TimeInterval? {
        guard let startDate else { return nil }
        return max(0, startDate.timeIntervalSince(now))
    }

    func isAiring(at now: Date) -> Bool {
        guard let startDate, let endDate, endDate > startDate else { return isLive }
        return startDate <= now && now < endDate
    }

    var hasRealTiming: Bool {
        guard let startDate, let endDate else { return false }
        return endDate > startDate
    }
}


