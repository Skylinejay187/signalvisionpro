import Foundation

// Extracted unchanged from vBRDC357 CatalogStore.swift: shared media models.
struct CastMember: Identifiable, Hashable, Codable {
    var id: String {
        if let tmdbPersonId { return "tmdb-person-\(tmdbPersonId)" }
        return name.lowercased() + "|" + (role ?? "")
    }
    var name: String
    var role: String? = nil
    var imageURL: String? = nil
    // v1134 Phase 13: retain the stable TMDB person identity from credits so Cast Explorer
    // opens the exact person without a name-search round trip when metadata provides it.
    var tmdbPersonId: Int? = nil
}

struct MediaItem: Identifiable, Hashable, Codable {
    let id: String
    var tmdbId: String? = nil
    var imdbId: String? = nil
    var tvdbId: String? = nil
    var title: String
    var year: String
    var type: String
    var catalog: String
    var description: String
    var genres: [String]
    var rating: String
    var posterURL: String?
    var landscapeURL: String?
    var logoURL: String?
    var previewURL: String? = nil
    // v274: Preserve the Stremio JSON add-on identity that supplied this catalog item
    // so UI cards/details can show the corresponding add-on icon/source name.
    var addonName: String? = nil
    var addonIconURL: String? = nil
    var seasonNumber: Int? = nil
    var episodeNumber: Int? = nil
    // v468: Optional credits surfaced in the movie/show popup.
    // These stay app-local and are hydrated from Stremio/Cinemeta metadata when available.
    var cast: [String] = []
    var directors: [String] = []
    // v469: actor face cards for popup cast row. Uses TMDB credits images when available.
    var castMembers: [CastMember] = []
    // v607: Optional episode air/release date used for next-up alerts.
    var airDateString: String? = nil
    var episodeDateStrings: [String] = []
    // v616: movie-only collection/franchise shelf. Empty unless TMDB confirms a real belongs_to_collection result.
    var franchiseItems: [MediaItem] = []
}


struct CatalogRowVisualTheme: Hashable, Codable {
    var style: String? = nil
    var accentHex: String? = nil
    var secondaryHex: String? = nil
    var symbol: String? = nil
    var labelStyle: String? = nil
}

struct CatalogRowPresentation: Hashable, Codable {
    var shortName: String? = nil
    var description: String? = nil
    var rowKind: String? = nil
    var providerName: String? = nil
    var themeLogoURL: String? = nil
    var providerBadgeURL: String? = nil
    var backgroundURL: String? = nil
    var theme: CatalogRowVisualTheme? = nil
}

struct MediaRow: Identifiable, Hashable, Codable {
    let id: String
    var title: String
    var items: [MediaItem]
    var presentation: CatalogRowPresentation? = nil

    init(id: String, title: String, items: [MediaItem], presentation: CatalogRowPresentation? = nil) {
        self.id = id
        self.title = title
        self.items = items
        self.presentation = presentation
    }
}

