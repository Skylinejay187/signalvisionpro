# Vision Pro GitHub workflow fix 3

The uploaded GitHub log shows two problems: the macOS Bash 3.2 shell has no `mapfile`, and the repository contains the Build 2 source as a ZIP rather than extracted files. This workflow removes `mapfile` and can automatically extract one `Signal-VisionPro_Build2*.zip` from repository root if no extracted visionOS project exists.

**Option A:** Upload the entire Build 2 ZIP *as a ZIP* at repository root and replace `.github/workflows/build-visionos.yml` with this new workflow.

**Option B:** Extract the full package and upload its contents, including root `project.yml`, `Sources`, `SharedFromAppleTV`, `Resources`, and `.github/workflows/build-visionos.yml`.

If a full GitHub project is uploaded, use Option B. The Apple TV reference project is excluded from project selection. Actual visionOS compilation is not yet verified.
