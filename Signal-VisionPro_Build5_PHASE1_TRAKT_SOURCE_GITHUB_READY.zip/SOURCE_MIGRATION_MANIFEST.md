# Actual-source migration evidence — Build 4

- Anchor: `DebridChannels_vBRDC357_PREVIEW_MIRROR_HEADER_POSITION_FIX_GITHUB_READY.zip` copied into `AppleTVSource_vBRDC357/` unchanged (original tvOS app cannot compile wholesale on visionOS).
- Compiled unchanged: `PlainHTTPClient.swift`, `BackendProfileBackupClient.swift`, `SportsChannelClassifierManager.swift`, `LiveTVProgramProgressLine.swift`, and **new** `CatalogArtworkCacheManager.swift`; `SignalMediaModels.swift` and `SignalLiveTVModels.swift` contain source-extracted original model definitions. The original implementations are not generic stand-ins.
- Compiled new platform adapters: `Sources/VisionSourceBridge.swift` uses the identical built-in manifest URL and `debridChannels.batchRowsURL` flow as original `CatalogStore.fetchRows`, maps actual Stremio metas to original `MediaItem` / `MediaRow`, and adapts original M3U source parsing to native visionOS UI. `Sources/SignalRootView.swift` renders real catalogs and playable channel lists, with a native gaze/pinch-friendly view hierarchy.
- Compiled assets: all `Resources/Assets.xcassets/*.imageset` from original app; exclude only `AppIcon.brandassets` because tvOS image stack icon cannot serve as visionOS app icon. Device workflow fails if `Assets.car` isn't present.
- Explicitly **not** compiled: original tvOS app shell, `CatalogStore.swift` itself, full Live TV guide UI, tvOS Top Shelf, playback KSPlayer/Aether frameworks, Trakt and membership. `AppleTVSource_vBRDC357/` is source reference rather than a linked target.
- Built-in catalog is *not* a substitute fake feed: its upstream service must be reachable. If the service fails, UI shows an error and no invented entries.

## Build 5 additions
Original vBRDC357 source files now directly compiled unchanged: `TraktSyncManager.swift`, `TraktCatalogService.swift`, `PlaybackResumeCache.swift`. These three compile together with the original `MediaItem` model (checked on Linux; warnings about older Sendable queue closures remain). The native visionOS UI starts Trakt device authorization, polls and shows actual Trakt shelves. This is NOT complete Trakt feature parity.
