# Signal Vision Pro — Build 3 / unsigned device IPA workflow

This is the actual source-first port from Apple TV vBRDC357 retained from Build 2, **not yet full feature parity**. Build 3 adds an unsigned physical Vision Pro build and IPA artifact to the simulator workflow. Original tvOS source is preserved separately in `AppleTVSource_vBRDC357/` and remains unmodified.

## GitHub installation
Upload **extracted contents** of this ZIP to the root of the separate Signal-VisionPro repository, including `.github/workflows/build-visionos.yml`. Alternatively the workflow detects and extracts one Build 2 ZIP when the source hasn't been extracted, but uploading extracted Build 3 contents is preferred. Run Actions > Signal Vision Pro - Simulator and Device IPA.

## Expected artifacts after successful run
- `SignalVisionPro-UNSIGNED-visionOS-DEVICE-IPA`: download artifact and extract its `.ipa` file for a compatible visionOS signing service; **unsigned, not installable directly**.
- `SignalVisionPro-simulator`: ZIP for the visionOS simulator (not suitable for device signing).
- Separate device and simulator build logs.

The device build uses `-sdk xros`, `generic/platform=visionOS` and `CODE_SIGNING_ALLOWED=NO`; the IPA contains `Payload/SignalVisionPro.app`. The signing provider must sign a **visionOS** app for your device; support of a service does not guarantee this specific IPA is accepted. No certificate or private key is stored in the repo. An unsigned IPA is not an Apple-exported signed IPA and some signing services may need the raw `.app` instead.

## Port status
Only selected unchanged Apple TV model/network files currently compile as shared visionOS source. Most tvOS UI including full Live TV Dashboard, Preview Mirror, catalogs, guide, membership and player engines remains under `AppleTVSource_vBRDC357/` pending adaptation. The build artifact is an early port shell, **not the complete Signal app**. Real GitHub Xcode device build and signing need to be checked; this environment cannot run Apple's visionOS SDK.
