# Signal Vision Pro Build 5 — actual Apple TV source integration, phase 1 (partial)

This is an INCOMPLETE port based on the original untouched vBRDC357 source. Do not market as full Signal. New in Build 5: the three real Trakt sync, catalog and persistent playback-resume source modules are part of the compiled target; native Settings offers Trakt device authorization, and catalog loading includes account shelves. The complete original tvOS UI, resolver, membership and third-party players are NOT operational. See `PHASE_STATUS.md` and `SOURCE_MIGRATION_MANIFEST.md`.

Upload this ZIP's extracted contents to the *separate* Vision Pro repository, replacing the previous source. The workflow produces unsigned device IPA and simulator ZIP. Actual GitHub/Xcode compile and headset operation remain unverified here. Original tvOS repo stays untouched.
