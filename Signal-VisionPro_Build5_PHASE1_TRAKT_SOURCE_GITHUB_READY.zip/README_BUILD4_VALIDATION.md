# Validation and next integration gate

Local checks: Swift frontend parse of all Sources and SharedFromAppleTV; original helper byte-for-byte check; full original asset image sets present; YAML structure parse; ZIP integrity. These checks **do not** prove Xcode type checking, media playback, backend integration or physical Vision Pro installation.

After GitHub Actions, verify simulator and device compilation, that device app includes nonempty `Assets.car`, catalogs actually populate, M3U lineup loads and AVKit handles your channels. Archive device build log when reporting an error. Do not sign/ship as a complete port until full catalog/state system, TV dashboard and guide, account/auth, VOD resolvers, and compatible player engines are migrated and tested.
