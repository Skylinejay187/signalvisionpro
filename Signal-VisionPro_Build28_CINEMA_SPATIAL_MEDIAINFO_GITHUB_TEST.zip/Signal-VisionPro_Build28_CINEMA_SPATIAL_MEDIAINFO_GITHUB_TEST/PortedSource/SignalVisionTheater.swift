import SwiftUI
import RealityKit
import UIKit

@MainActor
final class SignalVisionTheaterCoordinator: ObservableObject {
    static let shared = SignalVisionTheaterCoordinator()
    enum Mode: String { case app, playback }
    @Published var mode: Mode = .app
    @Published var immersiveActive = false
    @Published var transitionInProgress = false
    @Published var entryFailure: String?
    var didAttemptAutomaticEntry = false
    private init() {}
}

enum SignalVisionRemoteEvent {
    static let direction = Notification.Name("SignalVision.Remote.Direction")
    static let back = Notification.Name("SignalVision.Remote.Back")
    static let home = Notification.Name("SignalVision.Remote.Home")
    static let catalogDirection = Notification.Name("SignalVision.Catalog.Direction")
}

// Build 28: spatially stable, viewer-safe Classic Cinema. Keep Build 27's
// scene declaration/manifest and playback engine unchanged. Geometry has no
// colliders; the viewer starts in the CENTER AISLE, not inside a chair/wall.
struct SignalVisionTheaterSpace: View {
    @EnvironmentObject private var store: CatalogStore
    @EnvironmentObject private var unityCore: UnityAppCore
    @EnvironmentObject private var theater: SignalVisionTheaterCoordinator
    @Environment(\.dismissImmersiveSpace) private var dismissImmersiveSpace
    @Environment(\.openWindow) private var openWindow
    @Environment(\.dismissWindow) private var dismissWindow
    @AppStorage("signalVisionPersistentTheaterV22") private var persistentTheater = true
    @AppStorage("signalVisionCinemaEnvironmentV28") private var cinemaEnvironment = "Classic Cinema"
    @State private var cinemaScreenReady = false
    private let diagnostics = SignalVisionDiagnostics.shared

    var body: some View {
        RealityView { content, attachments in
            diagnostics.record("reality", "Build28 cinema construction started")
            content.add(makeAuditorium())
            // Cinema controls are viewer-side and to the LOWER RIGHT, never in the
            // middle of the movie screen. They remain a real gaze/pinch target.
            if let controls = attachments.entity(for: "signal-controls") {
                controls.position = [1.15, 0.68, -1.48]
                controls.scale = [0.72, 0.72, 0.72]
                content.add(controls)
            }
            if let screen = attachments.entity(for: "signal-screen") {
                screen.position = [0, 1.82, -7.26]
                // Attachment is 1600 x 900 pt: 5.36 m x 3.015 m, 16:9.
                screen.scale = [0.00335, 0.00335, 0.00335]
                content.add(screen)
            }
            diagnostics.record("reality", "auditorium, fixed cinema screen and viewer-side controls attached")
        } attachments: {
            Attachment(id: "signal-screen") {
                Group {
                    if cinemaScreenReady {
                        // Original Signal RootView, store, and existing KSPlayer/Aether
                        // player are the ONLY playback owner. No second AVPlayer.
                        RootView()
                            .environmentObject(store)
                            .environmentObject(unityCore)
                    } else {
                        ZStack {
                            Color.black
                            VStack(spacing: 18) {
                                Image(systemName: "theatermasks.fill").font(.system(size: 90))
                                Text("SIGNAL · CLASSIC CINEMA").font(.system(size: 48, weight: .bold))
                                Text("Preparing cinema screen…").font(.system(size: 30))
                            }.foregroundStyle(.white)
                        }
                    }
                }
                .frame(width: 1600, height: 900)
                .clipped()
                .background(.black)
                .clipShape(RoundedRectangle(cornerRadius: 12))
            }
            Attachment(id: "signal-controls") {
                Button("Exit Theater", systemImage: "xmark.circle.fill") {
                    Task { @MainActor in
                        openWindow(id: "signal-main")
                        await dismissImmersiveSpace()
                        theater.immersiveActive = false
                        diagnostics.record("lifecycle", "exit button dismissed immersive space")
                    }
                }
                .font(.system(size: 17, weight: .semibold))
                .buttonStyle(.bordered)
                .hoverEffect(.highlight)
                .padding(8)
                .background(.ultraThinMaterial, in: Capsule())
                .accessibilityLabel("Exit theater and return to Signal")
            }
        }
        .onAppear {
            theater.immersiveActive = true
            theater.transitionInProgress = false
            theater.entryFailure = nil
            theater.didAttemptAutomaticEntry = true
            diagnostics.record("lifecycle", "Build28 immersive scene onAppear")
            diagnostics.sceneSnapshot("immersive-appeared")
            // One playback owner; close the original window only after immersive
            // scene has appeared, then re-open it before exiting the theater.
            dismissWindow(id: "signal-main")
            Task { @MainActor in
                try? await Task.sleep(nanoseconds: 450_000_000)
                guard theater.immersiveActive else { return }
                cinemaScreenReady = true
                diagnostics.record("lifecycle", "full original Signal UI/player attached to cinema screen")
            }
        }
        .onDisappear {
            theater.immersiveActive = false
            cinemaScreenReady = false
            diagnostics.record("lifecycle", "Build28 immersive scene onDisappear")
            diagnostics.sceneSnapshot("immersive-disappeared")
        }
        .onChange(of: store.playbackURL) { url in
            if url != nil {
                theater.mode = persistentTheater ? .app : .playback
                diagnostics.record("lifecycle", "existing Signal playback entered cinema screen")
                return
            }
            guard theater.mode == .playback else { return }
            if persistentTheater {
                // In persistent mode the original RootView remains on the screen;
                // its existing backing store handles the return to the dashboard.
                theater.mode = .app
                diagnostics.record("lifecycle", "playback completed; persistent cinema remains open")
                return
            }
            Task { @MainActor in
                openWindow(id: "signal-main")
                await dismissImmersiveSpace()
                theater.immersiveActive = false
                diagnostics.record("lifecycle", "playback completed; returning to Signal window")
            }
        }
    }

    /// Unlit surfaces prevent headset environment lighting from creating giant
    /// white streaks across walls/floor or making seats disappear into black.
    /// Each item is created once at RealityView construction (no frame-by-frame
    /// reconstruction). All distances in meters and all objects are non-colliding.
    private func makeAuditorium() -> Entity {
        let auditorium = Entity()
        let wall = UIColor(red: 0.105, green: 0.11, blue: 0.14, alpha: 1)
        let ceiling = UIColor(red: 0.07, green: 0.074, blue: 0.09, alpha: 1)
        let carpet = UIColor(red: 0.13, green: 0.075, blue: 0.085, alpha: 1)
        let platform = UIColor(red: 0.15, green: 0.105, blue: 0.11, alpha: 1)
        let trim = UIColor(red: 0.28, green: 0.20, blue: 0.13, alpha: 1)
        let upholstery = UIColor(red: 0.30, green: 0.075, blue: 0.11, alpha: 1)
        let upholsteryShadow = UIColor(red: 0.19, green: 0.045, blue: 0.065, alpha: 1)
        let armColor = UIColor(red: 0.09, green: 0.085, blue: 0.095, alpha: 1)

        func block(_ size: SIMD3<Float>, _ position: SIMD3<Float>, _ color: UIColor) {
            let entity = ModelEntity(mesh: .generateBox(size: size),
                                     materials: [UnlitMaterial(color: color)])
            entity.position = position
            auditorium.addChild(entity)
        }

        // Alternate environment choices share the SAME functioning Build 27
        // ImmersiveSpace, screen attachment, player and exit lifecycle.
        if cinemaEnvironment == "Drive-In" {
            let night = UIColor(red: 0.035, green: 0.06, blue: 0.095, alpha: 1)
            block([30, 0.12, 30], [0, -0.16, -7.0], UIColor(red: 0.075, green: 0.085, blue: 0.075, alpha: 1))
            block([8.6, 4.25, 0.16], [0, 1.84, -7.59], night)
            block([5.88, 3.35, 0.12], [0, 1.82, -7.36], .black)
            block([0.18, 4.5, 0.2], [-3.55, 1.50, -7.65], trim)
            block([0.18, 4.5, 0.2], [ 3.55, 1.50, -7.65], trim)
            block([7.2, 0.12, 0.22], [0, 3.62, -7.46], trim)
            // Recognizable parked-car silhouettes, beyond the central clear aisle.
            for side: Float in [-1, 1] {
                for row in 0..<3 {
                    let z = -2.15 - Float(row) * 1.33
                    let x = side * 2.12
                    block([1.55, 0.48, 1.95], [x, 0.28, z], wall)
                    block([1.25, 0.48, 0.97], [x, 0.76, z + 0.20], night)
                    for wheelX: Float in [-0.60, 0.60] {
                        for wheelZ: Float in [-0.63, 0.63] {
                            block([0.17, 0.35, 0.35], [x + wheelX, 0.055, z + wheelZ], armColor)
                        }
                    }
                    block([1.05, 0.08, 0.08], [x, 0.32, z - 0.98], trim)
                }
            }
            return auditorium
        }

        if cinemaEnvironment == "Home Theater" {
            block([8.8, 0.10, 8.25], [0, -0.13, -3.51], carpet)
            block([8.8, 0.12, 8.25], [0, 3.38, -3.51], ceiling)
            block([8.8, 3.62, 0.10], [0, 1.64, -7.59], wall)
            block([8.8, 3.62, 0.10], [0, 1.64, 0.61], wall)
            for side: Float in [-1, 1] {
                block([0.10, 3.62, 8.25], [side * 4.37, 1.64, -3.51], wall)
                block([0.06, 0.09, 6.8], [side * 4.23, 1.24, -3.3], trim)
            }
            block([6.2, 3.46, 0.10], [0, 1.82, -7.43], trim)
            block([5.78, 3.26, 0.12], [0, 1.82, -7.35], .black)
            // Deep lounge sofa rows to the sides of the centered viewer aisle.
            for side: Float in [-1, 1] {
                for row in 0..<3 {
                    let z = -2.25 - Float(row) * 1.22
                    let x = side * 2.16
                    block([2.36, 0.35, 0.92], [x, 0.29, z], upholstery)
                    block([2.36, 0.74, 0.22], [x, 0.71, z + 0.43], upholsteryShadow)
                    block([0.24, 0.56, 0.89], [x - 1.24, 0.49, z], armColor)
                    block([0.24, 0.56, 0.89], [x + 1.24, 0.49, z], armColor)
                }
            }
            return auditorium
        }

        // Actual enclosed auditorium, with back wall BEHIND user's origin.
        // First chair is >1.6 meters FORWARD and across the center aisle.
        block([8.8, 0.10, 8.25], [0, -0.13, -3.51], carpet)
        block([8.8, 0.12, 8.25], [0, 3.64, -3.51], ceiling)
        block([8.8, 3.78, 0.10], [0, 1.74, -7.59], wall) // front
        block([8.8, 3.78, 0.10], [0, 1.74, 0.61], wall)  // behind viewer
        block([0.10, 3.78, 8.25], [-4.37, 1.74, -3.51], wall)
        block([0.10, 3.78, 8.25], [ 4.37, 1.74, -3.51], wall)

        // Screen and proscenium: 16:9, forward-facing, no spotlight blasts.
        block([6.52, 3.62, 0.10], [0, 1.78, -7.43], armColor)
        block([5.78, 3.26, 0.12], [0, 1.82, -7.35], .black)
        block([6.72, 0.13, 0.18], [0, 3.56, -7.31], trim)
        block([6.72, 0.13, 0.18], [0, 0.03, -7.31], trim)
        block([0.14, 3.40, 0.18], [-3.31, 1.82, -7.31], trim)
        block([0.14, 3.40, 0.18], [ 3.31, 1.82, -7.31], trim)
        block([7.15, 0.18, 0.95], [0, -0.015, -6.95], platform)

        // Four authentic stepped seating banks, with a clear central walkway.
        // Shaped cushions, vertical backs, headrests and armrests replace cubes.
        for row in 0..<4 {
            let z = -2.04 - Float(row) * 1.08
            let rise = Float(row) * 0.075
            for side: Float in [-1, 1] {
                block([3.44, 0.12 + rise, 0.92], [side * 2.42, -0.015 + rise * 0.5, z], platform)
                for column in 0..<4 {
                    let x = side * (0.99 + Float(column) * 0.80)
                    let seatHeight: Float = 0.34 + rise
                    block([0.67, 0.20, 0.61], [x, seatHeight, z], upholstery)
                    block([0.69, 0.73, 0.17], [x, seatHeight + 0.43, z + 0.29], upholsteryShadow)
                    block([0.60, 0.16, 0.13], [x, seatHeight + 0.76, z + 0.29], upholstery)
                    block([0.11, 0.20, 0.64], [x - 0.37, seatHeight + 0.13, z], armColor)
                    block([0.11, 0.20, 0.64], [x + 0.37, seatHeight + 0.13, z], armColor)
                }
            }
        }

        // Low-brightness architectural markers, never a giant white spot light.
        for side: Float in [-1, 1] {
            block([0.035, 0.012, 5.5], [side * 0.62, -0.065, -3.75], trim)
            block([0.035, 0.10, 7.5], [side * 4.24, 0.20, -3.45], trim)
            block([0.035, 0.09, 7.5], [side * 4.24, 2.84, -3.45], trim)
            for index in 0..<4 {
                block([0.19, 0.32, 0.06], [side * 4.25, 0.46, -1.72 - Float(index) * 1.32], trim)
            }
        }
        return auditorium
    }
}
