# Vision Pro workflow fix 4 — source auto-discovery

The uploaded GitHub log stopped before Xcode: `ERROR: Expected exactly one Build 2 source ZIP or extracted source.` The checked-in workflow was still using the older Build-2-only locator.

This replacement accepts extracted source at repo root or a subfolder, or scans any ZIP filename recursively for a real visionOS project containing `project.yml`, `Sources/`, and `SharedFromAppleTV/`. It prefers the Build 3 archive if there are multiple. It does **not** pretend that uploading only a workflow is sufficient.

**Recommended:** Extract this full package into the root of your separate `signalvisionpro` repo, ensuring `project.yml` and both source directories are at root. GitHub may hide dot folders in some ZIP viewers; upload `.github/workflows/build-visionos.yml` too. Alternatively leave the *full source* ZIP in GitHub alongside the updated workflow; ZIP-only workflow archives aren't source.

The workflow builds visionOS simulator + unsigned device application; upon successful device compilation packages an unsigned IPA under Actions → Artifacts. Device signing is performed separately through your chosen compatible provider. Full app feature parity has NOT been ported yet.
