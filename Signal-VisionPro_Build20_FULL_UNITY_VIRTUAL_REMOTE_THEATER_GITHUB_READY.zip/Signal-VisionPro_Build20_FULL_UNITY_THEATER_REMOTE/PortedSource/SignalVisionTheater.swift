import SwiftUI
import RealityKit

@MainActor
final class SignalVisionTheaterCoordinator: ObservableObject {
    static let shared = SignalVisionTheaterCoordinator()
    enum Mode: String { case app, playback }
    @Published var mode: Mode = .app
    @Published var immersiveActive = false
    private init() {}
}

enum SignalVisionRemoteEvent {
    static let direction = Notification.Name("SignalVision.Remote.Direction")
    static let back = Notification.Name("SignalVision.Remote.Back")
    static let home = Notification.Name("SignalVision.Remote.Home")
}

struct SignalVisionControlDock: View {
    @EnvironmentObject private var store: CatalogStore
    @EnvironmentObject private var theater: SignalVisionTheaterCoordinator
    @Environment(\.openImmersiveSpace) private var openImmersiveSpace
    @Environment(\.dismissImmersiveSpace) private var dismissImmersiveSpace
    @Environment(\.dismissWindow) private var dismissWindow
    @State private var controlsAwake = true
    @State private var fadeTask: Task<Void, Never>?

    private var playbackActive: Bool { store.playbackURL != nil }
    private var dockOpacity: Double { playbackActive && !controlsAwake ? 0.10 : 0.92 }

    var body: some View {
        VStack(spacing: 14) {
            HStack(spacing: 12) {
                theaterButton(mode: .app, icon: "theatermasks.fill", label: "App Theater")
                if playbackActive {
                    theaterButton(mode: .playback, icon: "film.fill", label: "Playback Theater")
                }
            }

            ZStack {
                Circle().fill(.black.opacity(0.52)).frame(width: 210, height: 210)
                remoteButton("chevron.up", direction: .up).offset(y: -70)
                remoteButton("chevron.down", direction: .down).offset(y: 70)
                remoteButton("chevron.left", direction: .left).offset(x: -70)
                remoteButton("chevron.right", direction: .right).offset(x: 70)
                Circle().fill(.white.opacity(0.13)).frame(width: 82, height: 82)
            }
            .contentShape(Circle())
            .hoverEffect(.lift)

            HStack(spacing: 18) {
                commandButton("arrow.backward", title: "Back") {
                    NotificationCenter.default.post(name: SignalVisionRemoteEvent.back, object: nil)
                }
                commandButton("house.fill", title: "Home") {
                    NotificationCenter.default.post(name: SignalVisionRemoteEvent.home, object: nil)
                }
            }
        }
        .padding(18)
        .background(.ultraThinMaterial, in: RoundedRectangle(cornerRadius: 28, style: .continuous))
        .opacity(dockOpacity)
        .scaleEffect(playbackActive && !controlsAwake ? 0.78 : 1)
        .animation(.easeInOut(duration: 0.28), value: dockOpacity)
        .onHover { hovering in
            if hovering { wakeControls() }
        }
        .onAppear { scheduleFadeIfNeeded() }
        .onChange(of: playbackActive) { _ in scheduleFadeIfNeeded() }
        .accessibilityLabel("Signal virtual remote")
    }

    private func wakeControls() {
        controlsAwake = true
        scheduleFadeIfNeeded()
    }

    private func scheduleFadeIfNeeded() {
        fadeTask?.cancel()
        guard playbackActive else { controlsAwake = true; return }
        fadeTask = Task { @MainActor in
            try? await Task.sleep(nanoseconds: 3_500_000_000)
            guard !Task.isCancelled else { return }
            controlsAwake = false
        }
    }

    private func post(_ direction: SignalMoveDirection) {
        wakeControls()
        NotificationCenter.default.post(name: SignalVisionRemoteEvent.direction, object: direction)
    }

    private func remoteButton(_ icon: String, direction: SignalMoveDirection) -> some View {
        Button { post(direction) } label: {
            Image(systemName: icon).font(.system(size: 30, weight: .bold)).frame(width: 62, height: 62)
        }
        .buttonStyle(.plain)
        .contentShape(Circle())
        .hoverEffect(.lift)
    }

    private func commandButton(_ icon: String, title: String, action: @escaping () -> Void) -> some View {
        Button { wakeControls(); action() } label: {
            VStack(spacing: 5) {
                Image(systemName: icon).font(.system(size: 23, weight: .semibold))
                Text(title).font(.caption2.weight(.semibold))
            }
            .frame(width: 82, height: 58)
        }
        .buttonStyle(.bordered)
        .hoverEffect(.lift)
    }

    private func theaterButton(mode: SignalVisionTheaterCoordinator.Mode, icon: String, label: String) -> some View {
        Button {
            wakeControls()
            Task { @MainActor in
                if theater.immersiveActive { await dismissImmersiveSpace() }
                theater.mode = mode
                let result = await openImmersiveSpace(id: "signal-theater")
                if case .opened = result {
                    theater.immersiveActive = true
                    dismissWindow(id: "signal-main")
                }
            }
        } label: {
            Label(label, systemImage: icon).font(.caption.weight(.semibold)).padding(.horizontal, 10).frame(height: 36)
        }
        .buttonStyle(.borderedProminent)
        .hoverEffect(.lift)
    }
}

struct SignalVisionTheaterSpace: View {
    @EnvironmentObject private var store: CatalogStore
    @EnvironmentObject private var unityCore: UnityAppCore
    @EnvironmentObject private var theater: SignalVisionTheaterCoordinator
    @Environment(\.dismissImmersiveSpace) private var dismissImmersiveSpace
    @Environment(\.openWindow) private var openWindow

    var body: some View {
        RealityView { content, attachments in
            let floor = ModelEntity(mesh: .generateBox(size: [9, 0.08, 9]), materials: [SimpleMaterial(color: .darkGray, isMetallic: false)])
            floor.position = [0, -1.75, -3.4]
            content.add(floor)

            let backWall = ModelEntity(mesh: .generateBox(size: [9, 5.2, 0.08]), materials: [SimpleMaterial(color: .black, isMetallic: false)])
            backWall.position = [0, 0.45, -6.0]
            content.add(backWall)

            let leftWall = ModelEntity(mesh: .generateBox(size: [0.08, 5.2, 9]), materials: [SimpleMaterial(color: .black, isMetallic: false)])
            leftWall.position = [-4.45, 0.45, -2.0]
            content.add(leftWall)
            let rightWall = leftWall.clone(recursive: true)
            rightWall.position.x = 4.45
            content.add(rightWall)

            let screenBacking = ModelEntity(mesh: .generateBox(size: [5.9, 3.45, 0.08]), materials: [SimpleMaterial(color: .black, isMetallic: false)])
            screenBacking.position = [0, 0.35, -5.72]
            content.add(screenBacking)

            for row in 0..<3 {
                for seat in -3...3 {
                    let chair = ModelEntity(mesh: .generateBox(size: [0.62, 0.62, 0.62]), materials: [SimpleMaterial(color: .darkGray, isMetallic: false)])
                    chair.position = [Float(seat) * 0.86, -1.38, Float(row) * 0.95 - 0.2]
                    content.add(chair)
                }
            }

            if let screen = attachments.entity(for: "signal-screen") {
                screen.position = [0, 0.35, -5.62]
                screen.scale = [0.00305, 0.00305, 0.00305]
                content.add(screen)
            }
        } attachments: {
            Attachment(id: "signal-screen") {
                ZStack(alignment: .bottomTrailing) {
                    RootView()
                        .environmentObject(store)
                        .environmentObject(unityCore)
                        .frame(width: 1600, height: 900)
                        .clipped()
                    SignalVisionControlDock()
                        .environmentObject(store)
                        .environmentObject(theater)
                        .padding(26)
                }
                .frame(width: 1600, height: 900)
                .background(.black)
                .clipShape(RoundedRectangle(cornerRadius: 18))
            }
        }
        .onChange(of: store.playbackURL) { url in
            guard theater.mode == .playback, url == nil else { return }
            Task { @MainActor in
                await dismissImmersiveSpace()
                theater.immersiveActive = false
                openWindow(id: "signal-main")
            }
        }
    }
}
