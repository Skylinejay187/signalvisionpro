import SwiftUI
import AVKit

// Vision Pro Build 2: real vBRDC357 shared models, HTTP, backup, sports and Live TV progress
// source is compiled from SharedFromAppleTV; full tvOS source retained in AppleTVSource_vBRDC357.
// tvOS-only app shell and playback binaries remain excluded until platform adaptation.
private enum SignalSection: String, CaseIterable, Identifiable {
    case home = "Home"
    case liveTV = "Live TV"
    case player = "Player"
    case settings = "Settings"

    var id: String { rawValue }
    var symbol: String {
        switch self {
        case .home: "house.fill"
        case .liveTV: "tv.fill"
        case .player: "play.rectangle.fill"
        case .settings: "gearshape.fill"
        }
    }
}

struct SignalRootView: View {
    @State private var selection: SignalSection? = .home
    @AppStorage("signal.backendURL") private var backendURL = ""
    @AppStorage("signal.streamURL") private var streamURL = ""
    @State private var backendStatus = "Not checked"
    @State private var checking = false
    @State private var player: AVPlayer?
    @State private var playingURL = ""
    @State private var playbackError = ""

    var body: some View {
        NavigationSplitView {
            List(SignalSection.allCases, selection: $selection) { section in
                Label(section.rawValue, systemImage: section.symbol)
                    .tag(section)
            }
            .navigationTitle("SIGNAL")
            .listStyle(.sidebar)
        } detail: {
            Group {
                switch selection ?? .home {
                case .home: home
                case .liveTV: liveTV
                case .player: playback
                case .settings: settings
                }
            }
            .frame(maxWidth: .infinity, maxHeight: .infinity)
            .padding(28)
        }
        .onDisappear { player?.pause() }
    }

    private var brand: some View {
        VStack(alignment: .leading, spacing: 10) {
            Image("SignalChromeWordmarkRaw")
                .resizable()
                .scaledToFit()
                .frame(maxWidth: 320, maxHeight: 140, alignment: .leading)
                .accessibilityLabel("Signal")
            Text("Vision Pro · vBRDC357 source migration")
                .font(.subheadline)
                .foregroundStyle(.secondary)
        }
    }

    private var home: some View {
        ScrollView {
            VStack(alignment: .leading, spacing: 28) {
                brand
                Text("Welcome to Signal")
                    .font(.largeTitle.bold())
                Text("This port includes the original Apple TV vBRDC357 source and assets, and compiles its original media models, HTTP, profile-backup transport, sports classification and Live TV progress component. The tvOS screen and playback engines still require adaptation before feature parity.")
                    .foregroundStyle(.secondary)
                HStack(spacing: 16) {
                    Button("Check backend") { Task { await checkBackend() } }
                        .disabled(checking)
                    Button("Open Live TV") { selection = .liveTV }
                    Button("Open Player") { selection = .player }
                }
                Text("Backend: \(backendStatus)")
                    .font(.callout.monospaced())
                    .textSelection(.enabled)
                if backendURL.isEmpty {
                    Text("Configure your backend in Settings to test connectivity.")
                        .foregroundStyle(.orange)
                }
                LiveTVProgramProgressLine(progress: 0.35, isFocused: false, width: 400, tick: 0)
                .accessibilityLabel("Apple TV Live TV progress component port preview")
            Spacer(minLength: 50)
            }
            .frame(maxWidth: .infinity, alignment: .leading)
        }
        .navigationTitle("Home")
    }

    private var liveTV: some View {
        VStack(alignment: .leading, spacing: 22) {
            Text("Live TV").font(.largeTitle.bold())
            Text("The original vBRDC357 Live TV source and channel guide are included in AppleTVSource_vBRDC357 for porting. This window currently supports direct AVKit playback; the full guide is not yet connected.")
                .foregroundStyle(.secondary)
            TextField("https://…/channel.m3u8", text: $streamURL)
                .textInputAutocapitalization(.never)
                .autocorrectionDisabled()
                .onSubmit(startPlayback)
            Button("Play stream") { startPlayback() }
                .disabled(streamURL.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty)
            Spacer()
        }
        .frame(maxWidth: .infinity, alignment: .leading)
        .navigationTitle("Live TV")
    }

    private var playback: some View {
        VStack(alignment: .leading, spacing: 16) {
            Text("Player").font(.largeTitle.bold())
            if let player {
                VideoPlayer(player: player)
                    .frame(minHeight: 420)
                    .clipShape(RoundedRectangle(cornerRadius: 16))
                Text(playingURL).font(.caption).foregroundStyle(.secondary)
                    .lineLimit(2).textSelection(.enabled)
                Button("Stop playback") { player.pause(); self.player = nil }
            } else {
                ContentUnavailableView("No stream selected", systemImage: "play.rectangle", description: Text("Choose a stream from Live TV to test playback."))
            }
            if !playbackError.isEmpty {
                Text(playbackError).foregroundStyle(.orange)
            }
            Spacer(minLength: 0)
        }
        .navigationTitle("Player")
    }

    private var settings: some View {
        Form {
            Section("Backend connection") {
                TextField("https://your-backend.example", text: $backendURL)
                    .textInputAutocapitalization(.never)
                    .autocorrectionDisabled()
                    .textContentType(.URL)
                Button(checking ? "Checking…" : "Check backend health") {
                    Task { await checkBackend() }
                }
                .disabled(checking)
                Text(backendStatus).foregroundStyle(.secondary).textSelection(.enabled)
                Text("Use a backend address reachable from Vision Pro. The connection test requests /health; it does not sign in or change membership records.")
                    .font(.caption).foregroundStyle(.secondary)
            }
            Section("Build") {
                LabeledContent("Port", value: "Vision Pro Build 2")
                LabeledContent("Source reference", value: "Apple TV vBRDC357 (bundled source)")
                LabeledContent("Playback", value: "AVKit interim; tvOS engines in port source")
                LabeledContent("Shared source", value: "vBRDC357 media / HTTP / backup / sports / progress")
            }
        }
        .navigationTitle("Settings")
    }

    private func startPlayback() {
        let trimmed = streamURL.trimmingCharacters(in: .whitespacesAndNewlines)
        guard let url = URL(string: trimmed), ["https", "http"].contains(url.scheme?.lowercased() ?? ""), url.host != nil else {
            playbackError = "Enter a valid HTTP or HTTPS stream URL."
            selection = .player
            return
        }
        playbackError = ""
        player?.pause()
        player = AVPlayer(url: url)
        playingURL = trimmed
        selection = .player
        player?.play()
    }

    @MainActor
    private func checkBackend() async {
        let base = backendURL.trimmingCharacters(in: .whitespacesAndNewlines)
        guard let url = URL(string: base), ["https", "http"].contains(url.scheme?.lowercased() ?? ""), url.host != nil else {
            backendStatus = "Enter a valid backend URL in Settings."
            return
        }
        checking = true
        defer { checking = false }
        let health = url.appendingPathComponent("health")
        var request = URLRequest(url: health)
        request.timeoutInterval = 12
        do {
            let (_, response) = try await URLSession.shared.data(for: request)
            if let http = response as? HTTPURLResponse {
                backendStatus = "HTTP \(http.statusCode) · \(health.host ?? "backend")"
            } else {
                backendStatus = "Server responded"
            }
        } catch {
            backendStatus = "Unreachable: \(error.localizedDescription)"
        }
    }
}
