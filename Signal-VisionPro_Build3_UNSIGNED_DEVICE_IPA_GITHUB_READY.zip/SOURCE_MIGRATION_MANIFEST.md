# Scope and source identity

Source anchor: `DebridChannels_vBRDC357_PREVIEW_MIRROR_HEADER_POSITION_FIX_GITHUB_READY.zip`, Apple TV version 1.0.1059 (1059).

Ported into the visionOS target with original code: model declarations from CatalogStore and Live TV channel/program declarations from DebridChannelsTVOSApp; PlainHTTPClient, BackendProfileBackupClient, SportsChannelClassifierManager, LiveTVProgramProgressLine. All other existing app source/asset/vendor trees are available under AppleTVSource_vBRDC357 but not in the target.

Decision: avoid creating a bogus 'full port' build by enabling TVServices/Top Shelf and tvOS-only SwiftPM engine binary dependencies on visionOS. The remaining adaptation must be completed and compiler errors resolved on a macOS runner with Xcode visionOS SDK.
