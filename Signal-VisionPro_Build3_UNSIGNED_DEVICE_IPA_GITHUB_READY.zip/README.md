# Signal Vision Pro — Build 3: source-first migration + unsigned device IPA from Apple TV vBRDC357

**This is an in-progress port, not the complete Apple TV app on visionOS.** Unlike Build 1, this ZIP includes the actual vBRDC357 source/assets and compiles genuinely reused source files into its visionOS target. Nothing in the original tvOS source has been modified.

## Source and compiled migration
- `AppleTVSource_vBRDC357/`: the real existing Apple TV source tree, asset catalog, vendor manifests, scripts, tvOS project and Top Shelf extension, copied verbatim. Not compiled into visionOS until its platform-specific APIs are adapted.
- `SharedFromAppleTV/`: directly copied, compiled versions of `PlainHTTPClient.swift`, `BackendProfileBackupClient.swift`, `SportsChannelClassifierManager.swift`, `LiveTVProgramProgressLine.swift`, and verbatim media/catalog model declarations extracted from `CatalogStore.swift`, plus channel/program models extracted from `DebridChannelsTVOSApp.swift`. These are the original client/model implementations, not substitute stubs.
- `Sources/`: visionOS shell from Build 1, updated to actually show the reused Live TV progress view and document port status; AVKit URL playback remains an interim option.
- `.github/workflows/build-visionos.yml`: builds simulator and unsigned visionOS device targets, packages a device IPA, and uploads separate logs.

## Important platform work still necessary
The original `DebridChannelsTVOSApp.swift` is a large tvOS-specific SwiftUI file that imports TVServices and uses Apple TV remote/focus APIs and UIScreen, so simply including it in a visionOS target will not compile. The KSPlayer/Aether manifests currently declare tvOS only and their binaries must be checked for visionOS slices. The complete catalog implementation (`CatalogStore.swift`) is coupled to app-wide UIKit/runtime/manager code and is not yet compiled. The existing Live TV guide, settings, membership flow, Trakt screens, and Aether/KS playback are not yet connected to the visionOS shell. No claim of feature parity or successful Apple/Xcode build is made.

## Build
Create a new `Signal-VisionPro` GitHub repo, upload the CONTENTS of this ZIP at repository root, and run Actions → Signal Vision Pro — Build → Run workflow. The Apple TV repository stays unchanged. A successful workflow provides the simulator ZIP and an UNSIGNED device IPA for a visionOS-capable signing service; this is not a directly installable signed IPA. See README_BUILD3_DEVICE_IPA.md.

## Restoration / network
Use your own reachable backend URL in Settings. This project does not edit your backend or membership settings. The user's temporary membership-off backend is independent from this app port.
