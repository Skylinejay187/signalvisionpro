import SwiftUI
import RealityKit
import UIKit

@MainActor
final class SignalVisionTheaterCoordinator: ObservableObject {
    static let shared = SignalVisionTheaterCoordinator()
    enum Mode: String { case app, playback }
    @Published var mode: Mode = .app
    @Published var immersiveActive = false
    @Published var transitionInProgress = false
    @Published var entryFailure: String?
    var didAttemptAutomaticEntry = false
    private init() {}
}

enum SignalVisionRemoteEvent {
    static let direction = Notification.Name("SignalVision.Remote.Direction")
    static let back = Notification.Name("SignalVision.Remote.Back")
    static let home = Notification.Name("SignalVision.Remote.Home")
    static let catalogDirection = Notification.Name("SignalVision.Catalog.Direction")
}

// Build 29: original modeled cinema seating and improved screen sightlines. Keep Build 27's
// scene declaration/manifest and playback engine unchanged. Geometry has no
// colliders; the viewer starts in the CENTER AISLE, not inside a chair/wall.
struct SignalVisionTheaterSpace: View {
    @EnvironmentObject private var store: CatalogStore
    @EnvironmentObject private var unityCore: UnityAppCore
    @EnvironmentObject private var theater: SignalVisionTheaterCoordinator
    @Environment(\.dismissImmersiveSpace) private var dismissImmersiveSpace
    @Environment(\.openWindow) private var openWindow
    @Environment(\.dismissWindow) private var dismissWindow
    @AppStorage("signalVisionPersistentTheaterV22") private var persistentTheater = true
    @AppStorage("signalVisionCinemaEnvironmentV28") private var cinemaEnvironment = "Classic Cinema"
    @State private var cinemaScreenReady = false
    private let diagnostics = SignalVisionDiagnostics.shared

    var body: some View {
        RealityView { content, attachments in
            diagnostics.record("reality", "Build29 auditorium construction started")
            content.add(makeAuditorium())
            // Cinema controls are viewer-side and to the LOWER RIGHT, never in the
            // middle of the movie screen. They remain a real gaze/pinch target.
            if let controls = attachments.entity(for: "signal-controls") {
                controls.position = [1.15, 0.68, -1.48]
                controls.scale = [0.72, 0.72, 0.72]
                content.add(controls)
            }
            if let screen = attachments.entity(for: "signal-screen") {
                screen.position = [0, 1.82, -7.26]
                // Attachment is 1600 x 900 pt: 5.36 m x 3.015 m, 16:9.
                screen.scale = [0.00335, 0.00335, 0.00335]
                content.add(screen)
            }
            diagnostics.record("reality", "auditorium, fixed cinema screen and viewer-side controls attached")
        } attachments: {
            Attachment(id: "signal-screen") {
                Group {
                    if cinemaScreenReady {
                        // Original Signal RootView, store, and existing KSPlayer/Aether
                        // player are the ONLY playback owner. No second AVPlayer.
                        RootView()
                            .environmentObject(store)
                            .environmentObject(unityCore)
                    } else {
                        ZStack {
                            Color.black
                            VStack(spacing: 18) {
                                Image(systemName: "theatermasks.fill").font(.system(size: 90))
                                Text("SIGNAL · CLASSIC CINEMA").font(.system(size: 48, weight: .bold))
                                Text("Preparing cinema screen…").font(.system(size: 30))
                            }.foregroundStyle(.white)
                        }
                    }
                }
                .frame(width: 1600, height: 900)
                .clipped()
                .background(.black)
                .clipShape(RoundedRectangle(cornerRadius: 12))
            }
            Attachment(id: "signal-controls") {
                Button("Exit Theater", systemImage: "xmark.circle.fill") {
                    Task { @MainActor in
                        openWindow(id: "signal-main")
                        await dismissImmersiveSpace()
                        theater.immersiveActive = false
                        diagnostics.record("lifecycle", "exit button dismissed immersive space")
                    }
                }
                .font(.system(size: 17, weight: .semibold))
                .buttonStyle(.bordered)
                .hoverEffect(.highlight)
                .padding(8)
                .background(.ultraThinMaterial, in: Capsule())
                .accessibilityLabel("Exit theater and return to Signal")
            }
        }
        .onAppear {
            theater.immersiveActive = true
            theater.transitionInProgress = false
            theater.entryFailure = nil
            theater.didAttemptAutomaticEntry = true
            diagnostics.record("lifecycle", "Build29 immersive scene onAppear")
            diagnostics.sceneSnapshot("immersive-appeared")
            // One playback owner; close the original window only after immersive
            // scene has appeared, then re-open it before exiting the theater.
            dismissWindow(id: "signal-main")
            Task { @MainActor in
                try? await Task.sleep(nanoseconds: 450_000_000)
                guard theater.immersiveActive else { return }
                cinemaScreenReady = true
                diagnostics.record("lifecycle", "full original Signal UI/player attached to cinema screen")
            }
        }
        .onDisappear {
            theater.immersiveActive = false
            cinemaScreenReady = false
            diagnostics.record("lifecycle", "Build29 immersive scene onDisappear")
            diagnostics.sceneSnapshot("immersive-disappeared")
        }
        .onChange(of: store.playbackURL) { url in
            if url != nil {
                theater.mode = persistentTheater ? .app : .playback
                diagnostics.record("lifecycle", "existing Signal playback entered cinema screen")
                return
            }
            guard theater.mode == .playback else { return }
            if persistentTheater {
                // In persistent mode the original RootView remains on the screen;
                // its existing backing store handles the return to the dashboard.
                theater.mode = .app
                diagnostics.record("lifecycle", "playback completed; persistent cinema remains open")
                return
            }
            Task { @MainActor in
                openWindow(id: "signal-main")
                await dismissImmersiveSpace()
                theater.immersiveActive = false
                diagnostics.record("lifecycle", "playback completed; returning to Signal window")
            }
        }
    }

    /// Build29 art pass: the seat asset is a native USD model with curved cushions,
    /// an upholstered shell, cup holders and PBR materials. An in-code curved
    /// version is available if the asset cannot load on a particular headset.
    /// Keep the proven Build27 scene registration and the Build28 player owner.
    private func makeAuditorium() -> Entity {
        let room = Entity()
        let charcoal = UIColor(red: 0.083, green: 0.085, blue: 0.103, alpha: 1)
        let acoustic = UIColor(red: 0.135, green: 0.125, blue: 0.155, alpha: 1)
        let panelInset = UIColor(red: 0.065, green: 0.068, blue: 0.083, alpha: 1)
        let carpet = UIColor(red: 0.145, green: 0.077, blue: 0.087, alpha: 1)
        let brass = UIColor(red: 0.45, green: 0.29, blue: 0.12, alpha: 1)
        let dimBrass = UIColor(red: 0.24, green: 0.155, blue: 0.075, alpha: 1)
        let lamp = UIColor(red: 0.58, green: 0.35, blue: 0.135, alpha: 1)
        let velour = UIColor(red: 0.24, green: 0.025, blue: 0.05, alpha: 1)
        let black = UIColor(red: 0.018, green: 0.020, blue: 0.026, alpha: 1)
        func box(_ size: SIMD3<Float>, at position: SIMD3<Float>, color: UIColor) {
            let e = ModelEntity(mesh: .generateBox(size: size), materials: [UnlitMaterial(color: color)])
            e.position = position
            room.addChild(e)
        }
        func oval(_ size: SIMD3<Float>, at position: SIMD3<Float>, color: UIColor) {
            let e = ModelEntity(mesh: .generateSphere(radius: 0.5), materials: [UnlitMaterial(color: color)])
            e.scale = size
            e.position = position
            room.addChild(e)
        }
        if cinemaEnvironment == "Drive-In" {
            // This separate environment intentionally retains the lightweight
            // outdoor build; Classic Cinema uses the full modeled auditorium.
            box([30, 0.09, 30], at: [0, -0.16, -7], color: charcoal)
            box([8.2, 4.2, 0.15], at: [0, 1.82, -7.55], color: acoustic)
            box([5.75, 3.23, 0.08], at: [0, 1.82, -7.40], color: .black)
            for side: Float in [-1, 1] {
                for r in 0..<3 {
                    let z = -2.25 - Float(r)*1.50
                    box([1.65, 0.46, 1.95], at: [side*2.25, 0.25, z], color: charcoal)
                    oval([1.27,0.49,0.95], at: [side*2.25,0.72,z+0.24], color: acoustic)
                }
            }
            return room
        }
        // Architectural shell remains centered on the user's starting position;
        // the rear wall is behind them and the center axis is an unobstructed aisle.
        box([9.8, 0.10, 9.05], at: [0, -0.20, -3.32], color: carpet)
        box([9.8, 0.13, 9.05], at: [0, 3.75, -3.32], color: charcoal)
        box([9.8, 3.9, 0.10], at: [0, 1.77, 0.66], color: charcoal)
        box([9.8, 3.9, 0.12], at: [0, 1.77, -7.50], color: charcoal)
        for side: Float in [-1, 1] {
            let x: Float = side * 4.85
            box([0.12, 3.9, 9.05], at: [x, 1.77, -3.32], color: acoustic)
            // Acoustic bay panels and vertical timber/brass slats make walls
            // readable at cinema brightness without overexposed point lights.
            for bay in 0..<6 {
                let z = -0.10 - Float(bay) * 1.20
                box([0.035, 2.25, 0.94], at: [x-side*0.085, 1.70, z], color: panelInset)
                for slot in 0..<5 {
                    box([0.038, 2.06, 0.014], at: [x-side*0.115, 1.70, z-0.36+Float(slot)*0.18], color: charcoal)
                }
                box([0.055, 2.55, 0.023], at: [x-side*0.14, 1.73, z-0.52], color: dimBrass)
                // Wall sconces use a warm low-intensity unlit emissive look.
                if bay == 1 || bay == 4 {
                    box([0.045, 0.38, 0.14], at: [x-side*0.18, 2.13, z], color: brass)
                    oval([0.07,0.19,0.12], at: [x-side*0.23, 2.16, z], color: lamp)
                }
            }
            box([0.055, 0.10, 8.8], at: [x-side*0.17, 0.40, -3.32], color: dimBrass)
            box([0.055, 0.025, 8.8], at: [x-side*0.17, 3.30, -3.32], color: brass)
        }
        // Subtle carpet stripes and safety LEDs: visible geometry, not lighting
        // that splashes giant white streaks over the viewer's field of vision.
        for side: Float in [-1, 1] {
            box([0.035,0.012,5.7], at: [side*1.04,-0.137,-3.8], color: brass)
            for step in 0..<6 {
                box([0.14,0.022,0.075], at: [side*1.07,-0.124,-1.45-Float(step)*0.98], color: lamp)
            }
        }
        // Acoustic ceiling coffers and shallow perimeter coves.
        for i in 0..<5 {
            let z = -0.24-Float(i)*1.47
            box([9.1,0.075,0.12], at: [0,3.67,z], color: acoustic)
            box([7.25,0.018,0.03], at: [0,3.62,z-0.12], color: dimBrass)
        }
        for side: Float in [-1,1] {
            box([0.10,0.065,8.25], at: [side*4.36,3.55,-3.35], color: dimBrass)
        }
        // Screen proscenium is built BEHIND the live SwiftUI attachment, not over it.
        box([6.74,3.58,0.07], at: [0,1.82,-7.43], color: black)
        box([6.08,3.40,0.045], at: [0,1.82,-7.355], color: .black)
        box([6.93,0.11,0.15], at: [0,3.59,-7.28], color: brass)
        box([6.93,0.11,0.15], at: [0,0.06,-7.28], color: dimBrass)
        for side: Float in [-1,1] {
            box([0.13,3.50,0.13], at: [side*3.47,1.82,-7.27], color: brass)
            box([0.28,3.33,0.26], at: [side*3.77,1.79,-7.15], color: black)
        }
        box([7.2,0.095,0.8], at: [0,-0.10,-6.97], color: acoustic)
        if cinemaEnvironment == "Home Theater" {
            // Home Theater keeps a less dense three-seat lounge with the same
            // unobstructed center and the same real cinema video attachment.
            for side: Float in [-1,1] {
                for row in 0..<2 {
                    let z = -2.70-Float(row)*1.43
                    box([2.40,0.27,1.03], at: [side*2.24,0.23,z], color: velour)
                    oval([2.25,0.67,0.27], at: [side*2.24,0.76,z+0.38], color: velour)
                    oval([2.13,0.23,0.75], at: [side*2.24,0.48,z-0.08], color: velour)
                }
            }
            return room
        }
        // Original curved native USD seat, loaded once then cloned into each
        // bank. Supports shipping actual model geometry without a GLB runtime.
        let seatAsset = try? Entity.load(named: "CinemaSeat", in: .main)
        diagnostics.record("assets", seatAsset == nil ? "CinemaSeat USDA unavailable; curved geometry fallback" : "CinemaSeat USD geometry loaded")
        for row in 0..<3 {
            let z = -2.85-Float(row)*1.27
            let rise = Float(row)*0.12
            for side: Float in [-1,1] {
                // Physically open center aisle >= 2.2 m; viewer at (0,0,0)
                // cannot start inside seating or have screen center blocked.
                box([3.40,0.14+rise,0.94], at: [side*2.91,-0.13+rise*0.5,z], color: acoustic)
                for column in 0..<3 {
                    let x = side*(1.54+Float(column)*0.93)
                    if let seatAsset {
                        let chair = seatAsset.clone(recursive: true)
                        chair.position = [x,rise,z]
                        room.addChild(chair)
                    } else {
                        // Smooth upholstery fallback, not opaque seat-shaped boxes.
                        oval([0.72,0.75,0.30], at: [x,0.92+rise,z+0.35], color: velour)
                        oval([0.70,0.22,0.65], at: [x,0.47+rise,z-0.08], color: velour)
                        for arm: Float in [-1,1] {
                            oval([0.11,0.17,0.65], at: [x+arm*0.39,0.67+rise,z-0.06], color: black)
                        }
                        box([0.63,0.21,0.40], at: [x,0.21+rise,z], color: black)
                    }
                }
            }
        }
        return room
    }
}
