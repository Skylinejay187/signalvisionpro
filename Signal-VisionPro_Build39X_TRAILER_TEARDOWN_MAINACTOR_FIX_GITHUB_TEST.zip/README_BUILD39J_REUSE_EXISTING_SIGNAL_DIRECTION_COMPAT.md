# Build 39J — reuse existing Signal direction compatibility

Patched directly from Build 39I.

Build 39I correctly removed the large tvOS-only API error families, but it accidentally
declared a second `SignalMoveDirection` in `DebridChannelsTVOSApp.swift`. The Vision Pro
compatibility layer already defines `SignalMoveDirection` in
`SignalVisionNavigationCompat.swift`.

39J removes only that duplicate enum and reuses the existing shared compatibility type.
The comprehensive 39I platform-safe adapters and call-site migrations remain intact.

- Exactly one `SignalMoveDirection` declaration remains.
- No Aether/theater/playback/UI redesign changes.
- Continue using Universal Workflow v4C.
