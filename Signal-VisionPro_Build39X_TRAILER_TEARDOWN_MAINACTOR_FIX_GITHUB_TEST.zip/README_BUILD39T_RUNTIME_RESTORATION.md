# Build 39T — Vision Pro runtime restoration

39S compiled but failed physical runtime validation. Audit against the complete
Build 38B Vision Pro runtime found that the assets were still present; several
Vision Pro integration hooks had disappeared from the active view tree.

Restored in 39T:
- complete Build 38B SignalVisionSpatialControls (theater settings, environments,
  seat controls, diagnostics and movable catalog navigation)
- visionOS move/back/play-pause adapters now forward to Signal's existing
  visionOS navigation compatibility layer instead of becoming no-ops
- movable SignalVisionCatalogArrows is mounted again on the catalog surface
- catalogDirection events are consumed by the active persistent catalog rail
- root GeometryReader and SignalVisionWindowMetrics updates are restored
- retained Live TV root gets SignalVisionLayerSurface again
- visionOS display bounds use current window metrics rather than hard-coded size

Preserved:
- Build 39 Aether-only playback architecture
- Build 39 theater single-owner/screen sizing work
- successful 39D–39S compile compatibility fixes
- 39S TopMenu solver decomposition
- Universal Workflow v4C
- build number remains 39

Build 40 external handoff is excluded until this recovery passes headset testing.
