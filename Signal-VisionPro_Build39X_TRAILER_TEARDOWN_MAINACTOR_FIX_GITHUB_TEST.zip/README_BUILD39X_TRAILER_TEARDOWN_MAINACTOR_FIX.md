# Build 39X — trailer teardown MainActor fix

Base: Build 39W.

39W cleared the prior three compiler errors and exposed one remaining
concurrency error: the SwiftUI dismantle callback synchronously called the
now-correctly MainActor-isolated trailer Coordinator.teardown().

39X marks that exact dismantleUIView callback @MainActor. This preserves
Coordinator isolation and teardown behavior rather than weakening actor
safety.

No theater, catalog, navigation, Aether, resource, or Build 40 external
handoff behavior is changed.
