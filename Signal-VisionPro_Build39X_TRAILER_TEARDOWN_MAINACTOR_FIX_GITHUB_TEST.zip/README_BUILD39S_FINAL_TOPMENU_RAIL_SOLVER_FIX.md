# Build 39S — final TopMenu rail solver fix

Patched directly from Build 39R after CI reported one remaining compiler blocker:
the Swift compiler timed out while type-checking the TopMenuBar navigation HStack.

39S isolates each tab into a dedicated `topMenuTabItem(_:)` leaf view and moves
the large tap action into `activateTopMenuTab(_:)`. The navigation rail now only
iterates `visibleTabs` and inserts the already-typed tab leaf views.

Preserved behavior includes:
- themed TopMenuTabVisual presentation
- focus/scale behavior
- Down navigation
- membership secret-tap owner-login behavior
- sports cleanup
- catalog/live/dedicated-surface selection behavior
- focus-token handoff behavior
- Preview Mirror search button and rail styling

No Aether, FFmpeg, theater, playback ownership, membership rules, or workflow
changes are intended. Continue using Universal Workflow v4C.
