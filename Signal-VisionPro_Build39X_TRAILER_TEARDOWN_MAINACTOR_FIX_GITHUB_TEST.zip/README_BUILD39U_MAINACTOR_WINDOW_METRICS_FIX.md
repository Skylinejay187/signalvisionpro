# Build 39U — MainActor window metrics compile fix

Base: Build 39T runtime restoration.

39T CI exposed one compiler error: the restored visionOS
`SignalVisionWindowMetrics.currentWindowBounds` property is MainActor-isolated,
while `SignalDisplayMetrics` was nonisolated.

39U marks the `SignalDisplayMetrics` abstraction `@MainActor`, preserving the
restored real window geometry rather than reverting to hard-coded 1920x1080.

All 39T runtime restoration remains intact. Build 40 external handoff remains
excluded until physical headset validation succeeds.
