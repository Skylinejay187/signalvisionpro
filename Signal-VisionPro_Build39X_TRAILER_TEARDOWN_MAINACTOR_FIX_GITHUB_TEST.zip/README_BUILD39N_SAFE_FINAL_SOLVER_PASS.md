# Build 39N — safe final solver pass

Build 39M is discarded: its aggressive structural extraction introduced a scope/brace
regression during workflow pre-parse. Build 39N is rebuilt directly from syntax-valid 39L.

39N deliberately avoids moving structural SwiftUI blocks:
- Hoists conditional style calculations from SourceConfirmationActionButton and
  PanelOptionChip out of ViewBuilder inference.
- Raises the compile-only Swift solver expression threshold from 60s to 300s for
  the remaining large legacy SwiftUI expressions.
- Added helper-property braces are balanced; conditional-compilation structure is
  identical to 39L.
- No Aether, theater, membership, playback ownership, or intended UI changes.
- Continue using Universal Workflow v4C.
