# Build 39K — remaining exit-command + SwiftUI type-check repair

Patched directly from Build 39J against the complete 39J Xcode error set.

- Migrates the three remaining application `.onExitCommand(perform:)` sites to the
  platform-safe Signal adapter.
- Preserves the one shared `SignalMoveDirection` declaration in
  `SignalVisionNavigationCompat.swift`.
- Type-erases the four platform compatibility View adapter return types to `AnyView`.
  This places a fixed compiler type boundary around the compatibility layer instead
  of multiplying conditional `some View` types through Signal's large SwiftUI view
  expressions, targeting all eight remaining solver timeouts without redesigning
  those screens.
- No Aether, theater ownership, playback, membership, or visual redesign changes.
- Continue using Universal Workflow v4C.
