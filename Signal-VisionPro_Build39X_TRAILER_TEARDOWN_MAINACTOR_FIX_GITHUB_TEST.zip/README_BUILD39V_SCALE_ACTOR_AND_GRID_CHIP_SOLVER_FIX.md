# Build 39V — scale actor + Preview Mirror GRID solver fix

Base: Build 39U.

39U CI exposed exactly three compiler errors:
1. Two MainActor isolation errors reading SignalDisplayMetrics.scale from the
   trailer PlayerLayer coordinator.
2. One Swift type-check timeout in the Preview Mirror GRID mode chip.

39V fixes them narrowly:
- marks the trailer Coordinator @MainActor, preserving the real
  SignalDisplayMetrics/window-metrics implementation
- splits the GRID chip into a visual leaf and a small interaction wrapper
- extracts the move-command closure into handleMirrorGridModeMove(_:)

No runtime-restoration feature is removed. Build 40 external handoff remains
excluded until physical Vision Pro validation succeeds.
