# Build 39Q — final four compile-fix pass

Patched directly from Build 39P after CI reported four errors.

Changes:
- Live TV channel action button: restores the missing `chipBorderWidth` local and
  gives the animation an explicit `Animation` value.
- SourceIntelligenceSatelliteLinkRow: precomputes conditional modifier values and
  adds a small `AnyView` content boundary to reduce SwiftUI solver load.
- TopMenuBar: splits the previous giant expression into `chromeContent` and
  `renderedBody`. The existing lifecycle/focus behavior remains on renderedBody;
  the GeometryReader/ZStack chrome is isolated behind a type-erased boundary.

No Aether, theater, playback ownership, membership, navigation behavior, or
workflow changes are intended. Continue using Universal Workflow v4C.
