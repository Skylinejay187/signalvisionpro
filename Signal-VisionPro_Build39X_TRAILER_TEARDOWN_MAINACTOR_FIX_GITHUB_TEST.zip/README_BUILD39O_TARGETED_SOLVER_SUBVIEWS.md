# Build 39O — targeted solver subviews

Patched from syntax-valid 39N after CI reported six remaining SwiftUI type-check
timeouts. This pass fixes the accidental recursive PanelOptionChip helper values in
39N and structurally reduces the reported expressions using small, scope-safe
computed subviews/functions.

Targets:
- TopMenuBar: thin AnyView body boundary around the existing render body.
- Connected series episode selector/cards: separated leaf views.
- ManualEpisodesRow: header, season strip/chips, and episode strip separated.
- SourceIntelligenceSatelliteLinkRow: badge/metadata/trailing content separated.
- EmbeddedSourceProviderStrip: provider chip extracted to a standalone View.
- PanelOptionChip: corrected helper values and uses them in the label expression.

The ineffective 300-second solver threshold is returned to 60 seconds.
No Aether, theater, playback ownership, membership, or intended UI changes.
Continue using Universal Workflow v4C.
