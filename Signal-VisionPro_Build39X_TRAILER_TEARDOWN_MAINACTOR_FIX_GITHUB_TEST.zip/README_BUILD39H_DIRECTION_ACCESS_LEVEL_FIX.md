# Build 39H — direction compatibility access-level fix

Patched directly from Build 39G.

The visionOS-only `MoveCommandDirection` compatibility enum is now internal
(the Swift default) instead of private. This resolves the Xcode access-level
error where `GridOSFixedSlotCatalogRail.onNavigationActivity` exposes that type.

No navigation closures, Aether code, theater/playback architecture, UI,
membership logic, or workflow were changed. Continue using Universal Workflow v4C.
