# Build 39W

Base: 39V.

- Marks the exact Coordinator containing the pair of
  SignalDisplayMetrics.scale accesses reported by CI as @MainActor.
- Removes the unsupported `perform:` argument label from
  signalOnMoveCommand(handleMirrorGridModeMove).

All 39T runtime restoration and Build 39 Aether work remain intact.
Build 40 external handoff remains excluded.
