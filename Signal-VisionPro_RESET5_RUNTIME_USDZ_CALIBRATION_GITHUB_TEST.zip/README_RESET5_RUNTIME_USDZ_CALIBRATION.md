# RESET5 — Runtime USDZ Calibration

Build 50 / 0.9.0-RESET5.

Physical RESET3/RESET4 testing proved that calibrating the Fab-converted USDZ with coordinates measured from the original GLB is invalid: the converted USDZ can contain a baked root/axis transform.

RESET5 therefore measures the actual RealityKit entity after loading the bundled USDZ. It uses `visualBounds(relativeTo:)` plus the imported screen entity to derive room scale, front direction, floor, rear-half viewer point, eye height, and yaw. The selected viewer point is then mapped to the tracked Vision Pro origin. No GLB coordinate is used to position the runtime USDZ.

The original paid Blender/GLB/textures remain the authoritative source assets for a future offline asset conversion pipeline; this build fixes the runtime placement of the currently bundled paid USDZ without another guessed offset.
