# RESET2 — New Cinema + Tracked Tablet Placement

Build 47 / 0.9.0-RESET2.

This build moves forward in one pass as requested: a completely new cinema environment is authored from scratch in meter-scale RealityKit geometry while the controller placement is corrected at the same time.

- No TF1/38B/legacy theater implementation is restored.
- The cinema root is calibrated from the tracked Vision Pro device pose.
- The tablet stays disabled until a valid tracked pose exists, preventing the previous temporary world-origin/floor spawn.
- Recenter resets the tablet and recalibrates the cinema wearer origin.
- Screen is 6.6–8m forward, floor is 1.3m below eye origin, and seats begin behind/to the sides of the wearer with a clear center position.
- The environment includes floor, ceiling, walls, a framed architectural screen, and black seating.

Physical Vision Pro testing remains authoritative for runtime placement.
