# Signal Vision Pro RESET1 — Clean Immersive Foundation

This build intentionally removes every previous movie-theater environment implementation from the active project.

Removed:
- SignalTheaterFoundationTF1.swift
- SignalVisionTheater.swift
- SignalVisionSpatialControls.swift
- SignalVisionPremiumTheaterCatalog.swift
- SignalVisionCinemaLaunchProbe.swift
- Resources/Cinema (all purchased/CC0 theater models and profiles)
- Resources/TheaterEnvironmentCatalog.json
- cinema asset fetch/verification scripts
- all active workflow gates that fetched, validated, or bundled legacy theater assets

Added:
- SignalImmersiveFoundation.swift
- empty Full Space with no theater geometry
- one personal control tablet only
- world-space spawn frame derived from headset yaw only (pitch/roll discarded)
- controller drag is defined in the user spawn frame: right drag = +X/right, left drag = -X/left
- no parent theater transform can mirror controller movement
- recenter and tablet reset controls

The purpose of RESET1 is not to look like a theater. It is a hard reset checkpoint. Physical Vision Pro testing must first prove that the immersive origin and controller directions are correct. Only after that should a completely new theater importer/environment system be added.

No Signal dashboard, cinema screen, theater model, AVPlayer, VideoMaterial, or legacy theater environment is instantiated by the new immersive foundation.
