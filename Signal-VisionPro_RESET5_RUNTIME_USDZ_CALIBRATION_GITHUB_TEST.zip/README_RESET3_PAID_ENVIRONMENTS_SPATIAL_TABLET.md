# Signal Vision Pro RESET3 — Paid Environments + Spatial Tablet

Build 48 / 0.9.0-RESET3.

This patches forward from RESET2 while preserving the clean-slate immersive architecture.

## Restored as geometry only
- `SignalPaidFabMovieTheater.usdz` from the user-supplied/purchased `movietheater.usdz` asset.
- `SignalPaidCinemaInterior.usdz` from the user-supplied/purchased `cinemamovie_theater_interior.usdz` asset.
- Neither restores the deleted legacy theater coordinator, seat transform system, duplicate playback surface, or old TF1 world placement code.

## Tablet changes
- Initial tablet target: centered, +0.10m above head-local origin, 0.88m forward.
- Recenter derives a fresh yaw-only root from the currently tracked Vision Pro device pose.
- Drag is now a RealityKit targeted entity gesture. The 3D pinch location is converted into the tablet parent's coordinate system, rather than multiplying a 2D SwiftUI pixel delta.
- InputTarget, Collision, and HoverEffect components are attached to the tablet entity.

## Environment controls
The controller exposes Paid FAB Theater, Paid Cinema Interior, and Clean Room plus room scale/depth/height adjustment. The paid FAB transform deliberately moves its seat bank behind the calibrated wearer origin.

Physical Vision Pro testing remains authoritative for placement and interaction.
