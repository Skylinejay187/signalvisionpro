# RESET5 — Calibrated Paid Environments + Dedicated Spatial Tablet Handle

Build 50 / 0.9.0-RESET5.

Physical RESET3 headset screenshots proved the paid environment geometry was still intersecting the wearer. RESET5 removes all arbitrary whole-model translations and calibrates each imported asset from a known source-space seated viewer point. The source viewer point is transformed exactly to the tracked Vision Pro head origin, and both environments are rotated so their architectural screen is in local -Z (straight ahead).

Paid FAB model calibration: viewer source point `(0.0, 2.50, -12.50)`, base scale `0.35`, yaw `pi`. This places the rear-most seat bank in front of the wearer rather than through the head and puts the source screen straight ahead.

Paid Cinema Interior calibration: viewer source point `(-69.47, 0.15, -30.80)`, base scale `1.0`, yaw `pi`. This is derived from the supplied model bounds and screen plane around z=-22.46.

The tablet starts at tracked eye height (`y=0`) about 0.82 m ahead. It now has a separate RealityKit `SignalTabletDragHandle` above the SwiftUI tablet so buttons/pickers cannot consume the pinch used for spatial movement.
