# RESET1C — Catalog Arrows Compile Fix

Build 46 / 0.9.0-RESET1C.

This patch keeps the RESET1 clean immersive foundation unchanged and restores only the app-wide `SignalVisionCatalogArrows` navigation palette that remained referenced by the catalog overlay after legacy theater sources were removed.

The component is intentionally embedded in `SignalVisionNavigationCompat.swift`, the same guaranteed-compiled compatibility unit that owns `SignalVisionRemoteEvent` and `SignalMoveDirection`. No theater environment, seating, screen, or legacy theater coordinator is restored.
