import SwiftUI
import AVKit

// Native visionOS presentation. All displayed catalog/channel records are loaded
// through VisionSourceBridge from the SAME vBRDC357 official manifest/M3U contracts;
// the underlying MediaItem/MediaRow/LiveTVChannel are the original tvOS models.
private enum SignalSection: String, CaseIterable, Identifiable {
    case home = "Home"
    case movies = "Movies"
    case shows = "Shows"
    case liveTV = "Live TV"
    case player = "Player"
    case settings = "Settings"
    var id: String { rawValue }
    var symbol: String {
        switch self {
        case .home: "house.fill"
        case .movies: "film.fill"
        case .shows: "play.tv.fill"
        case .liveTV: "tv.fill"
        case .player: "play.rectangle.fill"
        case .settings: "gearshape.fill"
        }
    }
}

struct SignalRootView: View {
    @State private var selection: SignalSection? = .home
    @AppStorage("signal.backendURL") private var backendURL = ""
    @AppStorage("signal.streamURL") private var streamURL = ""
    @AppStorage("signal.catalogManifestURL") private var catalogManifestURL = VisionSourceBridge.officialManifest
    @AppStorage("signal.livePlaylistURL") private var livePlaylistURL = ""
    @State private var backendStatus = "Not checked"
    @State private var checking = false
    @State private var catalogLoading = false
    @State private var catalogStatus = "Not loaded"
    @State private var catalogRows: [MediaRow] = []
    @State private var liveLoading = false
    @State private var liveStatus = "No lineup loaded"
    @State private var channels: [LiveTVChannel] = []
    @State private var category = "All"
    @State private var query = ""
    @State private var selectedMedia: MediaItem?
    @State private var player: AVPlayer?
    @State private var playingTitle = ""
    @State private var playbackError = ""

    var body: some View {
        NavigationSplitView {
            List(SignalSection.allCases, selection: $selection) { section in
                Label(section.rawValue, systemImage: section.symbol).tag(section)
            }
            .navigationTitle("SIGNAL")
            .listStyle(.sidebar)
        } detail: {
            Group {
                switch selection ?? .home {
                case .home: catalogScreen(kind: nil)
                case .movies: catalogScreen(kind: "movie")
                case .shows: catalogScreen(kind: "series")
                case .liveTV: liveTV
                case .player: playback
                case .settings: settings
                }
            }
            .frame(maxWidth: .infinity, maxHeight: .infinity)
            .padding(28)
        }
        .sheet(item: $selectedMedia) { item in
            mediaDetails(item)
                .frame(minWidth: 650, minHeight: 470)
        }
        .task {
            // Loading occurs only on first presentation, not on every navigation.
            if catalogRows.isEmpty { await loadCatalogs() }
        }
        .onDisappear { player?.pause() }
    }

    private var branding: some View {
        HStack(spacing: 16) {
            Image("SignalChromeWordmark")
                .resizable().scaledToFit().frame(width: 230, height: 90)
                .accessibilityLabel("Signal")
            VStack(alignment: .leading, spacing: 4) {
                Text("SIGNAL").font(.title2.bold())
                Text("Vision Pro • Apple TV vBRDC357 source port")
                    .font(.caption).foregroundStyle(.secondary)
            }
            Spacer()
        }
    }

    private func catalogScreen(kind: String?) -> some View {
        ScrollView {
            LazyVStack(alignment: .leading, spacing: 26) {
                branding
                HStack {
                    Text(kind == nil ? "Home" : (kind == "movie" ? "Movies" : "Shows"))
                        .font(.largeTitle.bold())
                    Spacer()
                    if catalogLoading { ProgressView() }
                    Button("Refresh catalogs", systemImage: "arrow.clockwise") {
                        Task { await loadCatalogs() }
                    }.disabled(catalogLoading)
                }
                Text(catalogStatus).font(.caption).foregroundStyle(.secondary)
                if let error = catalogError { Text(error).foregroundStyle(.orange) }
                let rows = catalogRows.filter { row in
                    kind == nil || row.items.contains(where: { normalizedKind($0.type) == kind })
                }
                ForEach(rows) { row in
                    let visible = row.items.filter { kind == nil || normalizedKind($0.type) == kind }
                    if !visible.isEmpty {
                        VStack(alignment: .leading, spacing: 12) {
                            Text(row.title).font(.title2.bold())
                            ScrollView(.horizontal) {
                                LazyHStack(spacing: 16) {
                                    ForEach(visible) { item in
                                        Button { selectedMedia = item } label: {
                                            VStack(alignment: .leading, spacing: 7) {
                                                AsyncImage(url: URL(string: item.posterURL ?? "")) { image in
                                                    image.resizable().scaledToFill()
                                                } placeholder: {
                                                    RoundedRectangle(cornerRadius: 14)
                                                        .fill(.quaternary)
                                                        .overlay { Image(systemName: "film") }
                                                }
                                                .frame(width: 154, height: 228)
                                                .clipShape(RoundedRectangle(cornerRadius: 14))
                                                Text(item.title).font(.caption.bold()).lineLimit(2)
                                                    .frame(width: 154, alignment: .leading)
                                                Text(item.year).font(.caption2).foregroundStyle(.secondary)
                                            }
                                        }
                                        .buttonStyle(.plain)
                                        .accessibilityLabel("Open \(item.title)")
                                    }
                                }.padding(8)
                            }.scrollIndicators(.hidden)
                        }
                    }
                }
                if !catalogLoading && rows.isEmpty {
                    ContentUnavailableView("No catalogs loaded", systemImage: "square.stack",
                        description: Text("Check the catalog manifest URL in Settings and reload."))
                }
            }
            .frame(maxWidth: .infinity, alignment: .leading)
        }
        .navigationTitle(kind == nil ? "Home" : (kind == "movie" ? "Movies" : "Shows"))
    }

    private var catalogError: String? {
        catalogStatus.hasPrefix("Error:") ? catalogStatus : nil
    }
    private func normalizedKind(_ raw: String) -> String {
        ["series", "show", "tv", "episode"].contains(raw.lowercased()) ? "series" : "movie"
    }

    private func mediaDetails(_ item: MediaItem) -> some View {
        HStack(alignment: .top, spacing: 24) {
            AsyncImage(url: URL(string: CatalogArtworkCacheManager.preferredBackdropURL(for: item) ?? "")) { image in
                image.resizable().scaledToFit()
            } placeholder: { Image(systemName: "film").font(.largeTitle) }
                .frame(width: 210, height: 320)
            VStack(alignment: .leading, spacing: 14) {
                Text(item.title).font(.largeTitle.bold())
                Text([item.year, item.rating, item.catalog].filter { !$0.isEmpty }.joined(separator: " • "))
                    .font(.subheadline).foregroundStyle(.secondary)
                Text(item.description.isEmpty ? "No description available." : item.description)
                if !item.genres.isEmpty { Text(item.genres.joined(separator: " • ")).font(.caption) }
                Text("The vBRDC357 source resolver and player-engine handoff are not yet compiled for visionOS. Do not treat this screen as full VOD playback.")
                    .font(.caption).foregroundStyle(.secondary)
                Button("Close") { selectedMedia = nil }
                Spacer()
            }
        }
        .padding(28)
    }

    private var liveTV: some View {
        VStack(alignment: .leading, spacing: 16) {
            branding
            HStack {
                Text("Live TV").font(.largeTitle.bold())
                Spacer()
                if liveLoading { ProgressView() }
                Button("Reload lineup", systemImage: "arrow.clockwise") { Task { await loadLineup() } }
                    .disabled(liveLoading || livePlaylistURL.isEmpty)
            }
            Text(liveStatus).font(.caption).foregroundStyle(.secondary)
            if channels.isEmpty {
                ContentUnavailableView("No channels loaded", systemImage: "tv",
                    description: Text("Enter your existing M3U playlist URL in Settings, then reload the lineup."))
            } else {
                TextField("Find channel", text: $query)
                let categories = ["All"] + Array(Set(channels.map(\.category))).sorted()
                Picker("Category", selection: $category) {
                    ForEach(categories, id: \.self) { Text($0).tag($0) }
                }.pickerStyle(.menu)
                List {
                    ForEach(channels.filter { channel in
                        (category == "All" || channel.category == category) &&
                        (query.isEmpty || channel.name.localizedCaseInsensitiveContains(query) || channel.number.contains(query))
                    }) { channel in
                        Button {
                            streamURL = channel.streamURL
                            startPlayback(title: channel.name)
                        } label: {
                            HStack(spacing: 16) {
                                AsyncImage(url: URL(string: channel.iconURL)) { image in
                                    image.resizable().scaledToFit()
                                } placeholder: { Image(systemName: "tv") }
                                .frame(width: 64, height: 46)
                                Text(channel.number).font(.subheadline.monospacedDigit())
                                VStack(alignment: .leading) {
                                    Text(channel.name).font(.headline)
                                    Text(channel.category).font(.caption).foregroundStyle(.secondary)
                                }
                                Spacer()
                                Image(systemName: "play.fill")
                            }.padding(.vertical, 5)
                        }
                    }
                }.listStyle(.plain)
            }
        }
        .navigationTitle("Live TV")
        .task { if channels.isEmpty && !livePlaylistURL.isEmpty { await loadLineup() } }
    }

    private var playback: some View {
        VStack(alignment: .leading, spacing: 16) {
            Text(playingTitle.isEmpty ? "Player" : playingTitle).font(.largeTitle.bold())
            if let player {
                VideoPlayer(player: player)
                    .frame(minHeight: 440)
                    .clipShape(RoundedRectangle(cornerRadius: 16))
                Button("Stop playback") { player.pause(); self.player = nil }
            } else {
                ContentUnavailableView("No stream selected", systemImage: "play.rectangle",
                    description: Text("Select a channel in Live TV or enter a direct stream in Settings."))
            }
            if !playbackError.isEmpty { Text(playbackError).foregroundStyle(.orange) }
            Spacer(minLength: 0)
        }
        .navigationTitle("Player")
    }

    private var settings: some View {
        Form {
            Section("Backend") {
                TextField("Backend URL", text: $backendURL)
                    .textInputAutocapitalization(.never).autocorrectionDisabled()
                Button(checking ? "Checking…" : "Check backend") { Task { await checkBackend() } }
                    .disabled(checking)
                Text(backendStatus).font(.caption).foregroundStyle(.secondary)
            }
            Section("Official Signal catalogs") {
                TextField("Manifest URL", text: $catalogManifestURL)
                    .textInputAutocapitalization(.never).autocorrectionDisabled()
                Button("Load catalogs") { Task { await loadCatalogs() } }.disabled(catalogLoading)
                Text("Defaults to the same internal all-in-one manifest URL as Apple TV vBRDC357.")
                    .font(.caption).foregroundStyle(.secondary)
            }
            Section("Live TV") {
                TextField("Your M3U playlist URL", text: $livePlaylistURL)
                    .textInputAutocapitalization(.never).autocorrectionDisabled()
                Button("Load channel lineup") { Task { await loadLineup() } }
                    .disabled(livePlaylistURL.isEmpty || liveLoading)
                Text("Playlist credentials remain in local app settings. Xtream, Channels DVR, guide/EPG, and provider-specific playback adapters need additional porting.")
                    .font(.caption).foregroundStyle(.secondary)
                TextField("Direct HTTP(S) playback URL", text: $streamURL)
                    .textInputAutocapitalization(.never).autocorrectionDisabled()
                Button("Play direct stream") { startPlayback(title: "Direct stream") }
            }
            Section("Port information") {
                LabeledContent("Build", value: "Vision Pro Build 4")
                LabeledContent("Apple TV source", value: "vBRDC357 (unchanged reference)")
                LabeledContent("Compiled", value: "Real catalog rows, M3U lineup, shared models, AVKit")
                LabeledContent("Pending", value: "Full VOD resolver, EPG, membership, Trakt, Aether / KS")
            }
        }.navigationTitle("Settings")
    }

    @MainActor
    private func loadCatalogs() async {
        guard !catalogLoading else { return }
        catalogLoading = true
        catalogStatus = "Loading original Signal catalog manifest…"
        defer { catalogLoading = false }
        do {
            let rows = try await VisionSourceBridge.catalogs(manifest: catalogManifestURL)
            catalogRows = rows
            catalogStatus = "\(rows.count) live catalog rows • \(rows.reduce(0) { $0 + $1.items.count }) titles"
        } catch { catalogStatus = "Error: \(error.localizedDescription)" }
    }

    @MainActor
    private func loadLineup() async {
        guard !liveLoading else { return }
        liveLoading = true
        liveStatus = "Loading lineup…"
        defer { liveLoading = false }
        do {
            channels = try await VisionSourceBridge.channels(playlist: livePlaylistURL)
            if !channels.contains(where: { $0.category == category }) { category = "All" }
            liveStatus = "\(channels.count) channels • M3U source"
        } catch { liveStatus = "Error: \(error.localizedDescription)" }
    }

    private func startPlayback(title: String) {
        let trimmed = streamURL.trimmingCharacters(in: .whitespacesAndNewlines)
        guard let url = URL(string: trimmed), ["https", "http"].contains(url.scheme?.lowercased() ?? ""), url.host != nil else {
            playbackError = "Enter a valid HTTP or HTTPS stream URL."
            selection = .player
            return
        }
        playbackError = ""
        player?.pause()
        player = AVPlayer(url: url)
        playingTitle = title
        selection = .player
        player?.play()
    }

    @MainActor
    private func checkBackend() async {
        guard !checking else { return }
        checking = true
        defer { checking = false }
        guard let url = URL(string: backendURL.trimmingCharacters(in: .whitespacesAndNewlines)),
              ["https", "http"].contains(url.scheme?.lowercased() ?? ""), url.host != nil else {
            backendStatus = "Enter a valid backend URL."
            return
        }
        var request = URLRequest(url: url.appendingPathComponent("health"), timeoutInterval: 12)
        request.setValue("application/json", forHTTPHeaderField: "Accept")
        do {
            let (_, response) = try await URLSession.shared.data(for: request)
            if let http = response as? HTTPURLResponse {
                backendStatus = "HTTP \(http.statusCode) • \(url.host ?? "backend")"
            } else { backendStatus = "Server responded" }
        } catch { backendStatus = "Unreachable: \(error.localizedDescription)" }
    }
}
