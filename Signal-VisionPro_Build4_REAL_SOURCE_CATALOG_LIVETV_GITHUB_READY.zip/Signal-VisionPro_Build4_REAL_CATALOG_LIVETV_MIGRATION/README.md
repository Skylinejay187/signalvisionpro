# Signal Vision Pro — Build 4 (real catalog / M3U source-port milestone)

**Source anchor:** Apple TV `vBRDC357`, version 1.0.1059. **visionOS:** version 0.4.0 (4). The original Apple TV project in `AppleTVSource_vBRDC357/` is left unchanged; the tvOS GitHub repository is not modified.

This is a substantially expanded port, **not yet full Apple TV feature parity**. Unlike the previous tiny shell app, the visionOS target now compiles the original Signal image asset catalog (excluding incompatible tvOS-only `AppIcon.brandassets`), adds the unchanged original `CatalogArtworkCacheManager`, reuses unchanged original media/channel/program models and the existing compiled shared network/profile code, and implements live catalog/Live TV consumption of the **same** vBRDC357 protocols.

## What is actually in the visionOS executable

- Home/Movies/Shows: real catalog requests to the original built-in manifest (`https://catalog.skylinejay187.it.com/manifest.json`), batch catalog endpoint if provided, then bounded standard Stremio catalog fallback. Media tiles show fetched posters, title, year, details and metadata. No demo/fabricated catalog entries.
- Live TV: M3U playlist URL configured in Settings; fetch and parse #EXTINF, groups, logos, channel numbers and playable URLs. Search by channel name/number, filter by category, open selected stream in native AVKit. The original `LiveTVChannel` model is used.
- Shared: original `MediaItem`, `MediaRow`, `LiveTVChannel`, `LiveProgram`, original `CatalogArtworkCacheManager`, PlainHTTPClient, BackendProfileBackupClient, SportsChannelClassifierManager and LiveTVProgramProgressLine are in the visionOS target.
- Branding: original Apple TV image assets, including animated-logo artwork source imagery, in the *compiled* visionOS asset catalog. tvOS-only AppIcon brandassets excluded because they are not a valid visionOS icon.
- GitHub workflow: recognizes Build 4 extracted source or Build 4 ZIP (not stale Build 2/3 project); simulator and unsigned device IPA plus logs, validates that original Assets.car is present in device app.

## Not ported — do not confuse with a complete release

- The original 13,000-line `CatalogStore` (advanced caching/customization/full pagination, all addon providers), full Live TV Dashboard Preview Mirror visuals, EPG guide/Gracenote, Xtream/Channels DVR source adapters, settings/membership UI, Trakt, source resolver, VOD link selection, AetherEngine, KSPlayer, watch party and immersive theater are **not yet compiled/functional on visionOS**. The full original source trees are retained only as a source reference for further platform adaptation. This build's VOD media-detail screen deliberately does not present a broken Play button.
- Playback in this build uses the interim AVKit direct-stream path, which may not support every original file/codec. No claim of KS/Aether compatibility is made.
- The IPAs produced by GitHub are unsigned and need a compatible visionOS signing provider.
- No full Xcode or physical-device build was possible in this environment; Swift syntax parsing and archive validation are not device build verification.

## Upload and build

Replace the previous Vision Pro repository contents with the **extracted contents** of this ZIP, preserving `.github/workflows/build-visionos.yml`, `Resources/Assets.xcassets/`, `Sources/`, `SharedFromAppleTV/` and `AppleTVSource_vBRDC357/`. If uploading just the ZIP to the repository root, make sure there is only one Build 4 ZIP; the workflow can extract it. Previous Build 2/3 ZIPs are not accepted as Build 4 source. Run GitHub Actions → `Signal Vision Pro - Source Port + Device IPA`. Download the device-IPA artifact, **extract its `.ipa`** then submit to your signing provider.

## Configuration

The original built-in catalog manifest URL is preconfigured and requires internet access. To view your Live TV channels, enter your reachable existing M3U playlist URL in Settings; this version does not yet import old tvOS settings into the different visionOS app sandbox. Backend `/health` can be tested separately. This project does not edit your backend or disable membership; restore membership in the backend independently as planned.
