import SwiftUI

/// Build 22 native controls. The original Unity Live TV, catalog and detail
/// visuals stay mounted in RootView; only the active surface is interactive.
/// This is a same-window focus-layer foundation, NOT a claim that visionOS
/// supports non-movable, perfectly coincident independent system windows.
struct SignalVisionSpatialControls: View {
    @EnvironmentObject private var store: CatalogStore
    @EnvironmentObject private var unityCore: UnityAppCore
    @EnvironmentObject private var theater: SignalVisionTheaterCoordinator
    @Environment(\.openImmersiveSpace) private var openImmersiveSpace
    @Environment(\.dismissImmersiveSpace) private var dismissImmersiveSpace
    @AppStorage("signalVisionPersistentTheaterV22") private var persistentTheater = true
    @State private var preferencesVisible = false

    private var playbackActive: Bool { store.playbackURL != nil }
    private var detailActive: Bool { store.selectedDetail != nil }
    private var canGoBack: Bool {
        playbackActive || detailActive || store.searchActive || store.liveQuickPanelOpen || store.selectedTab != .live
    }

    var body: some View {
        Group {
            // A window ornament lives OUTSIDE the fixed-size Signal canvas.
            // It never obscures Guide, footer chips, navigation, or the player.
            if !playbackActive {
                HStack(spacing: 12) {
                    if canGoBack {
                        Button(action: goBack) {
                            Label("Back", systemImage: "chevron.backward")
                                .frame(minHeight: 44)
                        }
                        .accessibilityLabel("Back one Signal layer")
                    }
                    Button {
                        preferencesVisible = true
                    } label: {
                        Label("Vision Pro / Theater", systemImage: "theatermasks")
                            .frame(minHeight: 44)
                    }
                    .accessibilityLabel("Vision Pro theater settings")
                }
                .buttonStyle(.bordered)
                .padding(10)
                .background(.ultraThinMaterial, in: Capsule())
            }
        }
        .sheet(isPresented: $preferencesVisible) {
            VStack(alignment: .leading, spacing: 22) {
                Text("Signal · Vision Pro")
                    .font(.title2.bold())
                Text("The original Signal design and player remain unchanged. Theater entry is requested through visionOS.")
                    .font(.subheadline)
                    .foregroundStyle(.secondary)
                Toggle("Stay in Classic Cinema", isOn: $persistentTheater)
                    .toggleStyle(.switch)
                Text(persistentTheater
                     ? "Cinema stays open until you explicitly exit it."
                     : "Cinema closes when playback ends.")
                    .font(.caption)
                    .foregroundStyle(.secondary)
                if let error = theater.entryFailure {
                    Text(error).foregroundStyle(.orange)
                        .accessibilityLabel("Theater error: \(error)")
                }
                Button("Enter Classic Cinema", systemImage: "theatermasks.fill") {
                    preferencesVisible = false
                    requestTheater()
                }
                .buttonStyle(.borderedProminent)
                .disabled(theater.transitionInProgress)
                if theater.immersiveActive {
                    Button("Exit Theater", systemImage: "xmark") {
                        preferencesVisible = false
                        Task { @MainActor in
                            await dismissImmersiveSpace()
                            theater.immersiveActive = false
                        }
                    }
                    .buttonStyle(.bordered)
                }
                Button("Close Settings") { preferencesVisible = false }
                    .buttonStyle(.bordered)
            }
            .padding(30)
            .frame(width: 510)
        }
    }

    private func goBack() {
        if playbackActive { store.closePlayer(); return }
        if detailActive {
            if let previous = store.detailBackStack.popLast() {
                store.selectedDetail = previous
            } else {
                store.selectedDetail = nil
            }
            return
        }
        if store.searchActive { store.searchActive = false; return }
        if store.liveQuickPanelOpen { store.liveQuickPanelOpen = false; return }
        if store.selectedTab != .live {
            unityCore.select(.live, store: store, reason: "visionOS spatial layer unwind")
            return
        }
        NotificationCenter.default.post(name: SignalVisionRemoteEvent.back, object: nil)
    }

    private func requestTheater() {
        guard !theater.transitionInProgress else { return }
        Task { @MainActor in
            theater.transitionInProgress = true
            defer { theater.transitionInProgress = false }
            theater.entryFailure = nil
            if theater.immersiveActive {
                print("[SignalVisionCinema] Ignoring duplicate entry: cinema is already active")
                return
            }
            theater.mode = persistentTheater ? .app : (playbackActive ? .playback : .app)
            // Do not request the immersive scene during the sheet dismissal animation.
            // The controls/ornament view remains mounted after the sheet disappears.
            try? await Task.sleep(nanoseconds: 350_000_000)
            print("[SignalVisionCinema] Requesting signal-theater; mode=\(theater.mode.rawValue)")
            switch await openImmersiveSpace(id: "signal-theater") {
            case .opened:
                theater.immersiveActive = true
                print("[SignalVisionCinema] Immersive space opened")
            case .userCancelled:
                theater.entryFailure = "Theater entry was cancelled. Choose Enter Classic Cinema to retry."
                print("[SignalVisionCinema] userCancelled")
            case .error:
                // .error does NOT prove any headset permission was denied.
                theater.entryFailure = "Classic Cinema could not open. The system returned an entry error; no permission denial was confirmed. Exit another immersive app if one is open and retry. See [SignalVisionCinema] device logs."
                print("[SignalVisionCinema] openImmersiveSpace returned .error (reason unspecified)")
            @unknown default:
                theater.entryFailure = "Theater entry returned an unknown result; check device logs."
                print("[SignalVisionCinema] unknown openImmersiveSpace result")
            }
        }
    }
}

/// Build 23: ONLY shown when the original Unity catalog owns the canvas.
/// Calls its existing rail-selection logic directly through the active rail,
/// rather than forwarding to the tvOS focus engine or the removed virtual remote.
struct SignalVisionCatalogArrows: View {
    private func arrow(_ symbol: String, _ label: String, _ direction: SignalMoveDirection) -> some View {
        Button {
            NotificationCenter.default.post(name: SignalVisionRemoteEvent.catalogDirection, object: direction)
        } label: {
            Image(systemName: symbol)
                .font(.system(size: 18, weight: .bold))
                .frame(width: 46, height: 46)
        }
        .buttonStyle(.bordered)
        .hoverEffect(.highlight)
        .accessibilityLabel(label)
    }

    var body: some View {
        VStack(spacing: 6) {
            arrow("chevron.up", "Previous catalog row", .up)
            HStack(spacing: 6) {
                arrow("chevron.left", "Previous poster", .left)
                arrow("chevron.right", "Next poster", .right)
            }
            arrow("chevron.down", "Next catalog row", .down)
        }
        .padding(8)
        .background(.ultraThinMaterial, in: RoundedRectangle(cornerRadius: 22))
        .accessibilityLabel("Catalog navigation")
    }
}
