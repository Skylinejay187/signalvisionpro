# Build 38F

Base: Build 38E (which was rebuilt from the user's uploaded Build 38B).

Changes:
- Media Information popup presentation restored to the Build 25A behavior:
  stageBackdropVisible owns presentation again; the visionOS 1920x1080 transparent
  compositor background and mediaInfoPanelPresented override are removed.
- The normal Signal main window is dismissed while the internal immersive theater
  is active and reopened on exit/disappearance, removing the persistent second window.
- The theater HUD can now be grabbed and dragged. Its position continues to persist
  through the existing AppStorage HUD X/Y values.
- Every internal theater receives deterministic procedural seats, aisles, front
  stage and side fixtures even with external cinema downloads disabled.
- External Theater-app handoff retains the app-only launch behavior that physically
  opened Theater in 38E, expands media payload variants, remembers an accepted
  route/variant, and never falls back to Safari.
- No Build 39 source is used.
