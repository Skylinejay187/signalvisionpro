# Build 38G — actual runtime-path correction

Base: Build 38F / user-supplied Build38B lineage.

Fixes:
- Media Information: replaces the entire SignalVisionLayerSurface implementation
  with the proven Build25A version. This removes the later detail-level
  ultraThinMaterial/compositingGroup that was creating the gray sheet behind the
  popup. This is the real outer layer that 38E/38F had not removed.
- Main Signal window: RootView is forced invisible/noninteractive whenever the
  immersive theater is active, in addition to dismissWindow.
- Internal theater: removes the world-level independent video-screen entity.
  The single VideoMaterial surface is now a child of the selected theater
  environment at the architectural screen coordinates.
- HUD: fixes cumulative drag math so it behaves like a movable controller
  rather than jumping/clamping while dragging.
- External Theater app: no Safari fallback. A successful app launch is no
  longer mistaken for successful media playback. Each press advances to the
  next media payload shape while prioritizing the route already proven to open
  Theater.
