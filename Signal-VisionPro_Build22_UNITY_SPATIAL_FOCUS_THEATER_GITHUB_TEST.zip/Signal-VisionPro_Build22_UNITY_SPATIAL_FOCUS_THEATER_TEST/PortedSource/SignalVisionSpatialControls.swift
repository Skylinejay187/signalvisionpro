import SwiftUI

/// Build 22 native controls. The original Unity Live TV, catalog and detail
/// visuals stay mounted in RootView; only the active surface is interactive.
/// This is a same-window focus-layer foundation, NOT a claim that visionOS
/// supports non-movable, perfectly coincident independent system windows.
struct SignalVisionSpatialControls: View {
    @EnvironmentObject private var store: CatalogStore
    @EnvironmentObject private var unityCore: UnityAppCore
    @EnvironmentObject private var theater: SignalVisionTheaterCoordinator
    @Environment(\.openImmersiveSpace) private var openImmersiveSpace
    @Environment(\.dismissImmersiveSpace) private var dismissImmersiveSpace
    @AppStorage("signalVisionPersistentTheaterV22") private var persistentTheater = false
    @State private var preferencesVisible = false

    private var playbackActive: Bool { store.playbackURL != nil }
    private var detailActive: Bool { store.selectedDetail != nil }
    private var canGoBack: Bool {
        playbackActive || detailActive || store.searchActive || store.liveQuickPanelOpen || store.selectedTab != .live
    }

    var body: some View {
        VStack {
            HStack(alignment: .top) {
                if canGoBack {
                    Button(action: goBack) {
                        Label("Back", systemImage: "chevron.backward")
                            .font(.system(size: 16, weight: .semibold))
                            .padding(.horizontal, 12)
                            .frame(minHeight: 44)
                    }
                    .buttonStyle(.bordered)
                    .hoverEffect(.highlight)
                    .accessibilityLabel(playbackActive ? "Exit playback" : "Back one Signal layer")
                }
                Spacer(minLength: 8)
                if playbackActive {
                    Button {
                        store.closePlayer()
                    } label: {
                        Image(systemName: "xmark")
                            .font(.system(size: 18, weight: .bold))
                            .frame(width: 46, height: 46)
                    }
                    .buttonStyle(.borderedProminent)
                    .hoverEffect(.highlight)
                    .accessibilityLabel("Close playback and return to Signal")
                } else {
                    Button {
                        preferencesVisible = true
                    } label: {
                        Label("Theater", systemImage: "theatermasks")
                            .font(.system(size: 14, weight: .semibold))
                            .padding(.horizontal, 10)
                            .frame(minHeight: 44)
                    }
                    .buttonStyle(.bordered)
                    .hoverEffect(.highlight)
                    .accessibilityLabel("Vision Pro theater settings")
                }
            }
            .padding(.horizontal, 24)
            .padding(.top, 64)
            Spacer(minLength: 0)
        }
        .sheet(isPresented: $preferencesVisible) {
            VStack(alignment: .leading, spacing: 22) {
                Text("Signal · Vision Pro")
                    .font(.title2.bold())
                Text("The original Signal design and player remain unchanged. Theater entry is requested through visionOS.")
                    .font(.subheadline)
                    .foregroundStyle(.secondary)
                Toggle("Stay in Classic Cinema", isOn: $persistentTheater)
                    .toggleStyle(.switch)
                Text(persistentTheater
                     ? "Cinema stays open until you explicitly exit it."
                     : "Cinema closes when playback ends.")
                    .font(.caption)
                    .foregroundStyle(.secondary)
                if let error = theater.entryFailure {
                    Text(error).foregroundStyle(.orange)
                        .accessibilityLabel("Theater error: \(error)")
                }
                Button("Enter Classic Cinema", systemImage: "theatermasks.fill") {
                    preferencesVisible = false
                    requestTheater()
                }
                .buttonStyle(.borderedProminent)
                .disabled(theater.transitionInProgress)
                if theater.immersiveActive {
                    Button("Exit Theater", systemImage: "xmark") {
                        preferencesVisible = false
                        Task { @MainActor in
                            await dismissImmersiveSpace()
                            theater.immersiveActive = false
                        }
                    }
                    .buttonStyle(.bordered)
                }
                Button("Close Settings") { preferencesVisible = false }
                    .buttonStyle(.bordered)
            }
            .padding(30)
            .frame(width: 510)
        }
    }

    private func goBack() {
        if playbackActive { store.closePlayer(); return }
        if detailActive {
            if let previous = store.detailBackStack.popLast() {
                store.selectedDetail = previous
            } else {
                store.selectedDetail = nil
            }
            return
        }
        if store.searchActive { store.searchActive = false; return }
        if store.liveQuickPanelOpen { store.liveQuickPanelOpen = false; return }
        if store.selectedTab != .live {
            unityCore.select(.live, store: store, reason: "visionOS spatial layer unwind")
            return
        }
        NotificationCenter.default.post(name: SignalVisionRemoteEvent.back, object: nil)
    }

    private func requestTheater() {
        guard !theater.transitionInProgress else { return }
        Task { @MainActor in
            theater.transitionInProgress = true
            defer { theater.transitionInProgress = false }
            theater.entryFailure = nil
            if theater.immersiveActive {
                await dismissImmersiveSpace()
                theater.immersiveActive = false
            }
            theater.mode = persistentTheater ? .app : (playbackActive ? .playback : .app)
            switch await openImmersiveSpace(id: "signal-theater") {
            case .opened:
                theater.immersiveActive = true
            case .userCancelled:
                theater.entryFailure = "visionOS cancelled theater entry. Open Theater Settings and try again."
            case .error:
                theater.entryFailure = "visionOS declined the immersive space. Check app/immersive permissions on the headset; the app cannot bypass this system decision."
            @unknown default:
                theater.entryFailure = "The immersive space returned an unknown result."
            }
        }
    }
}
