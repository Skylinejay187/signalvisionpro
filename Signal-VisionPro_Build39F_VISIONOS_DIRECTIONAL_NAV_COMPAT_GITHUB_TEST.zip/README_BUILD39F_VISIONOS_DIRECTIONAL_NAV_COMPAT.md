# Build 39F — visionOS directional navigation compatibility

Patched forward from Build 39E. Internal navigation now uses SignalMoveDirection.
tvOS native onMoveCommand remains available behind tvOS compilation guards and
adapts into the shared direction type. visionOS avoids compiling the unavailable
MoveCommandDirection API while preserving Signal's directional routing for its
virtual-remote/gaze navigation path. No playback or theater architecture changes.
Continue using Universal Workflow v4C.
