#if os(visionOS)
import Foundation
import UIKit

/// Build 40 external Theater handoff foundation.
///
/// Important: Theater publicly advertises partner deep-link support, but its
/// arbitrary-media partner URL schema is not publicly documented in the sources
/// we have verified. This bridge deliberately does NOT invent a theater:// URL
/// or guessed query-parameter contract.
///
/// Current behavior:
/// 1. Preserve Signal/Aether playback ownership.
/// 2. Put the already-resolved media URL on the pasteboard as a non-destructive
///    fallback for Theater/import/share workflows.
/// 3. Publish a Signal-owned NSUserActivity carrying title, URL and position.
/// 4. Ask visionOS to open Theater's verified web domain as a Universal Link.
/// 5. Fall back to the web URL if the installed app does not claim the link.
///
/// A documented Sandwich Vision partner-media route can later be dropped into
/// `partnerLaunchURL(...)` without changing Signal's playback architecture.
@MainActor
final class SignalTheaterExternalHandoff {
    static let shared = SignalTheaterExternalHandoff()

    private let diagnostics = SignalVisionDiagnostics.shared
    private let theaterHomeURL = URL(string: "https://in.theater/")!
    private let activityType = "com.signal.vision.external-theater-playback"

    private init() {}

    func openInTheater(
        streamURL: URL,
        title: String,
        playbackPosition: Double
    ) {
        let safePosition = playbackPosition.isFinite ? max(0, playbackPosition) : 0

        // Do not stop, replace or recreate Signal's Aether session here.
        // If the external route fails, current playback remains owned by Signal.
        UIPasteboard.general.string = streamURL.absoluteString

        let activity = NSUserActivity(activityType: activityType)
        activity.title = title.isEmpty ? "Play in Theater" : title
        activity.isEligibleForHandoff = true
        activity.isEligibleForSearch = false
        activity.isEligibleForPublicIndexing = false
        activity.webpageURL = theaterHomeURL
        activity.userInfo = [
            "mediaURL": streamURL.absoluteString,
            "title": title,
            "playbackPosition": safePosition
        ]
        activity.targetContentIdentifier = streamURL.absoluteString
        activity.becomeCurrent()

        let launchURL = partnerLaunchURL(
            streamURL: streamURL,
            title: title,
            playbackPosition: safePosition
        ) ?? theaterHomeURL

        diagnostics.record(
            "external-theater",
            "Build40 external Theater handoff requested for \(title.isEmpty ? "current media" : title); preserving Signal Aether ownership"
        )

        UIApplication.shared.open(
            launchURL,
            options: [.universalLinksOnly: true]
        ) { [weak activity] opened in
            Task { @MainActor in
                if opened {
                    SignalVisionDiagnostics.shared.record(
                        "external-theater",
                        "visionOS accepted Theater Universal Link route"
                    )
                } else {
                    SignalVisionDiagnostics.shared.record(
                        "external-theater",
                        "Theater Universal Link was not claimed; opening verified Theater web fallback"
                    )
                    UIApplication.shared.open(self.theaterHomeURL, options: [:]) { webOpened in
                        Task { @MainActor in
                            SignalVisionDiagnostics.shared.record(
                                "external-theater",
                                webOpened
                                    ? "Theater web fallback opened; resolved media URL remains on pasteboard"
                                    : "Theater handoff route could not be opened"
                            )
                        }
                    }
                }
                activity?.invalidate()
            }
        }
    }

    /// Intentionally nil until Sandwich Vision's actual arbitrary-media partner
    /// schema is verified. Never ship guessed routes such as
    /// `theater://play?url=...` or `https://in.theater/watch?url=...`.
    private func partnerLaunchURL(
        streamURL: URL,
        title: String,
        playbackPosition: Double
    ) -> URL? {
        _ = streamURL
        _ = title
        _ = playbackPosition
        return nil
    }
}
#endif
