import SwiftUI

/// Build 22 native controls. The original Unity Live TV, catalog and detail
/// visuals stay mounted in RootView; only the active surface is interactive.
/// This is a same-window focus-layer foundation, NOT a claim that visionOS
/// supports non-movable, perfectly coincident independent system windows.
struct SignalVisionSpatialControls: View {
    @EnvironmentObject private var store: CatalogStore
    @EnvironmentObject private var unityCore: UnityAppCore
    @EnvironmentObject private var theater: SignalVisionTheaterCoordinator
    @Environment(\.openImmersiveSpace) private var openImmersiveSpace
    private let diagnostics = SignalVisionDiagnostics.shared

    private var playbackActive: Bool { store.playbackURL != nil }
    private var detailActive: Bool { store.selectedDetail != nil }
    private var canGoBack: Bool { playbackActive || detailActive || store.searchActive || store.liveQuickPanelOpen || store.selectedTab != .live }

    var body: some View {
        HStack(spacing: 12) {
            if playbackActive && !theater.immersiveActive {
                Button { requestTheater() } label: {
                    Label("Enter Theater", systemImage: "theatermasks.fill").frame(minHeight: 44)
                }
                .buttonStyle(.borderedProminent)
                .disabled(theater.transitionInProgress)

                Button { requestExternalTheater() } label: {
                    Label("Play in Theater App", systemImage: "arrow.up.right.square.fill").frame(minHeight: 44)
                }
                .buttonStyle(.bordered)
            } else if !theater.immersiveActive && canGoBack {
                Button(action: goBack) { Label("Back", systemImage: "chevron.backward").frame(minHeight: 44) }
            }
        }
        .buttonStyle(.bordered)
        .padding(theater.immersiveActive ? 0 : 10)
        .background(theater.immersiveActive ? AnyShapeStyle(.clear) : AnyShapeStyle(.ultraThinMaterial), in: Capsule())
        .opacity(theater.immersiveActive ? 0 : 1)
        .allowsHitTesting(!theater.immersiveActive)
    }

    private func goBack() {
        if playbackActive { store.closePlayer(); return }
        if detailActive {
            if let previous = store.detailBackStack.popLast() { store.selectedDetail = previous } else { store.selectedDetail = nil }
            return
        }
        if store.searchActive { store.searchActive = false; return }
        if store.liveQuickPanelOpen { store.liveQuickPanelOpen = false; return }
        if store.selectedTab != .live { unityCore.select(.live, store: store, reason: "visionOS spatial layer unwind"); return }
        NotificationCenter.default.post(name: SignalVisionRemoteEvent.back, object: nil)
    }

    private func requestExternalTheater() {
        guard let streamURL = store.playbackURL else { return }
        let title = store.playbackItem?.title ?? "Signal"
        let position = SignalVisionPlaybackHandoff.shared.elapsed
        SignalTheaterExternalHandoff.shared.openInTheater(
            streamURL: streamURL,
            title: title,
            playbackPosition: position
        )
    }

    private func requestTheater() {
        guard !theater.transitionInProgress, !theater.immersiveActive else { return }
        Task { @MainActor in
            guard playbackActive, SignalVisionPlaybackHandoff.shared.sessionID == store.playbackPresentationID else {
                theater.entryFailure = "Start playback and wait for AetherEngine to be ready before entering theater."
                return
            }
            theater.transitionInProgress = true
            defer { theater.transitionInProgress = false }
            theater.entryFailure = nil
            theater.mode = .playback
            switch await openImmersiveSpace(id: "signal-theater") {
            case .opened: theater.immersiveActive = true
            case .userCancelled: theater.entryFailure = "Theater entry was cancelled."
            case .error: theater.entryFailure = "Theater could not open. Exit another immersive app if one is active and retry."
            @unknown default: theater.entryFailure = "Theater entry returned an unknown result."
            }
        }
    }
}

/// Build 23: ONLY shown when the original Unity catalog owns the canvas.
/// Calls its existing rail-selection logic directly through the active rail,
/// rather than forwarding to the tvOS focus engine or the removed virtual remote.
struct SignalVisionCatalogArrows: View {
    let availableSize: CGSize
    @AppStorage("signalVisionCatalogPalettePositionV26") private var locationIndex = 0
    @AppStorage("signalVisionCatalogPaletteOffsetX") private var savedX: Double = 0
    @AppStorage("signalVisionCatalogPaletteOffsetY") private var savedY: Double = 0
    @GestureState private var gestureOffset: CGSize = .zero

    private func arrow(_ symbol: String, _ label: String, _ direction: SignalMoveDirection) -> some View {
        Button {
            NotificationCenter.default.post(name: SignalVisionRemoteEvent.catalogDirection, object: direction)
        } label: {
            Image(systemName: symbol)
                .font(.system(size: 18, weight: .bold))
                .frame(width: 46, height: 46)
        }
        .buttonStyle(.bordered)
        .hoverEffect(.highlight)
        .accessibilityLabel(label)
    }

    private func cyclePosition() {
        locationIndex = (locationIndex + 1) % 4
        let horizontal = max(0, availableSize.width - 230)
        let vertical = max(0, availableSize.height * 0.27)
        switch locationIndex {
        case 1: savedX = Double(horizontal); savedY = 0
        case 2: savedX = Double(horizontal); savedY = Double(-vertical)
        case 3: savedX = 0; savedY = Double(-vertical)
        default: savedX = 0; savedY = 0
        }
    }

    private var repositionGesture: some Gesture {
        DragGesture(minimumDistance: 0)
            .updating($gestureOffset) { value, state, _ in state = value.translation }
            .onEnded { value in
                let x = CGFloat(savedX) + value.translation.width
                let y = CGFloat(savedY) + value.translation.height
                // The palette starts near the left gutter. Keep the grab handle in view.
                savedX = Double(min(max(-4, x), max(0, availableSize.width - 175)))
                savedY = Double(min(max(-availableSize.height * 0.55, y), availableSize.height * 0.38))
            }
    }

    var body: some View {
        VStack(spacing: 6) {
            HStack(spacing: 6) {
                Image(systemName: "hand.draw.fill")
                Button("Move") { cyclePosition() }
                    .buttonStyle(.bordered)
                    .accessibilityLabel("Move catalog controls to another screen corner")
            }
                .font(.system(size: 16, weight: .medium))
                .frame(width: 146, height: 56)
                .contentShape(Rectangle())
                .simultaneousGesture(repositionGesture)
                .accessibilityLabel("Drag or choose Move to reposition catalog controls")
            arrow("chevron.up", "Previous catalog row", .up)
            HStack(spacing: 6) {
                arrow("chevron.left", "Previous poster", .left)
                arrow("chevron.right", "Next poster", .right)
            }
            arrow("chevron.down", "Next catalog row", .down)
        }
        .padding(8)
        .background(Color.black.opacity(0.08), in: RoundedRectangle(cornerRadius: 22))
        .offset(CGSize(width: CGFloat(savedX) + gestureOffset.width,
                       height: CGFloat(savedY) + gestureOffset.height))
        .accessibilityLabel("Movable catalog navigation")
    }
}
