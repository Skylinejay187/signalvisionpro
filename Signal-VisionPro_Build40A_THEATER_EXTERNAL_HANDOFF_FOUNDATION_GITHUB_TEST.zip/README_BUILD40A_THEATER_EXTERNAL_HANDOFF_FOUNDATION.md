# Build 40A — Theater external handoff foundation

Base: successful Build 39S.

Build number:
- CURRENT_PROJECT_VERSION bumped from 39 to 40.

New Vision Pro playback option:
- While Signal playback is active and the internal immersive theater is not open,
  the spatial control bar now shows **Play in Theater App** beside **Enter Theater**.

Current handoff sequence:
1. Keep Signal/Aether playback ownership untouched.
2. Copy the already-resolved playback URL to the system pasteboard as a safe fallback.
3. Publish a Signal-owned NSUserActivity containing media URL, title and playback position.
4. Attempt Theater's verified `https://in.theater/` domain using Universal-Link-only opening.
5. If the app does not claim that link, open the verified Theater web endpoint instead.

Why the resolved media is not yet embedded in a Theater URL:
- Theater publicly documents partner deep-link support, but we have not verified a
  public arbitrary-media parameter schema.
- Build 40A therefore does not invent `theater://play?...` or
  `https://in.theater/watch?url=...`.
- `partnerLaunchURL(...)` is intentionally isolated so the documented route can
  be inserted immediately once verified.

Regression locks:
- Signal's internal Aether playback remains unchanged.
- Signal's own immersive theater remains unchanged.
- External handoff failure does not stop/recreate the active Aether session.
- Universal Workflow v4C remains the build workflow.
