#if os(visionOS)
import Foundation
import SwiftUI
import RealityKit
import ARKit
import QuartzCore
import simd

@MainActor
enum SignalCinemaEnvironment: String, CaseIterable, Identifiable {
    case paidFab = "Paid FAB Theater"
    case paidInterior = "Paid Cinema Interior"
    case cleanRoom = "Clean Room"
    var id: String { rawValue }
}

@MainActor
final class SignalImmersiveFoundationState: ObservableObject {
    static let shared = SignalImmersiveFoundationState()
    @Published var tabletX: Float = 0
    @Published var tabletY: Float = 0.10
    @Published var tabletZ: Float = -0.88
    @Published var recenterRevision = 0
    @Published var foundationReady = false
    @Published var environment: SignalCinemaEnvironment = .paidFab
    @Published var environmentScale: Float = 1.0
    @Published var environmentDepth: Float = 0.0
    @Published var environmentHeight: Float = 0.0

    func resetTablet() {
        tabletX = 0
        tabletY = 0.10
        tabletZ = -0.88
    }
    func requestRecenter() { recenterRevision &+= 1 }
}

@MainActor
private final class SignalDevicePoseTracker {
    static let shared = SignalDevicePoseTracker()
    private let session = ARKitSession()
    private let worldTracking = WorldTrackingProvider()
    private var started = false

    func startIfNeeded() async {
        guard !started, WorldTrackingProvider.isSupported else { return }
        started = true
        do { try await session.run([worldTracking]) }
        catch {
            started = false
            print("[SignalCinema] world tracking start failed: \(error)")
        }
    }

    func pose() -> simd_float4x4? {
        guard worldTracking.state == .running,
              let anchor = worldTracking.queryDeviceAnchor(atTimestamp: CACurrentMediaTime()),
              anchor.isTracked else { return nil }
        return anchor.originFromAnchorTransform
    }
}

struct SignalImmersiveBootstrap: View {
    @Environment(\.openImmersiveSpace) private var openImmersiveSpace
    @Environment(\.dismissWindow) private var dismissWindow
    @State private var requested = false

    var body: some View {
        Color.clear.frame(width: 1, height: 1).task {
            guard !requested else { return }
            requested = true
            if case .opened = await openImmersiveSpace(id: "signal-cinema") {
                dismissWindow(id: "signal-main")
            }
        }
    }
}

struct SignalImmersiveFoundationSpace: View {
    @StateObject private var state = SignalImmersiveFoundationState.shared
    @State private var lastAppliedRecenter = -1
    @State private var tabletDragOffset: SIMD3<Float>?

    var body: some View {
        RealityView { content, attachments in
            let root = Entity()
            root.name = "SignalCinemaRoot"
            content.add(root)

            let environments = Entity()
            environments.name = "SignalEnvironmentContainer"
            root.addChild(environments)

            // Purchased/user-supplied asset #1. Geometry only: none of the old theater
            // coordinator/seat/world transforms are restored.
            if let fab = Self.loadBundledEntity("SignalPaidFabMovieTheater") {
                fab.name = "SignalPaidFabEnvironment"
                fab.scale = [0.35, 0.35, 0.35]
                // Source screen is at the auditorium front. This translation keeps the
                // complete seat bank behind the wearer instead of intersecting the head/body.
                fab.position = [0, -1.15, 3.0]
                environments.addChild(fab)
                Self.applyBlackSeatMaterialIfPresent(in: fab)
            }

            // Purchased/user-supplied asset #2. Kept as a separate selectable environment.
            if let interior = Self.loadBundledEntity("SignalPaidCinemaInterior") {
                interior.name = "SignalPaidInteriorEnvironment"
                Self.fitImportedInterior(interior)
                environments.addChild(interior)
            }

            let clean = Self.makeCleanCinema()
            clean.name = "SignalCleanRoomEnvironment"
            environments.addChild(clean)

            if let tablet = attachments.entity(for: "signal-control-tablet") {
                tablet.name = "SignalControlTablet"
                tablet.isEnabled = false
                tablet.components.set(InputTargetComponent())
                tablet.components.set(CollisionComponent(shapes: [
                    ShapeResource.generateBox(size: SIMD3<Float>(0.58, 0.34, 0.04))
                ]))
                tablet.components.set(HoverEffectComponent())
                root.addChild(tablet)
            }

            Self.updateEnvironmentVisibility(in: root, selected: state.environment)
        } update: { content, attachments in
            guard let root = content.entities.first(where: { $0.name == "SignalCinemaRoot" }) else { return }

            if state.recenterRevision != lastAppliedRecenter,
               let pose = SignalDevicePoseTracker.shared.pose() {
                root.transform = Self.horizontalSpawnTransform(from: pose)
                lastAppliedRecenter = state.recenterRevision
                state.foundationReady = true
            }

            Self.updateEnvironmentVisibility(in: root, selected: state.environment)
            Self.applyEnvironmentAdjustment(in: root, state: state)

            if let tablet = attachments.entity(for: "signal-control-tablet") {
                tablet.isEnabled = state.foundationReady
                tablet.position = [state.tabletX, state.tabletY, state.tabletZ]
                tablet.orientation = simd_quatf(angle: 0, axis: [0, 1, 0])
            }
        } attachments: {
            Attachment(id: "signal-control-tablet") {
                SignalCinemaControlTablet(state: state)
                    .frame(width: 620, height: 440)
                    .glassBackgroundEffect(in: RoundedRectangle(cornerRadius: 34))
            }
        }
        // True spatial entity drag. This no longer interprets a 2D SwiftUI pixel delta as
        // world X/Y; the pinch location is converted into the tablet parent's 3D coordinates.
        .gesture(
            DragGesture(minimumDistance: 0)
                .targetedToAnyEntity()
                .onChanged { value in
                    guard value.entity.name == "SignalControlTablet",
                          let parent = value.entity.parent else { return }
                    let pointer = value.convert(value.location3D, from: .local, to: parent)
                    if tabletDragOffset == nil {
                        tabletDragOffset = value.entity.position - pointer
                    }
                    let target = pointer + (tabletDragOffset ?? .zero)
                    state.tabletX = target.x
                    state.tabletY = target.y
                    state.tabletZ = target.z
                }
                .onEnded { _ in tabletDragOffset = nil }
        )
        .task {
            await SignalDevicePoseTracker.shared.startIfNeeded()
            // Wait for a valid tracked headset pose before exposing either environment or HUD.
            for _ in 0..<150 {
                if SignalDevicePoseTracker.shared.pose() != nil {
                    state.resetTablet()
                    state.requestRecenter()
                    return
                }
                try? await Task.sleep(nanoseconds: 40_000_000)
            }
        }
    }

    private static func loadBundledEntity(_ resource: String) -> Entity? {
        let candidates = [resource, "\(resource).usdz", "Cinema/\(resource)", "Cinema/\(resource).usdz"]
        for candidate in candidates {
            if let entity = try? Entity.load(named: candidate, in: .main) { return entity }
        }
        print("[SignalCinema] missing bundled environment: \(resource)")
        return nil
    }

    private static func horizontalSpawnTransform(from pose: simd_float4x4) -> Transform {
        let p = SIMD3<Float>(pose.columns.3.x, pose.columns.3.y, pose.columns.3.z)
        var f = SIMD3<Float>(-pose.columns.2.x, 0, -pose.columns.2.z)
        f = simd_length_squared(f) < 0.0001 ? SIMD3<Float>(0, 0, -1) : simd_normalize(f)
        let yaw = atan2(f.x, -f.z)
        return Transform(scale: .one, rotation: simd_quatf(angle: yaw, axis: [0, 1, 0]), translation: p)
    }

    private static func updateEnvironmentVisibility(in root: Entity, selected: SignalCinemaEnvironment) {
        root.findEntity(named: "SignalPaidFabEnvironment")?.isEnabled = selected == .paidFab
        root.findEntity(named: "SignalPaidInteriorEnvironment")?.isEnabled = selected == .paidInterior
        root.findEntity(named: "SignalCleanRoomEnvironment")?.isEnabled = selected == .cleanRoom
    }

    private static func applyEnvironmentAdjustment(in root: Entity, state: SignalImmersiveFoundationState) {
        if let fab = root.findEntity(named: "SignalPaidFabEnvironment") {
            let s = 0.35 * max(0.80, min(1.25, state.environmentScale))
            fab.scale = [s, s, s]
            fab.position = [0, -1.15 + state.environmentHeight, 3.0 + state.environmentDepth]
        }
        if let interior = root.findEntity(named: "SignalPaidInteriorEnvironment") {
            let base = interior.components[SignalBaseTransformComponent.self]?.transform ?? interior.transform
            let factor = max(0.80, min(1.25, state.environmentScale))
            interior.scale = base.scale * factor
            interior.position = base.translation + [0, state.environmentHeight, state.environmentDepth]
        }
    }

    private static func fitImportedInterior(_ entity: Entity) {
        let bounds = entity.visualBounds(relativeTo: entity)
        let extent = bounds.extents
        let safeWidth = max(extent.x, 0.001)
        let safeDepth = max(extent.z, 0.001)
        let s = min(10.5 / safeWidth, 12.0 / safeDepth)
        let center = bounds.center
        // Put the imported floor around -1.25m and its center several meters forward.
        let floor = center.y - extent.y * 0.5
        entity.scale = [s, s, s]
        entity.position = [
            -center.x * s,
            -1.25 - floor * s,
            -4.5 - center.z * s
        ]
        entity.components.set(SignalBaseTransformComponent(transform: entity.transform))
    }

    private static func applyBlackSeatMaterialIfPresent(in entity: Entity) {
        if entity.name.localizedCaseInsensitiveContains("seat"),
           let model = entity as? ModelEntity,
           var component = model.model {
            let charcoal = SimpleMaterial(
                color: .init(red: 0.025, green: 0.027, blue: 0.030, alpha: 1),
                roughness: 0.72,
                isMetallic: false
            )
            component.materials = Array(repeating: charcoal, count: max(1, component.materials.count))
            model.model = component
        }
        for child in entity.children { applyBlackSeatMaterialIfPresent(in: child) }
    }

    private static func makeCleanCinema() -> Entity {
        let room = Entity()
        func box(_ name: String, _ size: SIMD3<Float>, _ pos: SIMD3<Float>, _ material: SimpleMaterial) {
            let e = ModelEntity(mesh: .generateBox(size: size), materials: [material])
            e.name = name
            e.position = pos
            room.addChild(e)
        }
        let dark = SimpleMaterial(color: .init(white: 0.035, alpha: 1), roughness: 0.82, isMetallic: false)
        let wall = SimpleMaterial(color: .init(red: 0.07, green: 0.055, blue: 0.06, alpha: 1), roughness: 0.9, isMetallic: false)
        let screen = SimpleMaterial(color: .init(white: 0.72, alpha: 1), roughness: 0.96, isMetallic: false)
        box("Floor", [12, 0.12, 15], [0, -1.30, -1], dark)
        box("Ceiling", [12, 0.12, 15], [0, 3.4, -1], dark)
        box("LeftWall", [0.15, 4.8, 15], [-6, 1.05, -1], wall)
        box("RightWall", [0.15, 4.8, 15], [6, 1.05, -1], wall)
        box("FrontWall", [12, 4.8, 0.15], [0, 1.05, -8.25], wall)
        box("BackWall", [12, 4.8, 0.15], [0, 1.05, 6.25], wall)
        box("MainScreen", [7.8, 3.45, 0.08], [0, 0.65, -8.10], screen)
        return room
    }
}

private struct SignalBaseTransformComponent: Component {
    var transform: Transform
}

private struct SignalCinemaControlTablet: View {
    @ObservedObject var state: SignalImmersiveFoundationState

    var body: some View {
        VStack(alignment: .leading, spacing: 14) {
            HStack {
                VStack(alignment: .leading, spacing: 3) {
                    Text("SIGNAL").font(.system(size: 19, weight: .black))
                    Text("VISION CINEMA / RESET3").font(.caption).foregroundStyle(.secondary)
                }
                Spacer()
                Image(systemName: "move.3d")
                Text("Pinch + drag anywhere on tablet").font(.caption).foregroundStyle(.secondary)
            }
            Divider()
            Text("Environment").font(.headline)
            Picker("Environment", selection: $state.environment) {
                ForEach(SignalCinemaEnvironment.allCases) { environment in
                    Text(environment.rawValue).tag(environment)
                }
            }
            .pickerStyle(.segmented)

            HStack(spacing: 12) {
                Button("Recenter") {
                    state.resetTablet()
                    state.requestRecenter()
                }.buttonStyle(.borderedProminent)
                Button("Reset Tablet") { state.resetTablet() }
                Spacer()
                Text(String(format: "x %.2f  y %.2f  z %.2f", state.tabletX, state.tabletY, state.tabletZ))
                    .font(.caption.monospacedDigit()).foregroundStyle(.secondary)
            }

            HStack {
                Text("Room size")
                Slider(value: $state.environmentScale, in: 0.80...1.25)
                Text("Depth")
                Slider(value: $state.environmentDepth, in: -2.0...2.0)
                Text("Height")
                Slider(value: $state.environmentHeight, in: -1.0...1.0)
            }
            .font(.caption)
        }
        .padding(24)
        .background(.black.opacity(0.20))
    }
}
#endif
