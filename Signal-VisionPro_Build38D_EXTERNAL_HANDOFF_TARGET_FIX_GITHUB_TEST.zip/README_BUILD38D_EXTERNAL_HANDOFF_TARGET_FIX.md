# Build 38D — External Theater handoff target-membership fix

Base: Build 38C.

38C's only compiler error was that the new standalone
SignalTheaterExternalHandoff.swift file was not included by the existing 38B
XcodeGen source membership, so SignalVisionSpatialControls could not see the
type.

38D keeps the 38B project/source configuration untouched and embeds the same
isolated handoff helper at file scope in the already-compiled
SignalVisionSpatialControls.swift.

No 38B runtime/UI, theater, catalog, navigation, playback, resource, or asset
logic is changed.
