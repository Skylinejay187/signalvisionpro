# Build 38C — 38B baseline + external Theater handoff

Base: user-supplied Build 38B.

38C deliberately keeps the known 38B runtime/UI baseline and does not carry
forward Build 39's runtime-regression chain.

Added:
- Theater App button beside the existing internal Enter Theater button.
- Open in Theater App inside the existing Vision Pro/Theater settings.
- Isolated external handoff helper.

Theater publicly advertises partner deep-link support, but no public arbitrary
media URL payload/route was found. 38C therefore preserves Signal playback,
copies the resolved media URL, publishes an NSUserActivity, and attempts the
public Theater universal link. If the installed app does not claim that link,
the public Theater page opens and the stream URL remains copied.

When Sandwich Vision's documented partner route/payload is obtained, direct
media launch can be added by changing only SignalTheaterExternalHandoff.swift.
